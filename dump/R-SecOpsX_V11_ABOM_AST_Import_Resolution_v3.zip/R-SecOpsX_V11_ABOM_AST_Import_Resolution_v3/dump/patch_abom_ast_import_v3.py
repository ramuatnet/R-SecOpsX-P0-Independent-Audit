from __future__ import annotations

import ast
import hashlib
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(r"D:\Data\Code test\R-SecOpsX_V11")
PROD = ROOT / "scanner" / "abom.py"
BACKUP_DIR = ROOT / "backup"
TEST = ROOT / "tests" / "test_v11_abom_ast_import_v3.py"

MARKER = "# --- V11 ABOM AST/IMPORT RESOLUTION v3 ---"


def run(cmd):
    print("[INFO]", " ".join(str(x) for x in cmd))
    subprocess.run(cmd, cwd=str(ROOT), check=True)


def main():
    if not PROD.exists():
        raise RuntimeError(f"Production ABOM not found: {PROD}")

    original = PROD.read_text(encoding="utf-8-sig")
    if MARKER in original:
        raise RuntimeError("ABOM AST/import v3 is already installed.")

    tree = ast.parse(original, filename=str(PROD))
    funcs = {
        n.name for n in ast.walk(tree)
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    if "scan_file" not in funcs:
        raise RuntimeError("Required scan_file() function not found.")

    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup = BACKUP_DIR / f"abom.py.before_abom_ast_import_v3_{stamp}.py"
    backup.write_text(original, encoding="utf-8")

    source = original
    lines = source.splitlines()

    imports = []
    if "import ast" not in source:
        imports.append("import ast")
    if "import hashlib" not in source:
        imports.append("import hashlib")

    if imports:
        idx = 0
        while idx < len(lines):
            s = lines[idx].strip()
            if not s or s.startswith("#") or s.startswith("import ") or s.startswith("from "):
                idx += 1
            else:
                break
        lines[idx:idx] = imports
        source = "\n".join(lines) + "\n"

    helper = r