# R-SecOpsX V11 — Evidence Schema v1

This phase implements only the canonical Evidence envelope. It does not alter detector logic, reporting, RCMSP, or Agent/MCP/RAG detection.

Required envelope:
- evidence_id
- source
- timestamp
- provenance
- type
- content_or_context
- confidence

Validation:
- UUID evidence_id
- ISO-8601 timestamp
- mandatory provenance
- controlled type/confidence

The mapping adapter is intentionally strict: it rejects missing required fields instead of guessing them.
