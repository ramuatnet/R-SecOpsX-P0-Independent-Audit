# R-SecOpsX V11 — Evidence Adapter v1

This is a compatibility adapter between the existing V11 finding/evidence contract
and the canonical Evidence Schema v1.

Important:
- It is non-mutating.
- It does not replace `core/finding_model.py`.
- It does not alter `core/analyzer.py`.
- Existing `evidence_valid` remains authoritative.
- Missing qualification is rejected rather than guessed.
- Existing finding identity is retained as `related_finding_id`.
- A canonical UUID is accepted only when an existing `evidence_id` is already present;
  the adapter deliberately does not fabricate a UUID from an arbitrary fingerprint.

Integration is intentionally a separate step after this adapter gate passes.
