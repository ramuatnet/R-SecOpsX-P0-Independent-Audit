from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path


VEX_VERSION = "1.0"


def _component_ref(pkg: dict) -> str:
    name = str(pkg.get("name") or "unknown")
    version = str(pkg.get("version") or "unknown")
    ecosystem = str(pkg.get("ecosystem") or "unknown").lower()
    return f"pkg:{ecosystem}/{name}@{version}".replace(" ", "_")


def _vulnerability_id(pkg: dict) -> str | None:
    return (
        pkg.get("cve")
        or pkg.get("primary_vulnerability_id")
        or pkg.get("advisory_id")
    )


def _reachability_status(pkg: dict) -> str:
    return str(pkg.get("reachability_priority") or pkg.get("reachability_status") or "UNKNOWN")


def _vex_status(pkg: dict) -> str:
    priority = str(pkg.get("reachability_priority") or "").upper()
    reachable = str(pkg.get("reachability_status") or "").upper()
    kev = bool(pkg.get("kev_status"))
    epss_priority = str(pkg.get("epss_priority") or "").upper()

    if priority == "REACHABLE_VULNERABLE" or reachable == "REACHABLE":
        return "affected"

    if priority == "NOT_OBSERVED_VULNERABLE":
        return "under_investigation"

    if kev or epss_priority == "P0_IMMEDIATE":
        return "under_investigation"

    return "not_affected"


def _justification(pkg: dict) -> str:
    status = _vex_status(pkg)

    if status == "affected":
        return "reachable_code"

    if status == "under_investigation":
        return "insufficient_runtime_evidence"

    return "vulnerable_code_not_in_execute_path"


def _impact_statement(pkg: dict) -> str:
    status = _vex_status(pkg)

    if status == "affected":
        return (
            "R-SecOpsX determined this vulnerable component is reachable or "
            "manifest-referenced in a way that requires remediation review."
        )

    if status == "under_investigation":
        return (
            "R-SecOpsX found vulnerability evidence, but reachability or exploitability "
            "could not be conclusively established."
        )

    return (
        "R-SecOpsX did not observe reachable usage evidence for this vulnerable "
        "component in the current scan context."
    )


def _action_statement(pkg: dict) -> str:
    patch_urgency = str(pkg.get("patch_urgency") or "").upper()
    epss_priority = str(pkg.get("epss_priority") or "").upper()

    if patch_urgency == "IMMEDIATE" or epss_priority == "P0_IMMEDIATE":
        return "Apply patch immediately or obtain formal executive exception."

    if _vex_status(pkg) == "affected":
        return "Prioritize remediation according to severity and reachability."

    if _vex_status(pkg) == "under_investigation":
        return "Review component usage, exposure, and exploitability evidence."

    return "No immediate action required unless deployment context changes."


def _statement(pkg: dict) -> dict | None:
    vuln_id = _vulnerability_id(pkg)

    if not vuln_id:
        return None

    status = _vex_status(pkg)

    return {
        "vulnerability": {
            "id": str(vuln_id),
            "source": (
                "NVD"
                if str(vuln_id).startswith("CVE-")
                else "GitHub Advisory"
                if str(vuln_id).startswith("GHSA-")
                else "R-SecOpsX"
            ),
        },
        "product": {
            "component": str(pkg.get("name") or "unknown"),
            "version": str(pkg.get("version") or "unknown"),
            "ecosystem": str(pkg.get("ecosystem") or "unknown"),
            "bom_ref": _component_ref(pkg),
        },
        "status": status,
        "justification": _justification(pkg),
        "impact_statement": _impact_statement(pkg),
        "action_statement": _action_statement(pkg),
        "properties": {
            "reachability_status": _reachability_status(pkg),
            "reachability_confidence": pkg.get("reachability_confidence"),
            "kev_status": pkg.get("kev_status"),
            "actively_exploited": pkg.get("actively_exploited"),
            "outbreak_status": pkg.get("outbreak_status"),
            "patch_urgency": pkg.get("patch_urgency"),
            "epss_score": pkg.get("epss_score"),
            "epss_bucket": pkg.get("epss_bucket"),
            "epss_priority": pkg.get("epss_priority"),
            "severity": pkg.get("severity"),
            "cvss": pkg.get("cvss"),
            "advisory_id": pkg.get("advisory_id"),
            "cve": pkg.get("cve"),
        },
    }


def build_vex(payload: dict) -> dict:
    sbom = payload.get("sbom", []) or []
    metadata = payload.get("metadata", {}) or {}

    statements = [
        stmt for stmt in (_statement(pkg) for pkg in sbom) if stmt
    ]

    return {
        "document": {
            "type": "R-SecOpsX VEX",
            "version": VEX_VERSION,
            "id": f"urn:uuid:{uuid.uuid4()}",
            "created": datetime.now(timezone.utc).isoformat(),
            "author": "R-SecOpsX",
        },
        "metadata": {
            "total_statements": len(statements),
            "risk_score": metadata.get("risk_score"),
            "executive_decision": metadata.get("executive_decision"),
            "reachability_summary": payload.get("reachability_summary"),
            "vulnerability_age_summary": payload.get("vulnerability_age_summary"),
            "epss_intelligence_summary": payload.get("epss_intelligence_summary"),
        },
        "statements": statements,
    }


def write_vex_report(payload: dict, output_path: str) -> str:
    vex = build_vex(payload)

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    with out.open("w", encoding="utf-8") as f:
        json.dump(vex, f, indent=2, default=str)

    return str(out)


if __name__ == "__main__":
    sample_payload = {
        "metadata": {
            "risk_score": 90,
            "executive_decision": "DO_NOT_RELEASE",
        },
        "sbom": [
            {
                "name": "log4j-core",
                "version": "2.14.1",
                "ecosystem": "maven",
                "cve": "CVE-2021-44228",
                "severity": "Critical",
                "cvss": 10.0,
                "reachability_status": "REACHABLE",
                "reachability_priority": "REACHABLE_VULNERABLE",
                "reachability_confidence": 0.95,
                "kev_status": True,
                "actively_exploited": True,
                "outbreak_status": "OUTBREAK_ACTIVE_REACHABLE",
                "patch_urgency": "IMMEDIATE",
                "epss_score": 0.975,
                "epss_bucket": "VERY_HIGH_EXPLOIT_PROBABILITY",
                "epss_priority": "P0_IMMEDIATE",
            },
            {
                "name": "lodash",
                "version": "4.17.20",
                "ecosystem": "npm",
                "cve": "CVE-2021-23337",
                "severity": "High",
                "reachability_status": "NOT_OBSERVED",
                "reachability_priority": "NOT_OBSERVED_VULNERABLE",
                "epss_score": 0.021,
                "epss_priority": "P3_STANDARD",
            },
            {
                "name": "left-pad",
                "version": "1.3.0",
                "ecosystem": "npm",
                "advisory_id": "GHSA-test",
                "severity": "Medium",
                "reachability_status": "UNKNOWN",
            },
        ],
        "reachability_summary": {},
        "vulnerability_age_summary": {},
        "epss_intelligence_summary": {},
    }

    write_vex_report(sample_payload, "reports/vex.rsecopsx.json")
    print("VEX written to reports/vex.rsecopsx.json")