# ---- RSECOpsX PDF COMPLIANCE TABLE FALLBACK PATCH V1 ----
# Mapping-only fallback used by PDF compliance table rendering.
# Does not alter scanner output, layout, colors, theme, or report structure.

PDF_COMPLIANCE_FALLBACK_BY_TITLE = {
    "tenant isolation failure indicator": {
        "pci_dss": "Req 7 / Req 8 - Access control and tenant data segregation",
        "nist": "AC-3 / AC-6 / SC-7",
        "nist_800_53": "AC-3 / AC-6 / SC-7",
        "iso27001": "A.5.15 / A.8.3 / A.8.20",
        "iso_27001": "A.5.15 / A.8.3 / A.8.20",
        "soc2": "CC6.1 / CC6.6 / CC7.2",
    },
    "graphql introspection exposure": {
        "pci_dss": "Req 6.2.4 - Secure API configuration",
        "nist": "CM-7 / AC-3 / SC-7",
        "nist_800_53": "CM-7 / AC-3 / SC-7",
        "iso27001": "A.8.9 / A.8.20",
        "iso_27001": "A.8.9 / A.8.20",
        "soc2": "CC6.6 / CC7.2",
    },
    "graphql resolver bola / idor indicator": {
        "pci_dss": "Req 7 / Req 8 - Access control",
        "nist": "AC-3 / AC-6 / SI-10",
        "nist_800_53": "AC-3 / AC-6 / SI-10",
        "iso27001": "A.5.15 / A.8.3 / A.8.20",
        "iso_27001": "A.5.15 / A.8.3 / A.8.20",
        "soc2": "CC6.1 / CC6.6",
    },
    "dangerous reflection setaccessible(true)": {
        "pci_dss": "Req 6.2.4 - Secure coding and unsafe reflection prevention",
        "nist": "SI-10 / CM-7 / SA-11",
        "nist_800_53": "SI-10 / CM-7 / SA-11",
        "iso27001": "A.8.28 / A.8.29",
        "iso_27001": "A.8.28 / A.8.29",
        "soc2": "CC7.1 / CC7.2",
    },
}

def _rsecopsx_pdf_value_is_empty(value):
    text = str(value or "").strip()
    return (not text) or text.lower() in {
        "not applicable", "n/a", "na", "none", "null", "unknown", "-"
    }

def _rsecopsx_pdf_apply_compliance_fallback(finding):
    if not isinstance(finding, dict):
        return finding

    title = str(finding.get("title", "")).strip().lower()
    rule = str(finding.get("rule_id", "")).strip().lower()
    vuln = str(finding.get("vuln_type", "")).strip().lower()
    combined = f"{title} {rule} {vuln}"

    fallback = None
    for key, value in PDF_COMPLIANCE_FALLBACK_BY_TITLE.items():
        if key in combined:
            fallback = value
            break

    if not fallback:
        if "tenant" in combined and "isolation" in combined:
            fallback = PDF_COMPLIANCE_FALLBACK_BY_TITLE["tenant isolation failure indicator"]
        elif "graphql" in combined and "introspection" in combined:
            fallback = PDF_COMPLIANCE_FALLBACK_BY_TITLE["graphql introspection exposure"]
        elif "graphql" in combined and ("idor" in combined or "bola" in combined):
            fallback = PDF_COMPLIANCE_FALLBACK_BY_TITLE["graphql resolver bola / idor indicator"]
        elif "setaccessible" in combined or "set_accessible" in combined:
            fallback = PDF_COMPLIANCE_FALLBACK_BY_TITLE["dangerous reflection setaccessible(true)"]

    if not fallback:
        return finding

    for field, mapped in fallback.items():
        if _rsecopsx_pdf_value_is_empty(finding.get(field)):
            finding[field] = mapped

    return finding

try:
    _RSECOpsX_ORIGINAL_GENERATE_PDF_REPORT = generate_pdf_report  # type: ignore[name-defined]

    def generate_pdf_report(payload, output_path):  # type: ignore[no-redef]
        if isinstance(payload, dict):
            for finding in payload.get("findings", []) or []:
                _rsecopsx_pdf_apply_compliance_fallback(finding)
        return _RSECOpsX_ORIGINAL_GENERATE_PDF_REPORT(payload, output_path)
except Exception:
    pass
# ---- END RSECOpsX PDF COMPLIANCE TABLE FALLBACK PATCH V1 ----
