"""
reporting/excel_report.py  v3

FIX LOG (v2 → v3):
  1. BUG  — SBOM sheet: pkg.get("direct", True) replaced with pkg.get("type", "Direct")
             to match the string field now produced by sbom.py v3
  2. BUG  — File column: str(Path(...).name) fails on Windows-style backslash paths
             on Linux/macOS; replaced with os.path.basename() (cross-platform)
  3. WARN — Findings sheet: "Confidence" and "Score Rationale" columns added,
             surfacing score_finding() breakdown and taint confidence per finding
  4. WARN — Findings sheet: "Affected Files" column added, showing all files
             from the grouped finding's affected_files[] list
  5. ENH  — Summary sheet: risk score model description rows added so auditors
             can understand and challenge the portfolio score without the PDF
"""
from __future__ import annotations

import os
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

C_NAVY = "1B3A5C"; C_BLUE = "2563A8"; C_LBLUE = "D6E8F7"
C_RED  = "C0392B"; C_ORG  = "E67E22"; C_YEL   = "F1C40F"
C_GRN  = "27AE60"; C_WHT  = "FFFFFF"; C_GRY   = "F4F6F8"
C_BDR  = "B8CCE4"; C_BLK  = "1A1A2E"; C_GOLD  = "C9A84C"
# Confidence cell colours
C_CONF_HIGH = "E8F5E9"  # light green
C_CONF_MED  = "FFF8E1"  # light amber
C_CONF_LOW  = "FFEBEE"  # light red

def _fill(h):  return PatternFill("solid", fgColor=h)
def _font(bold=False, color=C_WHT, size=10):
    return Font(name="Calibri", bold=bold, color=color, size=size)
def _bdr():
    t = Side(style="thin", color=C_BDR)
    return Border(left=t, right=t, top=t, bottom=t)
def _ctr(): return Alignment(horizontal="center", vertical="center", wrap_text=True)
def _lft(): return Alignment(horizontal="left",   vertical="center", wrap_text=True)

SEV_FILL = {
    "Critical": _fill(C_RED), "High": _fill(C_ORG), "Medium": _fill(C_YEL),
    "Low": _fill(C_GRN), "Info": _fill("808080"), "None": _fill(C_GRN),
}
SEV_FONT = {
    "Critical": _font(True), "High": _font(True),
    "Medium":   _font(True, color=C_BLK), "Low": _font(True),
    "Info":     _font(True), "None": _font(True),
}
CONF_FILL = {
    "High":   _fill(C_CONF_HIGH),
    "Medium": _fill(C_CONF_MED),
    "Low":    _fill(C_CONF_LOW),
}
CONF_FONT = {
    "High":   _font(color="1B5E20"),
    "Medium": _font(color="E65100"),
    "Low":    _font(color="B71C1C"),
}

def _hdr(ws, row, headers, col=1):
    for i, h in enumerate(headers):
        c = ws.cell(row=row, column=col + i, value=h)
        c.fill = _fill(C_NAVY); c.font = _font(True); c.alignment = _ctr(); c.border = _bdr()

def _title_row(ws, text, cols):
    ws.merge_cells(f"A1:{get_column_letter(cols)}1")
    c = ws["A1"]; c.value = text
    c.fill = _fill(C_NAVY); c.font = _font(True, size=12)
    c.alignment = _ctr(); ws.row_dimensions[1].height = 30


# ── Sheet 1: Summary ─────────────────────────────────────────────────────────
def _summary(ws, payload):
    ws.title = "Summary"
    for col, w in zip("ABCDE", [28, 20, 16, 30, 30]):
        ws.column_dimensions[col].width = w

    meta  = payload.get("metadata", {})
    dist  = meta.get("severity_distribution", {})
    model = meta.get("risk_score_model", {})

    _title_row(ws, "SECURITY ASSESSMENT — EXECUTIVE SUMMARY", 5)

    # FIX #5: include scoring model rows so auditors can understand the score
    rows = [
        ("Tool",                meta.get("tool", "")),
        ("Target",              meta.get("target", "")),
        ("Scan Date",           meta.get("scan_date", "")[:10]),
        ("SAST Findings",       meta.get("sast_findings", meta.get("total_findings", 0))),
        ("SCA Findings",        meta.get("sca_findings", 0)),
        ("Total Findings",      meta.get("total_findings", 0)),
        ("Portfolio Risk Score", f"{meta.get('risk_score', 0)}/100"),
        ("Scoring Model",       model.get("model", "")),
        ("Score Formula",       model.get("portfolio_method", "")),
        ("Confidence Multipliers", "High=1.0×  Medium=0.85×  Low=0.70×"),
    ]
    for i, (lbl, val) in enumerate(rows, 2):
        ws.cell(row=i, column=1, value=lbl).font  = _font(True, color=C_BLK)
        ws.cell(row=i, column=1).fill              = _fill(C_GRY)
        ws.cell(row=i, column=1).alignment         = _lft()
        ws.cell(row=i, column=2, value=val).font   = _font(color=C_BLK)
        ws.cell(row=i, column=2).alignment         = _lft()

    sr = len(rows) + 3
    ws.merge_cells(f"A{sr}:E{sr}")
    h = ws[f"A{sr}"]; h.value = "SEVERITY DISTRIBUTION"
    h.fill = _fill(C_BLUE); h.font = _font(True, size=11); h.alignment = _ctr()
    ws.row_dimensions[sr].height = 22

    _hdr(ws, sr + 1, ["Severity", "Count", "Priority", "SLA", "Risk Action"])
    slas = {"Critical": "< 24 hours", "High": "7 days", "Medium": "30 days",
            "Low": "90 days", "Info": "Next sprint"}
    pris = {"Critical": "P1", "High": "P2", "Medium": "P3", "Low": "P4", "Info": "P4"}
    acts = {
        "Critical": "Remediate immediately — block release",
        "High":     "Fix within 7 days — escalate to security lead",
        "Medium":   "Fix within 30 days — add to sprint backlog",
        "Low":      "Fix within 90 days — track in backlog",
        "Info":     "Review at convenience",
    }
    for j, sev in enumerate(["Critical", "High", "Medium", "Low", "Info"]):
        r = sr + 2 + j
        for col, val in enumerate([sev, dist.get(sev, 0), pris[sev], slas[sev], acts[sev]], 1):
            c = ws.cell(row=r, column=col, value=val)
            c.border = _bdr()
            if col == 1:
                c.fill = SEV_FILL.get(sev, _fill(C_GRY))
                c.font = SEV_FONT.get(sev, _font(color=C_BLK))
                c.alignment = _ctr()
            else:
                c.fill = _fill(C_GRY); c.font = _font(color=C_BLK)
                c.alignment = _lft() if col == 5 else _ctr()

    ir = sr + 9
    ws.merge_cells(f"A{ir}:E{ir}")
    ih = ws[f"A{ir}"]; ih.value = "INTELLIGENCE INSIGHTS"
    ih.fill = _fill(C_NAVY); ih.font = _font(True, size=11); ih.alignment = _ctr()
    for k, ins in enumerate(payload.get("insights", []), 1):
        r = ir + k
        ws.merge_cells(f"A{r}:E{r}")
        c = ws[f"A{r}"]; c.value = f"* {ins}"
        c.font = _font(color=C_BLK, size=9)
        c.fill = _fill(C_GRY if k % 2 else C_WHT)
        c.alignment = _lft(); c.border = _bdr()
        ws.row_dimensions[r].height = 28


# ── Sheet 2: Findings ─────────────────────────────────────────────────────────
def _findings(ws, payload):
    ws.title = "Findings"
    # FIX #3: added Confidence and Score Rationale columns
    # FIX #4: added Affected Files column
    headers = [
        "#", "Issue", "Severity", "Priority", "Risk Score",
        "File", "Affected Files", "Line",
        "CWE", "OWASP", "MITRE",
        "PCI DSS", "NIST", "ISO 27001", "SOC2",
        "CVE", "CVSS",
        "Confidence", "Instances", "Score Rationale", "Fix Summary",
    ]
    widths = [
        4,   32,   12,   10,   10,
        28,  42,   6,
        14,  28,   12,
        30,  28,   24,   20,
        18,  8,
        12,  10,   52,   45,
    ]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    _title_row(ws, "DETAILED SECURITY FINDINGS — ALL COMPLIANCE FIELDS", len(headers))
    _hdr(ws, 2, headers)
    ws.row_dimensions[2].height = 22
    ws.freeze_panes = "A3"

    for i, f in enumerate(payload.get("grouped", []), start=3):
        sev        = f.get("severity", "Medium")
        confidence = f.get("confidence", "")
        bg         = C_LBLUE if i % 2 == 0 else C_WHT
        rem        = f.get("remediation", [])
        instances  = f.get("instances", 1)

        # FIX #2: cross-platform file name extraction
        primary_file   = os.path.basename(f.get("file", ""))
        # FIX #4: show all affected files (basename of each)
        affected_files = f.get("affected_files", [f.get("file", "")])
        affected_str   = "; ".join(os.path.basename(fp) for fp in affected_files)

        score_explanation = f.get("score_breakdown", {}).get("explanation", "")

        row_vals = [
            i - 2,
            f.get("title", ""),
            sev,
            f.get("priority", ""),
            f.get("risk_score", ""),
            primary_file,
            affected_str,             # FIX #4
            f.get("line", ""),
            f.get("cwe", ""),
            f.get("owasp", ""),
            f.get("mitre", ""),
            f.get("pci_dss", ""),
            f.get("nist", ""),
            f.get("iso27001", ""),
            f.get("soc2", ""),
            f.get("cve") or "N/A",
            f.get("cvss") or "N/A",
            confidence,               # FIX #3
            instances,
            score_explanation,        # FIX #3
            rem[0] if rem else "",
        ]
        for j, val in enumerate(row_vals, 1):
            cell = ws.cell(row=i, column=j, value=val)
            cell.border    = _bdr()
            cell.font      = Font(name="Calibri", size=9, color=C_BLK)
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
            if j == 3:   # Severity
                cell.fill = SEV_FILL.get(sev, _fill(bg))
                cell.font = SEV_FONT.get(sev, _font(color=C_BLK))
                cell.alignment = _ctr()
            elif j == 18:  # FIX #3: Confidence — colour-coded cell
                cell.fill = CONF_FILL.get(confidence, _fill(bg))
                cell.font = CONF_FONT.get(confidence, _font(color=C_BLK))
                cell.alignment = _ctr()
            else:
                cell.fill = _fill(bg)
        ws.row_dimensions[i].height = 30


# ── Sheet 3: SBOM ─────────────────────────────────────────────────────────────
def _sbom(ws, payload):
    ws.title = "SBOM"
    headers = [
        "Package", "Version", "Type", "Parent", "CVE", "CVSS", "EPSS",
        "Severity", "Reachable", "Fixed In", "Additional CVEs", "NVD Link",
    ]
    widths = [22, 14, 12, 18, 20, 8, 8, 12, 10, 12, 28, 52]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    _title_row(ws, "SOFTWARE BILL OF MATERIALS (SBOM) — WITH CVE + EPSS", len(headers))
    _hdr(ws, 2, headers)
    ws.row_dimensions[2].height = 22
    ws.freeze_panes = "A3"

    for i, pkg in enumerate(payload.get("sbom", []), start=3):
        sev    = pkg.get("severity", "None")
        bg     = C_LBLUE if i % 2 == 0 else C_WHT
        epss   = pkg.get("epss")
        epss_s = f"{epss:.3f}" if epss is not None else "--"
        # FIX #1: read "type" string field (was "direct" boolean in v2 sbom.py)
        pkg_type       = pkg.get("type", "Direct")
        parent         = pkg.get("parent", "--")
        additional_cve = ", ".join(pkg.get("additional_cves", [])) or "--"

        row_vals = [
            pkg.get("name", ""),
            pkg.get("version", ""),
            pkg_type,
            parent,
            pkg.get("cve") or "--",
            (f"{float(pkg['cvss']):.1f}" if pkg.get("cvss") not in (None, "--", "N/A") else "--"),
            epss_s,
            sev,
            "Yes" if pkg.get("reachable") else "No",
            pkg.get("fixed_in") or "--",
            additional_cve,
            pkg.get("nvd") or "--",
        ]
        for j, val in enumerate(row_vals, 1):
            cell = ws.cell(row=i, column=j, value=val)
            cell.border    = _bdr()
            cell.font      = Font(name="Calibri", size=9, color=C_BLK)
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
            if j == 8:   # Severity
                cell.fill = SEV_FILL.get(sev, _fill(bg))
                cell.font = SEV_FONT.get(sev, _font(color=C_BLK))
                cell.alignment = _ctr()
            elif j == 9:  # Reachable
                cell.fill = _fill("FFE5E5") if val == "Yes" else _fill(bg)
                cell.alignment = _ctr()
            else:
                cell.fill = _fill(bg)
        ws.row_dimensions[i].height = 22


# ── Sheet 4: Attack Paths ─────────────────────────────────────────────────────
def _attack_paths(ws, payload):
    ws.title = "Attack Paths"
    headers = [
        "#", "Attack Path", "Severity", "Risk Score",
        "Entry Point", "Exploit", "Pivot", "Impact", "Chains To",
    ]
    widths = [4, 30, 12, 10, 28, 24, 20, 35, 25]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    _title_row(ws, "ATTACK PATH CORRELATION — EXPLOIT CHAINS", len(headers))
    _hdr(ws, 2, headers)
    ws.row_dimensions[2].height = 22
    ws.freeze_panes = "A3"

    paths = payload.get("attack_paths", [])
    if not paths:
        ws.merge_cells(f"A3:{get_column_letter(len(headers))}3")
        c = ws["A3"]; c.value = "No multi-step attack chains detected."
        c.font = _font(color=C_BLK); c.alignment = _lft()
        return

    for i, ap in enumerate(paths, start=3):
        sev    = ap.get("severity", "Medium")
        bg     = C_LBLUE if i % 2 == 0 else C_WHT
        steps  = ap.get("steps", [])
        chains = ", ".join(ap.get("chains_to", []))
        row_vals = [
            i - 2,
            ap.get("title", ""),
            sev,
            ap.get("risk_score", ""),
            steps[0] if len(steps) > 0 else "",
            steps[1] if len(steps) > 1 else "",
            steps[2] if len(steps) > 2 else "",
            steps[3] if len(steps) > 3 else "",
            chains or "--",
        ]
        for j, val in enumerate(row_vals, 1):
            cell = ws.cell(row=i, column=j, value=val)
            cell.border    = _bdr()
            cell.font      = Font(name="Calibri", size=9, color=C_BLK)
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
            if j == 3:
                cell.fill = SEV_FILL.get(sev, _fill(bg))
                cell.font = SEV_FONT.get(sev, _font(color=C_BLK))
                cell.alignment = _ctr()
            else:
                cell.fill = _fill(bg)
        ws.row_dimensions[i].height = 28


# ── Public interface ──────────────────────────────────────────────────────────
def generate_excel_report(payload: dict, output_path: str) -> str:
    wb = Workbook()
    wb.remove(wb.active)
    _summary(wb.create_sheet("Summary"),          payload)
    _findings(wb.create_sheet("Findings"),         payload)
    _sbom(wb.create_sheet("SBOM"),                 payload)
    _attack_paths(wb.create_sheet("Attack Paths"), payload)
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(path))
    return str(path)
