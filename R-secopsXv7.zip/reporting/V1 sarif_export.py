from __future__ import annotations

import json
from pathlib import Path


SARIF_VERSION = "2.1.0"
SARIF_SCHEMA = "https://json.schemastore.org/sarif-2.1.0.json"


def _level(severity: str) -> str:
    sev = str(severity or "").lower()

    if sev == "critical":
        return "error"
    if sev == "high":
        return "error"
    if sev == "medium":
        return "warning"
    if sev == "low":
        return "note"

    return "none"


def _rule_id(finding: dict) -> str:
    return str(
        finding.get("rule_id")
        or finding.get("vuln_type")
        or finding.get("title")
        or "UNKNOWN_RULE"
    )


def _rule_name(finding: dict) -> str:
    return str(finding.get("title") or _rule_id(finding))


def _description(finding: dict) -> str:
    return str(
        finding.get("description")
        or finding.get("business_impact")
        or finding.get("vuln_type")
        or ""
    )


def _help_text(finding: dict) -> str:
    remediation = finding.get("remediation", "")

    if isinstance(remediation, list):
        remediation = "\n".join(f"- {x}" for x in remediation)

    parts = []

    if finding.get("cwe"):
        parts.append(f"CWE: {finding.get('cwe')}")

    if finding.get("owasp"):
        parts.append(f"OWASP: {finding.get('owasp')}")

    if finding.get("taint_path"):
        parts.append(f"Taint path: {finding.get('taint_path')}")

    if remediation:
        parts.append(f"Remediation:\n{remediation}")

    return "\n\n".join(parts)


def _artifact_uri(finding: dict) -> str:
    return str(
        finding.get("file")
        or finding.get("file_path")
        or finding.get("full_path")
        or "unknown"
    ).replace("\\", "/")


def _line(finding: dict) -> int:
    try:
        return max(int(finding.get("line") or 1), 1)
    except Exception:
        return 1


def _message(finding: dict) -> str:
    title = finding.get("title") or _rule_id(finding)
    snippet = finding.get("snippet") or ""

    if snippet:
        return f"{title}: {snippet}"

    return str(title)


def _build_rules(findings: list[dict]) -> list[dict]:
    seen = {}
    rules = []

    for finding in findings:
        rid = _rule_id(finding)

        if rid in seen:
            continue

        seen[rid] = True

        rules.append(
            {
                "id": rid,
                "name": _rule_name(finding),
                "shortDescription": {
                    "text": _rule_name(finding)
                },
                "fullDescription": {
                    "text": _description(finding)
                },
                "help": {
                    "text": _help_text(finding),
                    "markdown": _help_text(finding),
                },
                "properties": {
                    "severity": finding.get("severity"),
                    "priority": finding.get("priority"),
                    "confidence": finding.get("confidence"),
                    "vuln_type": finding.get("vuln_type"),
                    "cwe": finding.get("cwe"),
                    "owasp": finding.get("owasp"),
                },
            }
        )

    return rules


def _build_results(findings: list[dict]) -> list[dict]:
    results = []

    for finding in findings:
        results.append(
            {
                "ruleId": _rule_id(finding),
                "level": _level(finding.get("severity")),
                "message": {
                    "text": _message(finding)
                },
                "locations": [
                    {
                        "physicalLocation": {
                            "artifactLocation": {
                                "uri": _artifact_uri(finding)
                            },
                            "region": {
                                "startLine": _line(finding)
                            },
                        }
                    }
                ],
                "properties": {
                    "severity": finding.get("severity"),
                    "priority": finding.get("priority"),
                    "confidence": finding.get("confidence"),
                    "vuln_type": finding.get("vuln_type"),
                    "issue_group": finding.get("issue_group"),
                    "taint_path": finding.get("taint_path"),
                    "framework_mappings": finding.get("framework_mappings"),
                    "secret_category": finding.get("secret_category"),
                    "secret_provider": finding.get("secret_provider"),
                    "blast_radius": finding.get("blast_radius"),
                },
            }
        )

    return results


def build_sarif(payload: dict) -> dict:
    findings = payload.get("findings", []) or []
    metadata = payload.get("metadata", {}) or {}

    return {
        "$schema": SARIF_SCHEMA,
        "version": SARIF_VERSION,
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "R-SecOpsX",
                        "informationUri": "https://r-secopsx.local",
                        "semanticVersion": "2.0.0",
                        "rules": _build_rules(findings),
                    }
                },
                "automationDetails": {
                    "id": "rsecopsx-sast-scan"
                },
                "invocations": [
                    {
                        "executionSuccessful": True,
                        "properties": {
                            "total_findings": metadata.get("total_findings"),
                            "risk_score": metadata.get("risk_score"),
                            "executive_decision": metadata.get("executive_decision"),
                            "framework_mapping_status": metadata.get(
                                "framework_mapping_status"
                            ),
                        },
                    }
                ],
                "results": _build_results(findings),
                "properties": {
                    "tool": "R-SecOpsX",
                    "report_type": "SARIF",
                    "governance_signals": payload.get("governance_signal_summary"),
                    "executive_decision": payload.get("executive_decision"),
                    "vulnerability_age_summary": payload.get(
                        "vulnerability_age_summary"
                    ),
                    "secret_intelligence_summary": payload.get(
                        "secret_intelligence_summary"
                    ),
                },
            }
        ],
    }


def write_sarif_report(payload: dict, output_path: str) -> str:
    sarif = build_sarif(payload)

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    with out.open("w", encoding="utf-8") as f:
        json.dump(sarif, f, indent=2, default=str)

    return str(out)


if __name__ == "__main__":
    sample_payload = {
        "metadata": {
            "total_findings": 1,
            "risk_score": 80,
            "executive_decision": "DO_NOT_RELEASE",
        },
        "findings": [
            {
                "rule_id": "TAINT_COMMAND_INJECTION",
                "title": "Command Injection",
                "severity": "Critical",
                "priority": "P1",
                "confidence": "High",
                "vuln_type": "command_injection",
                "file": "app.py",
                "line": 10,
                "snippet": "subprocess.run(cmd, shell=True)",
                "taint_path": "request.args.get('cmd') -> cmd -> subprocess.run",
                "cwe": "CWE-78",
                "owasp": "A03:2021 - Injection",
                "remediation": [
                    "Use subprocess with list arguments.",
                    "Set shell=False.",
                ],
            }
        ],
    }

    write_sarif_report(sample_payload, "reports/Security_Report.sarif")
    print("SARIF written to reports/Security_Report.sarif")