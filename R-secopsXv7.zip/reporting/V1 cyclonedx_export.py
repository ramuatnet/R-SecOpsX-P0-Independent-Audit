from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path


CYCLONEDX_VERSION = "1.5"


def _bom_ref(pkg: dict) -> str:
    name = str(pkg.get("name") or "unknown")
    version = str(pkg.get("version") or "unknown")
    return f"pkg:{name}@{version}".replace(" ", "_")


def _purl(pkg: dict) -> str | None:
    ecosystem = str(pkg.get("ecosystem") or "").lower()
    name = pkg.get("name")
    version = pkg.get("version")

    if not name:
        return None

    purl_type = {
        "pypi": "pypi",
        "npm": "npm",
        "maven": "maven",
        "go": "golang",
        "cargo": "cargo",
        "nuget": "nuget",
        "composer": "composer",
        "gem": "gem",
    }.get(ecosystem)

    if not purl_type:
        return None

    if version:
        return f"pkg:{purl_type}/{name}@{version}"

    return f"pkg:{purl_type}/{name}"


def _license(pkg: dict) -> list[dict]:
    lic = pkg.get("license")

    if not lic or str(lic).lower() in {"unknown", "none", "null"}:
        return []

    return [{"license": {"id": str(lic)}}]


def _component(pkg: dict) -> dict:
    comp = {
        "type": "library",
        "bom-ref": _bom_ref(pkg),
        "name": str(pkg.get("name") or "unknown"),
        "version": str(pkg.get("version") or "unknown"),
        "scope": "required",
        "properties": [
            {"name": "rsecopsx:ecosystem", "value": str(pkg.get("ecosystem") or "")},
            {"name": "rsecopsx:dependency_type", "value": str(pkg.get("dependency_type") or "")},
            {"name": "rsecopsx:reachability_status", "value": str(pkg.get("reachability_status") or "")},
            {"name": "rsecopsx:reachability_priority", "value": str(pkg.get("reachability_priority") or "")},
            {"name": "rsecopsx:vulnerability_age_bucket", "value": str(pkg.get("vulnerability_age_bucket") or "")},
            {"name": "rsecopsx:patch_urgency", "value": str(pkg.get("patch_urgency") or "")},
        ],
    }

    purl = _purl(pkg)
    if purl:
        comp["purl"] = purl

    licenses = _license(pkg)
    if licenses:
        comp["licenses"] = licenses

    return comp


def _vulnerability_id(pkg: dict) -> str | None:
    return pkg.get("cve") or pkg.get("advisory_id") or pkg.get("primary_vulnerability_id")


def _vulnerability_source(pkg: dict) -> dict:
    vuln_id = _vulnerability_id(pkg) or ""

    if vuln_id.startswith("CVE-"):
        return {"name": "NVD", "url": f"https://nvd.nist.gov/vuln/detail/{vuln_id}"}

    if vuln_id.startswith("GHSA-"):
        return {"name": "GitHub Security Advisory"}

    return {"name": "R-SecOpsX"}


def _severity(pkg: dict) -> str:
    sev = str(pkg.get("severity") or pkg.get("cvss_severity") or "").lower()

    if sev in {"critical", "high", "medium", "low"}:
        return sev

    return "unknown"


def _vulnerability(pkg: dict) -> dict | None:
    vuln_id = _vulnerability_id(pkg)

    if not vuln_id:
        return None

    vuln = {
        "id": str(vuln_id),
        "source": _vulnerability_source(pkg),
        "ratings": [
            {
                "severity": _severity(pkg),
                "method": "other",
            }
        ],
        "affects": [
            {
                "ref": _bom_ref(pkg)
            }
        ],
        "properties": [
            {"name": "rsecopsx:cve", "value": str(pkg.get("cve") or "")},
            {"name": "rsecopsx:advisory_id", "value": str(pkg.get("advisory_id") or "")},
            {"name": "rsecopsx:kev_status", "value": str(pkg.get("kev_status") or False)},
            {"name": "rsecopsx:actively_exploited", "value": str(pkg.get("actively_exploited") or False)},
            {"name": "rsecopsx:outbreak_status", "value": str(pkg.get("outbreak_status") or "")},
            {"name": "rsecopsx:patch_urgency", "value": str(pkg.get("patch_urgency") or "")},
            {"name": "rsecopsx:reachability_status", "value": str(pkg.get("reachability_status") or "")},
            {"name": "rsecopsx:reachability_priority", "value": str(pkg.get("reachability_priority") or "")},
        ],
    }

    if pkg.get("description"):
        vuln["description"] = str(pkg.get("description"))

    if pkg.get("cvss"):
        vuln["ratings"][0]["score"] = pkg.get("cvss")

    if pkg.get("published_date"):
        vuln["published"] = str(pkg.get("published_date"))

    return vuln


def build_cyclonedx(payload: dict) -> dict:
    sbom = payload.get("sbom", []) or []
    metadata = payload.get("metadata", {}) or {}

    components = [_component(pkg) for pkg in sbom]
    vulnerabilities = [
        vuln for vuln in (_vulnerability(pkg) for pkg in sbom) if vuln
    ]

    return {
        "bomFormat": "CycloneDX",
        "specVersion": CYCLONEDX_VERSION,
        "serialNumber": f"urn:uuid:{uuid.uuid4()}",
        "version": 1,
        "metadata": {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "tools": [
                {
                    "vendor": "R-SecOpsX",
                    "name": "R-SecOpsX SAST",
                    "version": "2.0.0",
                }
            ],
            "properties": [
                {"name": "rsecopsx:total_findings", "value": str(metadata.get("total_findings", ""))},
                {"name": "rsecopsx:risk_score", "value": str(metadata.get("risk_score", ""))},
                {"name": "rsecopsx:executive_decision", "value": str(metadata.get("executive_decision", ""))},
                {"name": "rsecopsx:framework_mapping_status", "value": str(metadata.get("framework_mapping_status", ""))},
                {"name": "rsecopsx:vulnerability_age_status", "value": str(metadata.get("vulnerability_age_status", ""))},
            ],
        },
        "components": components,
        "vulnerabilities": vulnerabilities,
        "properties": [
            {
                "name": "rsecopsx:secret_intelligence_summary",
                "value": json.dumps(payload.get("secret_intelligence_summary", {}), default=str),
            },
            {
                "name": "rsecopsx:vulnerability_age_summary",
                "value": json.dumps(payload.get("vulnerability_age_summary", {}), default=str),
            },
            {
                "name": "rsecopsx:governance_signal_summary",
                "value": json.dumps(payload.get("governance_signal_summary", {}), default=str),
            },
            {
                "name": "rsecopsx:executive_decision",
                "value": json.dumps(payload.get("executive_decision", {}), default=str),
            },
        ],
    }


def write_cyclonedx_report(payload: dict, output_path: str) -> str:
    bom = build_cyclonedx(payload)

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    with out.open("w", encoding="utf-8") as f:
        json.dump(bom, f, indent=2, default=str)

    return str(out)


if __name__ == "__main__":
    sample_payload = {
        "metadata": {
            "total_findings": 10,
            "risk_score": 78.2,
            "executive_decision": "REMEDIATE_BEFORE_RELEASE",
            "framework_mapping_status": "RULE_BASED_FRAMEWORK_ENRICHMENT_V1",
            "vulnerability_age_status": "VULNERABILITY_AGE_INTELLIGENCE_V1_OFFLINE",
        },
        "sbom": [
            {
                "name": "log4j-core",
                "version": "2.14.1",
                "ecosystem": "maven",
                "dependency_type": "Direct",
                "license": "Apache-2.0",
                "cve": "CVE-2021-44228",
                "advisory_id": "GHSA-jfh8-c2jp-5v3q",
                "severity": "Critical",
                "reachability_status": "REACHABLE",
                "reachability_priority": "REACHABLE_VULNERABLE",
                "vulnerability_age_bucket": "LEGACY_HIGH_RISK",
                "kev_status": True,
                "actively_exploited": True,
                "outbreak_status": "OUTBREAK_ACTIVE_REACHABLE",
                "patch_urgency": "IMMEDIATE",
                "published_date": "2021-12-10T00:00:00Z",
            }
        ],
        "secret_intelligence_summary": {},
        "vulnerability_age_summary": {},
        "governance_signal_summary": {},
        "executive_decision": {},
    }

    write_cyclonedx_report(sample_payload, "reports/bom.cyclonedx.json")
    print("CycloneDX written to reports/bom.cyclonedx.json")