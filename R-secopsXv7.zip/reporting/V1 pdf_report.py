"""
reporting/pdf_report.py  v2
Big4-style PDF with:
  - Redesigned navy/gold cover (logo support)
  - Full compliance table (PCI DSS, NIST, ISO 27001, SOC2)
  - Attack path section with chain diagrams
  - Per-finding risk score + affected files
  - Enhanced SBOM with EPSS + reachability
"""
from __future__ import annotations

import io, os
from datetime import datetime
from core.config import TOOL_NAME, TOOL_FULL, CLASSIFICATION
from pathlib import Path

os.environ.setdefault("MPLBACKEND","Agg")
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (
    BaseDocTemplate, Frame, PageTemplate, NextPageTemplate,
    Paragraph, Spacer, Table, TableStyle, PageBreak,
    HRFlowable, Image, KeepTogether,
)

NAVY       = colors.HexColor("#0D1B2A")
DARK_BLUE  = colors.HexColor("#1B3A5C")
MID_BLUE   = colors.HexColor("#2563A8")
ELECTRIC   = colors.HexColor("#00A8E8")
GOLD       = colors.HexColor("#C9A84C")
LIGHT_BLUE = colors.HexColor("#D6E8F7")
RED        = colors.HexColor("#C0392B")
ORANGE     = colors.HexColor("#E67E22")
YELLOW     = colors.HexColor("#F1C40F")
GREEN      = colors.HexColor("#27AE60")
GREY_LIGHT = colors.HexColor("#F4F6F8")
GREY_MED   = colors.HexColor("#D5D8DC")
WHITE      = colors.white
BLACK      = colors.HexColor("#1A1A2E")
PAGE_W, PAGE_H = A4
MARGIN = 1.8*cm
SEV_C  = {"Critical":RED,"High":ORANGE,"Medium":YELLOW,"Low":GREEN,
           "Info":colors.HexColor("#7F8C8D")}


def _s(n,**k): return ParagraphStyle(name=n,**k)

S = {
    "SectionTitle":_s("SectionTitle",fontName="Helvetica-Bold",fontSize=14,
                       textColor=DARK_BLUE,spaceBefore=14,spaceAfter=6,leading=18),
    "SubTitle":    _s("SubTitle",fontName="Helvetica-Bold",fontSize=11,
                       textColor=MID_BLUE,spaceBefore=8,spaceAfter=4,leading=14),
    "Body":        _s("Body",fontName="Helvetica",fontSize=9,textColor=BLACK,
                       alignment=TA_JUSTIFY,spaceAfter=4,leading=13),
    "BodySmall":   _s("BodySmall",fontName="Helvetica",fontSize=8,
                       textColor=BLACK,spaceAfter=2,leading=11),
    "Bullet":      _s("Bullet",fontName="Helvetica",fontSize=9,textColor=BLACK,
                       leftIndent=14,spaceAfter=3,leading=13),
    "Code":        _s("Code",fontName="Courier",fontSize=8,
                       textColor=colors.HexColor("#1a1a2e"),
                       backColor=GREY_LIGHT,spaceAfter=4,leading=11,
                       borderPad=4,leftIndent=8),
    "TH":          _s("TH",fontName="Helvetica-Bold",fontSize=8,
                       textColor=WHITE,alignment=TA_CENTER),
    "TD":          _s("TD",fontName="Helvetica",fontSize=8,
                       textColor=BLACK,alignment=TA_LEFT,leading=11),
    "TDC":         _s("TDC",fontName="Helvetica",fontSize=8,
                       textColor=BLACK,alignment=TA_CENTER,leading=11),
    "TDSm":        _s("TDSm",fontName="Helvetica",fontSize=7,
                       textColor=BLACK,alignment=TA_LEFT,leading=10),
    "AF":          _s("AF",fontName="Courier",fontSize=7,
                       textColor=MID_BLUE,leading=10,spaceAfter=1),
    "Chain":       _s("Chain",fontName="Helvetica",fontSize=8,
                       textColor=DARK_BLUE,leading=12),
}

# ── Charts ────────────────────────────────────────────────────────────────────

def _pie(dist):
    cmap={"Critical":"#C0392B","High":"#E67E22","Medium":"#F1C40F",
          "Low":"#27AE60","Info":"#7F8C8D"}
    sizes,labels,clrs=[],[],[]
    for sev in ["Critical","High","Medium","Low","Info"]:
        n=dist.get(sev,0)
        if n:
            labels.append(f"{sev}\n({n})"); sizes.append(n); clrs.append(cmap[sev])
    if not sizes:
        sizes,labels,clrs=[1],["No Findings"],["#27AE60"]
    fig,ax=plt.subplots(figsize=(4.5,3.2),dpi=130)
    _,_,auts=ax.pie(sizes,labels=labels,colors=clrs,autopct="%1.0f%%",startangle=140,
                    wedgeprops=dict(width=0.55,edgecolor="white",linewidth=1.5),
                    textprops={"fontsize":7})
    for a in auts: a.set_fontsize(6);a.set_color("white");a.set_fontweight("bold")
    ax.set_title("Severity Distribution",fontsize=9,fontweight="bold",color="#0D1B2A",pad=10)
    fig.patch.set_facecolor("#F4F6F8"); ax.set_facecolor("#F4F6F8")
    buf=io.BytesIO(); plt.savefig(buf,format="png",bbox_inches="tight",facecolor="#F4F6F8")
    plt.close(fig); buf.seek(0); return buf.read()


def _bar(dist):
    sevs=["Critical","High","Medium","Low","Info"]
    cnts=[dist.get(s,0) for s in sevs]
    clrs=["#C0392B","#E67E22","#F1C40F","#27AE60","#7F8C8D"]
    fig,ax=plt.subplots(figsize=(5.5,2.8),dpi=130)
    bars=ax.bar(sevs,cnts,color=clrs,edgecolor="white",linewidth=0.8,width=0.55)
    for bar,cnt in zip(bars,cnts):
        if cnt:
            ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()+0.05,
                    str(cnt),ha="center",va="bottom",fontsize=9,fontweight="bold",color="#0D1B2A")
    ax.set_ylabel("Count",fontsize=8,color="#0D1B2A")
    ax.set_title("Findings by Severity",fontsize=9,fontweight="bold",color="#0D1B2A")
    ax.tick_params(axis="both",labelsize=7)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
    ax.set_facecolor("#F4F6F8"); fig.patch.set_facecolor("#F4F6F8")
    ax.yaxis.grid(True,alpha=0.4,linestyle="--"); ax.set_axisbelow(True)
    buf=io.BytesIO(); plt.savefig(buf,format="png",bbox_inches="tight",facecolor="#F4F6F8")
    plt.close(fig); buf.seek(0); return buf.read()

# ── Page template ─────────────────────────────────────────────────────────────

# ── PATCH 8: Section-aware page header ────────────────────────────────────────
# Each PageTemplate can carry a custom section label for the running header.
_CURRENT_SECTION = {"label": ""}  # mutable container updated per-section


class _SectionTemplate(PageTemplate):
    """PageTemplate that stamps the current section name into the header."""
    def __init__(self, section_label, *args, **kwargs):
        self.section_label = section_label
        super().__init__(*args, **kwargs)

    def beforeDrawPage(self, canvas, doc):
        _CURRENT_SECTION["label"] = self.section_label


class _Doc(BaseDocTemplate):
    def __init__(self, filename, **kw):
        super().__init__(filename, pagesize=A4, **kw)
        content = Frame(MARGIN, MARGIN+1.2*cm, PAGE_W-2*MARGIN,
                        PAGE_H-2*MARGIN-2.2*cm, id="content")
        cover   = Frame(0, 0, PAGE_W, PAGE_H, id="cover")
        self.addPageTemplates([
            PageTemplate(id="Cover",   frames=[cover],   onPage=_noop),
            # PATCH 8: one template per major section for dynamic header labels
            _SectionTemplate("Executive Summary",
                id="ExecSummary",   frames=[content], onPage=_hf),
            _SectionTemplate("Top Root Causes",
                id="TopCauses",     frames=[content], onPage=_hf),
            _SectionTemplate("Compliance Mapping",
                id="Compliance",    frames=[content], onPage=_hf),
            _SectionTemplate("Attack Path Correlation",
                id="AttackPaths",   frames=[content], onPage=_hf),
            _SectionTemplate("Detailed Findings",
                id="Findings",      frames=[content], onPage=_hf),
            _SectionTemplate("SBOM & Dependencies",
                id="SBOM",          frames=[content], onPage=_hf),
            _SectionTemplate("Conclusion",
                id="Conclusion",    frames=[content], onPage=_hf),
            # Generic fallback
            _SectionTemplate("Security Assessment Report",
                id="Content",       frames=[content], onPage=_hf),
        ])
        # PATCH 9: enable automatic page number tracking for ToC
        self._page_map: dict[str, int] = {}

    def afterFlowable(self, flowable):
        """Record section → page number for Table of Contents."""
        if hasattr(flowable, "_toc_bookmark"):
            self._page_map[flowable._toc_bookmark] = self.page


def _noop(c, d): pass


def _hf(canvas, doc):
    """PATCH 7+8+10: header with section name + footer with confidential notice."""
    canvas.saveState()
    w, h = A4
    section = _CURRENT_SECTION.get("label", "")
    tool    = TOOL_FULL

    # ── Top header bar ──────────────────────────────────────────────────────
    canvas.setFillColor(NAVY)
    canvas.rect(0, h-1.3*cm, w, 1.3*cm, fill=1, stroke=0)
    canvas.setFillColor(GOLD)
    canvas.rect(0, h-1.35*cm, w, 0.05*cm, fill=1, stroke=0)
    canvas.setFillColor(WHITE)
    # Left: "CONFIDENTIAL  |  <Section Name>"
    canvas.setFont("Helvetica-Bold", 7.5)
    canvas.drawString(MARGIN, h-0.58*cm, "CONFIDENTIAL")
    canvas.setFont("Helvetica", 7.5)
    if section:
        canvas.drawString(MARGIN+2.3*cm, h-0.58*cm, f"|  {section}")
    # Right: tool name + page
    canvas.setFont("Helvetica", 7)
    canvas.drawRightString(w-MARGIN, h-0.58*cm,
                           f"Security Assessment Report  |  Page {doc.page}")
    # PATCH 10: thin gold separator
    canvas.setFillColor(GOLD)
    canvas.rect(0, h-1.35*cm, w, 0.04*cm, fill=1, stroke=0)

    # ── Bottom footer bar (PATCH 10) ─────────────────────────────────────────
    canvas.setFillColor(NAVY)
    canvas.rect(0, 0, w, 1.1*cm, fill=1, stroke=0)
    canvas.setFillColor(GOLD)
    canvas.rect(0, 1.05*cm, w, 0.05*cm, fill=1, stroke=0)
    canvas.setFillColor(WHITE)
    canvas.setFont("Helvetica", 7)
    canvas.drawString(MARGIN, 0.38*cm,
                      f"Generated by {TOOL_FULL}  |  "
                      f"{datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
    canvas.drawRightString(w-MARGIN, 0.38*cm, f"Page {doc.page}")
    canvas.restoreState()


# ── PATCH 9: Table of Contents helper ─────────────────────────────────────────

class _TocBookmark(Spacer):
    """Zero-height spacer that records its section name when rendered."""
    def __init__(self, name: str):
        super().__init__(0, 0)
        self._toc_bookmark = name


def _toc_section(payload: dict, page_map: dict | None = None) -> list:
    """
    PATCH 3: Table of Contents with actual page numbers.
    page_map is populated by _Doc.afterFlowable on a first-pass build.
    On first call (page_map=None) page numbers show as "—".
    On second call they are replaced with real page numbers.
    """
    SECTIONS = [
        ("1.", "Executive Summary"),
        ("2.", "Top Root Causes"),
        ("3.", "Compliance Mapping"),
        ("4.", "Attack Path Correlation"),
        ("5.", "Detailed Findings"),
        ("6.", "SBOM & Dependencies"),
        ("7.", "Conclusion & Remediation SLA"),
    ]
    pm = page_map or {}
    story = []
    story.append(Paragraph("Table of Contents", S["SectionTitle"]))
    story.append(HRFlowable(width="100%", thickness=2, color=DARK_BLUE, spaceAfter=8))
    story.append(Spacer(1, 0.3*cm))

    rows = []
    for num, title in SECTIONS:
        page_num = pm.get(title, "—")
        rows.append([
            Paragraph(f"<b>{num}</b>", S["TD"]),
            Paragraph(title, S["TD"]),
            Paragraph("·" * 18, _s(f"Dots{num}",
                fontSize=9, textColor=colors.HexColor("#AAAAAA"),
                alignment=TA_CENTER, fontName="Helvetica")),
            Paragraph(f"<b>{page_num}</b>", _s(f"PgN{num}",
                fontSize=9, alignment=TA_CENTER, fontName="Helvetica-Bold",
                textColor=DARK_BLUE)),
        ])
    t = Table(rows, colWidths=[1.2*cm, 12*cm, 3*cm, 1.5*cm])
    t.setStyle(TableStyle([
        ("FONTSIZE",     (0,0), (-1,-1), 10),
        ("TOPPADDING",   (0,0), (-1,-1), 7),
        ("BOTTOMPADDING",(0,0), (-1,-1), 7),
        ("LINEBELOW",    (0,0), (-1,-1), 0.3, colors.HexColor("#E0E0E0")),
        ("TEXTCOLOR",    (0,0), (0,-1), DARK_BLUE),
        ("FONTNAME",     (0,0), (0,-1), "Helvetica-Bold"),
        ("BACKGROUND",   (0,0), (-1,-1), colors.HexColor("#FAFAFA")),
        ("ROWBACKGROUNDS",(0,0),(-1,-1),[WHITE, colors.HexColor("#F4F6F8")]),
    ]))
    story.append(t)
    story.append(Spacer(1, 0.3*cm))
    return story


# ── Cover page ────────────────────────────────────────────────────────────────

def _navy(tbl): # wrap table in full-width navy background
    t=Table([[tbl]],colWidths=[PAGE_W])
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),NAVY),
                            ("LEFTPADDING",(0,0),(-1,-1),1.5*cm),
                            ("RIGHTPADDING",(0,0),(-1,-1),1.5*cm),
                            ("TOPPADDING",(0,0),(-1,-1),0),
                            ("BOTTOMPADDING",(0,0),(-1,-1),0)]))
    return t

def _navy_para(text,style):
    t=Table([[Paragraph(text,style)]],colWidths=[PAGE_W])
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),NAVY),
                            ("TOPPADDING",(0,0),(-1,-1),2),
                            ("BOTTOMPADDING",(0,0),(-1,-1),2)]))
    return t

def _navy_space(h):
    t=Table([[""]],colWidths=[PAGE_W],rowHeights=[h])
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),NAVY)])); return t

def _gold_rule():
    t=Table([[""]],colWidths=[PAGE_W],rowHeights=[0.12*cm])
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),GOLD)])); return t

def _cover(payload, logo_path=None):
    meta   = payload.get("metadata",{})
    target = Path(meta.get("target","Unknown")).name or meta.get("target","Unknown")
    dist   = meta.get("severity_distribution",{})
    risk   = meta.get("risk_score",0)
    total  = meta.get("total_findings",0)
    story  = []

    # Logo
    if logo_path and Path(logo_path).exists():
        try:
            logo_img=Image(logo_path,width=5*cm,height=2*cm,kind="proportional")
            lt=Table([[logo_img]],colWidths=[PAGE_W])
            lt.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),NAVY),
                                    ("ALIGN",(0,0),(-1,-1),"LEFT"),
                                    ("LEFTPADDING",(0,0),(-1,-1),1.8*cm),
                                    ("TOPPADDING",(0,0),(-1,-1),1.2*cm),
                                    ("BOTTOMPADDING",(0,0),(-1,-1),0)]))
            story.append(lt)
        except Exception:
            story.append(_navy_space(2.5*cm))
    else:
        story.append(_navy_space(2.5*cm))

    story.append(_navy_para(TOOL_NAME,_s("T1",fontName="Helvetica",fontSize=13,
                             textColor=ELECTRIC,alignment=TA_CENTER,spaceAfter=0,leading=16)))
    story.append(_gold_rule())
    story.append(Spacer(1,0.4*cm))
    story.append(_navy_para("SECURITY ASSESSMENT REPORT",_s("T2",fontName="Helvetica-Bold",
                             fontSize=30,textColor=WHITE,alignment=TA_CENTER,spaceAfter=4,leading=36)))
    story.append(_navy_para("Static Application Security Testing  (SAST)",_s("T3",
                             fontName="Helvetica",fontSize=13,textColor=ELECTRIC,
                             alignment=TA_CENTER,spaceAfter=0,leading=16)))
    story.append(Spacer(1,0.5*cm))
    story.append(_gold_rule())
    story.append(Spacer(1,0.8*cm))

    sast_count = meta.get("sast_findings", total)
    sca_count  = meta.get("sca_findings",  0)
    findings_label = (f"{total}  (SAST: {sast_count} + SCA: {sca_count})"
                      if sca_count > 0 else str(total))

    info=Table([["Target System",target],["Scan Date",meta.get("scan_date","")[:10]],
                ["Classification","CONFIDENTIAL"],
                ["Total Findings",findings_label],["Risk Score",f"{risk} / 100"]],
               colWidths=[6*cm,10*cm])
    info.setStyle(TableStyle([
        ("FONTNAME",(0,0),(-1,-1),"Helvetica"),("FONTSIZE",(0,0),(-1,-1),10),
        ("TEXTCOLOR",(0,0),(0,-1),ELECTRIC),("TEXTCOLOR",(1,0),(1,-1),WHITE),
        ("FONTNAME",(0,0),(0,-1),"Helvetica-Bold"),
        ("ALIGN",(0,0),(0,-1),"RIGHT"),("ALIGN",(1,0),(1,-1),"LEFT"),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
        ("BACKGROUND",(0,0),(-1,-1),NAVY),
    ]))
    story.append(_navy(info))
    story.append(Spacer(1,0.8*cm))

    pill_data,pill_c=[],[]
    for sev,col in [("Critical",RED),("High",ORANGE),("Medium",YELLOW),("Low",GREEN)]:
        cnt=dist.get(sev,0)
        pill_data.append(Paragraph(f"<b>{sev}</b><br/>{cnt}",
            _s(f"P{sev}",fontName="Helvetica-Bold",fontSize=9,
               textColor=WHITE if sev!="Medium" else BLACK,
               alignment=TA_CENTER,leading=13)))
        pill_c.append(col)
    pt=Table([pill_data],colWidths=[4.2*cm]*4)
    cmds=[("ALIGN",(0,0),(-1,-1),"CENTER"),("VALIGN",(0,0),(-1,-1),"MIDDLE"),
          ("TOPPADDING",(0,0),(-1,-1),8),("BOTTOMPADDING",(0,0),(-1,-1),8),
          ("BACKGROUND",(0,0),(-1,-1),NAVY)]
    for i,c in enumerate(pill_c):
        cmds.append(("BACKGROUND",(i,0),(i,0),c))
    pt.setStyle(TableStyle(cmds))
    story.append(_navy(pt))

    story.append(Spacer(1,1.2*cm))
    story.append(_navy_para(
        "This report contains confidential security findings. "
        "Distribution is restricted to authorized personnel only.",
        _s("Disc",fontName="Helvetica-Oblique",fontSize=8,
           textColor=colors.HexColor("#7B93A8"),alignment=TA_CENTER,leading=12)))
    story.append(NextPageTemplate("Content"))
    story.append(PageBreak())
    return story

# ── Section helper ─────────────────────────────────────────────────────────────

def _sec(title,level=1):
    return [HRFlowable(width="100%",thickness=2 if level==1 else 0.5,
                       color=DARK_BLUE if level==1 else MID_BLUE,spaceAfter=4),
            Paragraph(title,S["SectionTitle"] if level==1 else S["SubTitle"])]

# ── Top Root Causes ──────────────────────────────────────────────────────────────

def _top_root_causes_section(payload):
    """
    'Top Root Causes to Fix First' — ranked by total occurrence count.
    Shows the N vulnerabilities whose fix will eliminate the most instances.
    """
    top = payload.get("top_root_causes", [])
    if not top:
        return []

    story = _sec("Top Root Causes to Fix First")
    story.append(Paragraph(
        "The following vulnerabilities appear most frequently across the codebase. "
        "Fixing the root cause in shared code eliminates all occurrences at once — "
        "highest remediation leverage.",
        S["Body"]
    ))
    story.append(Spacer(1, 0.3*cm))

    SEV_BG = {"Critical": RED, "High": ORANGE, "Medium": YELLOW,
              "Low": GREEN, "Info": colors.HexColor("#7F8C8D")}
    SEV_FG = {"Critical": WHITE, "High": WHITE, "Medium": BLACK,
              "Low": WHITE,     "Info": WHITE}

    rows = [[Paragraph(h, S["TH"]) for h in
             ["#", "Vulnerability", "Severity", "Occurrences", "Files Affected", "Risk Score"]]]

    for i, f in enumerate(top, 1):
        sev        = f.get("severity", "Medium")
        instances  = f.get("instances", 1)
        files      = len(f.get("affected_files", [f.get("file","")]))
        risk       = f.get("risk_score", "")
        risk_str   = f"{risk}" if risk else "N/A"

        sev_para = Paragraph(sev, _s(f"SevR{i}", fontName="Helvetica-Bold",
                                      fontSize=8, textColor=SEV_FG.get(sev, WHITE),
                                      alignment=TA_CENTER))
        rows.append([
            Paragraph(str(i),              S["TDC"]),
            Paragraph(f.get("title",""),   S["TD"]),
            sev_para,
            Paragraph(str(instances),      S["TDC"]),
            Paragraph(str(files),          S["TDC"]),
            Paragraph(risk_str,            S["TDC"]),
        ])

    t = Table(rows, colWidths=[1*cm, 7*cm, 2.5*cm, 2.5*cm, 2.5*cm, 1.5*cm])
    cmds = [
        ("BACKGROUND",    (0, 0), (-1, 0), DARK_BLUE),
        ("GRID",          (0, 0), (-1, -1), 0.5, GREY_MED),
        ("ROWBACKGROUNDS",(0, 1), (-1, -1), [WHITE, LIGHT_BLUE]),
        ("TOPPADDING",    (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("FONTSIZE",      (0, 0), (-1, -1), 9),
    ]
    for i, f in enumerate(top, 1):
        sev = f.get("severity", "Medium")
        bg  = SEV_BG.get(sev, GREY_MED)
        cmds.append(("BACKGROUND", (2, i), (2, i), bg))
    t.setStyle(TableStyle(cmds))
    story.append(t)
    story.append(Spacer(1, 0.4*cm))

    # Narrative bullets
    for i, f in enumerate(top, 1):
        instances = f.get("instances", 1)
        files     = len(f.get("affected_files", [f.get("file","")]))
        impact_note = (
            f" ✦ Fixing this root cause eliminates {instances} occurrences across "
            f"{files} file{'s' if files!=1 else ''}."
            if instances > 1 else ""
        )
        story.append(Paragraph(
            f"<b>{i}. {f.get('title','')}:</b> {instances} occurrence"
            f"{'s' if instances != 1 else ''} across {files} file"
            f"{'s' if files != 1 else ''}."
            f"{impact_note}",
            S["Bullet"]
        ))
    story.append(Spacer(1, 0.4*cm))
    return story


# ── Executive summary ──────────────────────────────────────────────────────────

def _exec_summary(payload):
    meta=payload.get("metadata",{}); dist=meta.get("severity_distribution",{})
    risk=meta.get("risk_score",0);   total=meta.get("total_findings",0)
    story=_sec("1. Executive Summary")
    # Issue 7: risk label aligns score with executive recommendation
    risk_label = (
        "CRITICAL — immediate remediation required" if risk >= 80 else
        "HIGH — address before next release"         if risk >= 60 else
        "MEDIUM — schedule remediation"              if risk >= 40 else
        "LOW — monitor and track"
    )
    story.append(Paragraph(
        f"The security assessment of <b>{Path(meta.get('target','')).name or meta.get('target','')}</b> "
        f"identified <b>{total} unique findings</b> (after deduplication). "
        f"Portfolio risk score: <b>{risk}/100 — {risk_label}</b>. "
        f"Each finding is individually scored using a 6-factor enterprise risk model "
        f"(severity, exploitability, data sensitivity, exposure, privilege, business impact).",
        S["Body"]))
    story.append(Spacer(1,0.3*cm))

    slas={"Critical":"< 24 hours","High":"7 days","Medium":"30 days","Low":"90 days","Info":"Next sprint"}
    pris={"Critical":"P1","High":"P2","Medium":"P3","Low":"P4","Info":"P4"}
    bg  ={"Critical":"#C0392B","High":"#E67E22","Medium":"#F1C40F","Low":"#27AE60","Info":"#7F8C8D"}
    rows=[[Paragraph(h,S["TH"]) for h in ["Severity","Count","Priority","SLA"]]]
    for sev in ["Critical","High","Medium","Low","Info"]:
        rows.append([Paragraph(sev,S["TDC"]),Paragraph(str(dist.get(sev,0)),S["TDC"]),
                     Paragraph(pris[sev],S["TDC"]),Paragraph(slas[sev],S["TDC"])])
    t=Table(rows,colWidths=[4*cm,3*cm,3*cm,5*cm])
    cmds=[("BACKGROUND",(0,0),(-1,0),DARK_BLUE),("GRID",(0,0),(-1,-1),0.5,WHITE),
          ("TEXTCOLOR",(0,0),(-1,-1),WHITE),("TOPPADDING",(0,0),(-1,-1),6),
          ("BOTTOMPADDING",(0,0),(-1,-1),6),("FONTSIZE",(0,0),(-1,-1),9)]
    for i,sev in enumerate(["Critical","High","Medium","Low","Info"],1):
        cmds.append(("BACKGROUND",(0,i),(-1,i),colors.HexColor(bg[sev])))
        if sev=="Medium": cmds.append(("TEXTCOLOR",(0,i),(-1,i),BLACK))
    t.setStyle(TableStyle(cmds)); story.append(t); story.append(Spacer(1,0.4*cm))

    pi=Image(io.BytesIO(_pie(dist)),width=7.5*cm,height=5.5*cm)
    bi=Image(io.BytesIO(_bar(dist)),width=9*cm,  height=5.5*cm)
    ct=Table([[pi,bi]],colWidths=[8*cm,10*cm])
    ct.setStyle(TableStyle([("ALIGN",(0,0),(-1,-1),"CENTER"),("VALIGN",(0,0),(-1,-1),"MIDDLE"),
                             ("BACKGROUND",(0,0),(-1,-1),GREY_LIGHT),("BOX",(0,0),(-1,-1),0.5,GREY_MED)]))
    story.append(ct); story.append(Spacer(1,0.4*cm))
    story+=_sec("Key Intelligence Insights",level=2)
    for ins in payload.get("insights",[]):
        # Issue 6: enhance typosquat insight with explanation
        if ins.startswith("DEPENDENCY CONFUSION"):
            ins = ins + (
                " Typosquatted packages are indistinguishable from legitimate ones by name — "
                "they execute malicious code silently on pip/npm install, stealing credentials "
                "or establishing backdoors. Remove immediately and audit install history."
            )
        story.append(Paragraph(f"* {ins}", S["Bullet"]))
    story.append(Spacer(1,0.3*cm))

    # PATCH 14: executive prioritization block
    top_causes = payload.get("top_root_causes", [])
    if top_causes:
        top3_inst  = sum(f.get("instances",1) for f in top_causes[:3])
        total_inst = sum(f.get("instances",1) for f in payload.get("grouped",[]))
        if total_inst > 0:
            pct   = int(100 * top3_inst / total_inst)
            names = ", ".join(f.get("title","")[:28] for f in top_causes[:3])
            prio_tbl = Table([[Paragraph(
                f"<b>&#x26A1; Executive Prioritization:</b> Fixing the top "
                f"{min(3,len(top_causes))} root causes (<i>{names}</i>) eliminates "
                f"<b>{top3_inst} of {total_inst} occurrences (~{pct}% of all findings)</b>. "
                "Remediate these first for maximum risk reduction with minimum effort.",
                S["Body"]
            )]], colWidths=[17*cm])
            prio_tbl.setStyle(TableStyle([
                ("BACKGROUND",    (0,0),(-1,-1), colors.HexColor("#EAF4FB")),
                ("BOX",           (0,0),(-1,-1), 1, MID_BLUE),
                ("TOPPADDING",    (0,0),(-1,-1), 8),
                ("BOTTOMPADDING", (0,0),(-1,-1), 8),
                ("LEFTPADDING",   (0,0),(-1,-1), 10),
            ]))
            story.append(prio_tbl)
    story.append(Spacer(1,0.4*cm))
    return story

# ── Compliance ────────────────────────────────────────────────────────────────

def _compliance(payload):
    story=_sec("2. Compliance Mapping")

    # OWASP
    owasp=payload.get("owasp",{})
    if owasp:
        story+=_sec("OWASP Top 10",level=2)
        rows=[[Paragraph(h,S["TH"]) for h in ["OWASP ID","Category","Findings"]]]
        for oid,info in sorted(owasp.items()):
            rows.append([Paragraph(oid,S["TDC"]),Paragraph(info.get("category",""),S["TD"]),
                         Paragraph(str(info.get("count",0)),S["TDC"])])
        t=Table(rows,colWidths=[3*cm,11*cm,3*cm])
        t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),DARK_BLUE),
                                ("GRID",(0,0),(-1,-1),0.5,GREY_MED),
                                ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,LIGHT_BLUE]),
                                ("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4),
                                ("FONTSIZE",(0,0),(-1,-1),8)]))
        story.append(t); story.append(Spacer(1,0.3*cm))

    # MITRE
    mitre=payload.get("mitre",[])
    if mitre:
        story+=_sec("MITRE ATT&amp;CK",level=2)
        rows=[[Paragraph(h,S["TH"]) for h in ["Technique ID","Description"]]]
        for te in mitre:
            rows.append([Paragraph(te.get("id",""),S["TDC"]),Paragraph(te.get("description",""),S["TD"])])
        t=Table(rows,colWidths=[4*cm,13*cm])
        t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),DARK_BLUE),
                                ("GRID",(0,0),(-1,-1),0.5,GREY_MED),
                                ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,LIGHT_BLUE]),
                                ("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4),
                                ("FONTSIZE",(0,0),(-1,-1),8)]))
        story.append(t); story.append(Spacer(1,0.3*cm))

    # PATCH 1: force clean page before the wide compliance table
    story.append(PageBreak())
    # PCI DSS + NIST + ISO 27001 + SOC2 consolidated table
    story+=_sec("PCI DSS / NIST / ISO 27001 / SOC 2",level=2)
    seen_types: set = set()
    rows=[[Paragraph(h,S["TH"]) for h in ["Vulnerability","PCI DSS","NIST 800-53","ISO 27001","SOC 2"]]]
    for f in payload.get("grouped",[]):
        vt=f.get("vuln_type","")
        if vt in seen_types: continue
        seen_types.add(vt)
        rows.append([
            Paragraph(f.get("title",""),    S["TDSm"]),
            Paragraph(f.get("pci_dss",""),  S["TDSm"]),
            Paragraph(f.get("nist",""),     S["TDSm"]),
            Paragraph(f.get("iso27001",""), S["TDSm"]),
            Paragraph(f.get("soc2",""),     S["TDSm"]),
        ])
    if len(rows)>1:
        t=Table(rows,colWidths=[4*cm,3.5*cm,3.5*cm,3.5*cm,3.5*cm],
                repeatRows=1)          # repeat header on every page
        t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),DARK_BLUE),
                                ("GRID",(0,0),(-1,-1),0.5,GREY_MED),
                                ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,LIGHT_BLUE]),
                                ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
                                ("FONTSIZE",(0,0),(-1,-1),7)]))
        # KeepTogether wraps the section header + table so they never split at top.
        # repeatRows=1 ensures the column header re-appears if table spans pages.
        story.append(KeepTogether([t]))
    return story

# ── Attack paths ──────────────────────────────────────────────────────────────

def _attack_paths_section(payload):
    story=_sec("3. Attack Path Correlation")
    paths=payload.get("attack_paths",[])
    if not paths:
        story.append(Paragraph("No multi-step attack chains detected.",S["Body"]))
        return story

    story.append(Paragraph(
        f"The following {len(paths)} attack path"
        f"{'s were' if len(paths)>1 else ' was'} identified by correlating "
        f"vulnerability findings into exploit chains. "
        f"These represent realistic multi-step scenarios an attacker could execute.",
        S["Body"]))
    story.append(Spacer(1,0.3*cm))

    for i,ap in enumerate(paths,1):
        sev=ap.get("severity","Medium"); sc=SEV_C.get(sev,GREY_MED)
        steps=ap.get("steps",[])
        chains=ap.get("chains_to",[])
        evidence_type = ap.get("evidence_type", "pattern-detected")
        evidence_note = ap.get("evidence_note", "")
        ev_color = "#E9F7EF" if evidence_type == "taint-confirmed" else "#FFF8E7"
        ev_border = colors.HexColor("#27AE60") if evidence_type == "taint-confirmed" else GOLD
        ev_label  = (
            "<b>TAINT-VALIDATED</b> — Data flow confirmed by AST taint analysis."
            if evidence_type == "taint-confirmed"
            else "<b>PATTERN-ONLY</b> — Likely exploitable. <i>Action: Manual validation required before fix — confirm user input reaches this sink.</i>"
        )

        hdr=Table([[Paragraph(f"Chain #{i:02d}",S["TH"]),
                    Paragraph(ap.get("title",""),S["TH"]),
                    Paragraph(sev.upper(),S["TH"]),
                    Paragraph(f"Risk: {ap.get('risk_score',0)}",S["TH"])]],
                  colWidths=[2.5*cm,9*cm,2.5*cm,3*cm])
        hdr.setStyle(TableStyle([("BACKGROUND",(0,0),(1,0),DARK_BLUE),
                                  ("BACKGROUND",(2,0),(2,0),sc),
                                  ("BACKGROUND",(3,0),(3,0),MID_BLUE),
                                  ("TEXTCOLOR",(0,0),(-1,-1),WHITE),
                                  ("FONTNAME",(0,0),(-1,-1),"Helvetica-Bold"),
                                  ("FONTSIZE",(0,0),(-1,-1),9),
                                  ("ALIGN",(0,0),(-1,-1),"CENTER"),
                                  ("TOPPADDING",(0,0),(-1,-1),5),
                                  ("BOTTOMPADDING",(0,0),(-1,-1),5)]))

        # Step chain arrow row
        arrow="  -->  "
        chain_str=arrow.join(steps)
        chain_tbl=Table([[Paragraph(f"<b>Chain:</b>  {chain_str}",S["Chain"])]],
                        colWidths=[17*cm])
        chain_tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),GREY_LIGHT),
                                        ("TOPPADDING",(0,0),(-1,-1),5),
                                        ("BOTTOMPADDING",(0,0),(-1,-1),5),
                                        ("LEFTPADDING",(0,0),(-1,-1),8),
                                        ("BOX",(0,0),(-1,-1),0.5,GREY_MED)]))

        narr_tbl=Table([[Paragraph("<b>Narrative</b>",S["BodySmall"])],
                        [Paragraph(ap.get("narrative",""),S["Body"])]],
                       colWidths=[17*cm])
        narr_tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),LIGHT_BLUE),
                                       ("BACKGROUND",(0,1),(-1,-1),WHITE),
                                       ("GRID",(0,0),(-1,-1),0.5,GREY_MED),
                                       ("TOPPADDING",(0,0),(-1,-1),4),
                                       ("BOTTOMPADDING",(0,0),(-1,-1),4),
                                       ("LEFTPADDING",(0,0),(-1,-1),6)]))

        chain_note=""
        if chains:
            chain_note=f"<b>Chains to:</b> {', '.join(chains)} — remediate these together."
        note_content = f"{ev_label}  {chain_note}" if chain_note else ev_label
        note_rows=[[Paragraph(note_content, S["BodySmall"])]]
        note_tbl=Table(note_rows,colWidths=[17*cm])
        note_tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),colors.HexColor(ev_color)),
                                       ("BOX",(0,0),(-1,-1),0.5,ev_border),
                                       ("TOPPADDING",(0,0),(-1,-1),4),
                                       ("BOTTOMPADDING",(0,0),(-1,-1),4),
                                       ("LEFTPADDING",(0,0),(-1,-1),6)]))

        story.append(KeepTogether([hdr,chain_tbl,narr_tbl,note_tbl,Spacer(1,0.4*cm)]))
    return story

# ── Findings ──────────────────────────────────────────────────────────────────

def _findings_section(payload):
    story=_sec("4. Detailed Findings")
    grouped=payload.get("grouped",[])
    if not grouped:
        story.append(Paragraph("No findings detected.",S["Body"])); return story

    for idx,f in enumerate(grouped,1):
        sev=f.get("severity","Medium"); sc=SEV_C.get(sev,GREY_MED)
        instances=f.get("instances",1)
        affected =f.get("affected_files",[f.get("file","")])

        hdr=Table([[Paragraph(f"#{idx:02d}",S["TH"]),
                    Paragraph(f.get("title","Unknown"),S["TH"]),
                    Paragraph(sev.upper(),S["TH"]),
                    Paragraph(f.get("priority",""),S["TH"]),
                    Paragraph(f"Risk: {f.get('risk_score','')}",S["TH"])]],
                  colWidths=[1.8*cm,9.2*cm,2.5*cm,2*cm,1.5*cm])
        hdr.setStyle(TableStyle([("BACKGROUND",(0,0),(1,0),DARK_BLUE),
                                  ("BACKGROUND",(2,0),(2,0),sc),
                                  ("BACKGROUND",(3,0),(3,0),MID_BLUE),
                                  ("BACKGROUND",(4,0),(4,0),colors.HexColor("#1B3A5C")),
                                  ("TEXTCOLOR",(0,0),(-1,-1),WHITE),
                                  ("FONTNAME",(0,0),(-1,-1),"Helvetica-Bold"),
                                  ("FONTSIZE",(0,0),(-1,-1),8),
                                  ("ALIGN",(0,0),(-1,-1),"CENTER"),
                                  ("TOPPADDING",(0,0),(-1,-1),5),
                                  ("BOTTOMPADDING",(0,0),(-1,-1),5)]))

        # PATCH 12: clean file path — show only relative tail, not full absolute path
        def _clean_path(fp: str) -> str:
            p = Path(fp)
            # Return last 2 parts of path (folder/file.py) to keep it readable
            parts = p.parts
            if len(parts) >= 2:
                return str(Path(*parts[-2:]))
            return p.name or fp
        pf = _clean_path(affected[0]) if affected else ""

        # PATCH 6: enrich IDOR description with access type context
        desc = f.get("description", "") or f.get("business_impact", "")
        if f.get("vuln_type") == "api_idor":
            snippet_low = (f.get("snippet","") or "").lower()
            idor_type = "Vertical IDOR" if any(
                x in snippet_low for x in ("admin","role","permission","privilege")
            ) else "Horizontal IDOR"
            access = "Write access" if any(
                x in snippet_low for x in ("post","put","delete","update","save","write")
            ) else "Read access"
            desc = (f"[{idor_type} / {access}] Missing authorization validation. "
                    + (desc or "User-controlled ID used in object access without ownership check."))
        exploit_val = f.get("exploitability","")
        exploit_disp = exploit_val.upper() if exploit_val else "N/A"
        # Issue 5: single Detection value, used in both Exploitability and Confidence rows
        det_label = (
            "TAINT-VALIDATED"
            if (f.get("taint_path") and "->" in str(f.get("taint_path","")))
               or f.get("detection") == "TAINT-VALIDATED"
            else ("Regex + Contextual Analysis"
                  if f.get("detection") == "Regex Pattern"
                  else f.get("detection",""))
        )
        meta_rows=[
            ["File",pf,                        "Line",          str(f.get("line",""))],
            ["CWE", f.get("cwe",""),            "OWASP",         f.get("owasp","")],
            ["MITRE",f.get("mitre",""),         "CVE",           f.get("cve") or "N/A"],
            ["PCI DSS",f.get("pci_dss",""),     "NIST",          f.get("nist","")],
            ["ISO 27001",f.get("iso27001",""),  "SOC2",          f.get("soc2","")],
            ["Detection",    det_label,
             "Sink Category", f.get("sink_category","unknown").title().replace("_"," ")],
            ["Confidence",   f.get("confidence_label","") or f.get("confidence",""),
             "Exploitability", exploit_disp],
        ]
        meta_tbl=Table([[Paragraph(c,S["BodySmall"]) for c in row] for row in meta_rows],
                       colWidths=[2*cm,8*cm,2*cm,5*cm])
        meta_tbl.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(0,-1),GREY_LIGHT),("BACKGROUND",(2,0),(2,-1),GREY_LIGHT),
            ("FONTNAME",(0,0),(0,-1),"Helvetica-Bold"),("FONTNAME",(2,0),(2,-1),"Helvetica-Bold"),
            ("GRID",(0,0),(-1,-1),0.5,GREY_MED),("FONTSIZE",(0,0),(-1,-1),7),
            ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3)]))

        af_tbl=None
        if instances>1:
            fl="<br/>".join(f"&nbsp;&nbsp;{i+1}. {_clean_path(fp)}" for i,fp in enumerate(affected))
            af_rows=[[Paragraph(f"<b>Found in {instances} files (consolidated)</b>",S["BodySmall"])],
                     [Paragraph(fl,S["AF"])]]
            af_tbl=Table(af_rows,colWidths=[17*cm])
            af_tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#EBF5FB")),
                                         ("BACKGROUND",(0,1),(-1,-1),colors.HexColor("#F8FBFD")),
                                         ("GRID",(0,0),(-1,-1),0.5,GREY_MED),
                                         ("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4),
                                         ("LEFTPADDING",(0,0),(-1,-1),6)]))

        # Issue 8 FIX: show description only if different from business_impact
        raw_desc   = f.get("description","").strip()
        raw_impact = f.get("business_impact","").strip()
        show_desc  = raw_desc and raw_desc != raw_impact
        desc_rows  = []
        if show_desc:
            desc_rows += [[Paragraph("<b>Description</b>",S["BodySmall"])],
                          [Paragraph(raw_desc, S["Body"])]]
        desc_rows  += [[Paragraph("<b>Business Impact</b>",S["BodySmall"])],
                       [Paragraph(raw_impact or raw_desc, S["Body"])]]
        desc_tbl=Table(desc_rows, colWidths=[17*cm])
        _hdr_rows = [i for i,r in enumerate(desc_rows)
                     if r and hasattr(r[0],"text") and "<b>" in (r[0].text or "")]
        _style8 = [("GRID",(0,0),(-1,-1),0.5,GREY_MED),
                   ("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4),
                   ("LEFTPADDING",(0,0),(-1,-1),6)]
        for _ri in _hdr_rows:
            _style8.append(("BACKGROUND",(0,_ri),(-1,_ri),LIGHT_BLUE))
        desc_tbl.setStyle(TableStyle(_style8))

        snippet = f.get("snippet","").strip()
        # Issue 1 FIX: escape < > so route vars like <user_id> render correctly
        snippet_safe = snippet.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
        ev_rows=[[Paragraph("<b>Code Evidence</b>",S["BodySmall"])],
                 [Paragraph(f"{_clean_path(affected[0]) if affected else ''}:{f.get('line','')}<br/>"
                             f"<font name='Courier' size='8'>{snippet_safe or '[no snippet]'}</font>",
                             S["Code"])]]
        if f.get("taint_path"):
            ev_rows.append([Paragraph(
                f"<b>Taint Path:</b> <font color='#C0392B'>{f['taint_path']}</font>",S["BodySmall"])])
        ev_tbl=Table(ev_rows,colWidths=[17*cm])
        ev_tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#E8F0FE")),
                                     ("BACKGROUND",(0,1),(-1,-1),GREY_LIGHT),
                                     ("GRID",(0,0),(-1,-1),0.5,GREY_MED),
                                     ("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4),
                                     ("LEFTPADDING",(0,0),(-1,-1),6)]))

        rem=f.get("remediation",[])
        rem_text="".join(f"<br/>&nbsp;&nbsp;{i+1}. {s}" for i,s in enumerate(rem))
        rem_tbl=Table([[Paragraph("<b>Remediation Steps</b>",S["BodySmall"])],
                       [Paragraph(rem_text or "Follow secure coding best practices.",S["Body"])]],
                      colWidths=[17*cm])
        rem_tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#E9F7EF")),
                                      ("BACKGROUND",(0,1),(-1,-1),WHITE),
                                      ("GRID",(0,0),(-1,-1),0.5,GREY_MED),
                                      ("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4),
                                      ("LEFTPADDING",(0,0),(-1,-1),6)]))

        items=[hdr,meta_tbl]
        if af_tbl: items.append(af_tbl)
        items+=[desc_tbl,ev_tbl,rem_tbl,Spacer(1,0.5*cm)]
        story.append(KeepTogether(items))
    return story

# ── SBOM ──────────────────────────────────────────────────────────────────────

def _sbom_section(payload):
    story=_sec("5. SBOM — Dependency Vulnerabilities")
    sbom=payload.get("sbom",[])
    if not sbom:
        story.append(Paragraph("No dependency manifests found.",S["Body"])); return story

    vuln_deps=[d for d in sbom if d.get("cve")]
    reachable=[d for d in vuln_deps if d.get("reachable")]
    story.append(Paragraph(
        f"{len(vuln_deps)} of {len(sbom)} packages have known CVEs. "
        f"<b>{len(reachable)} are marked reachable</b> (exploitable in this context).",S["Body"]))

    rows=[[Paragraph(h,S["TH"]) for h in
           ["Package","Ver","Type","CVE","CVSS","EPSS","Severity","Reachable","Fixed In"]]]
    for pkg in sbom:
        sev=pkg.get("severity","None")
        epss=pkg.get("epss")
        epss_str=f"{epss:.3f}" if epss is not None else "--"
        direct=pkg.get("direct",True)
        rows.append([
            Paragraph(pkg.get("name",""),         S["TDSm"]),
            Paragraph(pkg.get("version",""),      S["TDC"]),
            Paragraph("D" if direct else "T",     S["TDC"]),
            Paragraph(pkg.get("cve") or "--",     S["TDSm"]),
            Paragraph(str(pkg.get("cvss") or "--"),S["TDC"]),
            Paragraph(epss_str,                   S["TDC"]),
            Paragraph(sev,                        S["TDC"]),
            Paragraph("Yes" if pkg.get("reachable") else "No", S["TDC"]),
            Paragraph(pkg.get("fixed_in") or "--",S["TDSm"]),
        ])
    t=Table(rows,colWidths=[3.5*cm,2*cm,1.2*cm,3*cm,1.5*cm,1.5*cm,2*cm,2*cm,2.3*cm])
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),DARK_BLUE),
                            ("GRID",(0,0),(-1,-1),0.5,GREY_MED),
                            ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,LIGHT_BLUE]),
                            ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
                            ("FONTSIZE",(0,0),(-1,-1),7)]))
    story.append(t); return story

# ── Conclusion ────────────────────────────────────────────────────────────────

def _conclusion(payload):
    story=_sec("6. Conclusion & Remediation SLA")
    meta=payload.get("metadata",{}); dist=meta.get("severity_distribution",{}); risk=meta.get("risk_score",0)
    story.append(Paragraph(
        f"This assessment identified <b>{meta.get('total_findings',0)} unique vulnerabilities</b> "
        f"with a portfolio risk score of <b>{risk}/100</b>. "
        f"All critical and high findings must be verified post-remediation before next production release.",S["Body"]))
    story.append(Spacer(1,0.3*cm))
    rows=[[Paragraph(h,S["TH"]) for h in ["Priority","Severity","Count","SLA","Owner"]],
          ["P1","Critical",str(dist.get("Critical",0)),"< 24 hours","Security Team + Dev Lead"],
          ["P2","High",    str(dist.get("High",    0)),"7 days",     "Dev Team"],
          ["P3","Medium",  str(dist.get("Medium",  0)),"30 days",    "Dev Team"],
          ["P4","Low",     str(dist.get("Low",     0)),"90 days",    "Dev Team (backlog)"]]
    t=Table(rows,colWidths=[2*cm,3.5*cm,2.5*cm,4*cm,6*cm])
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),DARK_BLUE),("TEXTCOLOR",(0,0),(-1,0),WHITE),
                            ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
                            ("GRID",(0,0),(-1,-1),0.5,GREY_MED),
                            ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,LIGHT_BLUE]),
                            ("ALIGN",(0,0),(-1,-1),"CENTER"),
                            ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
                            ("FONTSIZE",(0,0),(-1,-1),9)]))
    story.append(t); story.append(Spacer(1,0.4*cm))
    story.append(Paragraph("This report is confidential and restricted to authorized personnel.",S["Body"]))

    # ── Final Recommendation block ───────────────────────────────────────────
    story.append(Spacer(1,0.5*cm))
    story+=_sec("Final Recommendation")

    crit  = dist.get("Critical", 0)
    high  = dist.get("High",     0)
    grouped = payload.get("grouped", [])

    # Collect the most severe vuln titles for the bullet list
    critical_vulns = [f.get("title","") for f in grouped
                      if f.get("severity") in ("Critical","High")][:5]

    if crit > 0 or high > 0:
        # Red DO NOT RELEASE banner
        banner_tbl = Table(
            [[Paragraph("⚠  DO NOT RELEASE", _s("Banner",
                fontName="Helvetica-Bold", fontSize=14,
                textColor=WHITE, alignment=TA_CENTER, leading=18))]],
            colWidths=[17*cm]
        )
        banner_tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0,0), (-1,-1), RED),
            ("TOPPADDING",    (0,0), (-1,-1), 10),
            ("BOTTOMPADDING", (0,0), (-1,-1), 10),
            ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ]))
        story.append(banner_tbl)
        story.append(Spacer(1, 0.3*cm))

        story.append(Paragraph(
            "This application contains exploitable critical and high vulnerabilities. "
            "Production deployment is <b>blocked</b> until all P1 and P2 findings are "
            "remediated and verified by a full re-scan.",
            S["Body"]
        ))
        story.append(Spacer(1, 0.2*cm))

        story.append(Paragraph("<b>Vulnerabilities blocking release:</b>", S["BodySmall"]))
        for title in critical_vulns:
            story.append(Paragraph(f"* {title}", S["Bullet"]))

        story.append(Spacer(1, 0.3*cm))
        story.append(Paragraph(
            "<b>Required actions before re-scan:</b>",
            S["BodySmall"]
        ))
        actions = [
            "Fix all P1 Critical findings within 24 hours.",
            "Fix all P2 High findings within 7 days.",
            "Perform a full re-scan after each fix batch.",
            "Obtain sign-off from Security Team Lead before any deployment.",
        ]
        for a in actions:
            story.append(Paragraph(f"* {a}", S["Bullet"]))
    else:
        # Green release-approved banner
        banner_tbl = Table(
            [[Paragraph("✓  RELEASE APPROVED (WITH CONDITIONS)", _s("BannerOK",
                fontName="Helvetica-Bold", fontSize=12,
                textColor=WHITE, alignment=TA_CENTER, leading=16))]],
            colWidths=[17*cm]
        )
        banner_tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0,0), (-1,-1), GREEN),
            ("TOPPADDING",    (0,0), (-1,-1), 8),
            ("BOTTOMPADDING", (0,0), (-1,-1), 8),
        ]))
        story.append(banner_tbl)
        story.append(Spacer(1, 0.3*cm))
        story.append(Paragraph(
            "No critical or high severity findings detected. "
            "Release can proceed subject to risk acceptance, monitoring in place, "
            "and remediation of medium findings within 30 days.",
            S["Body"]
        ))

    return story

# ── Public interface ──────────────────────────────────────────────────────────

def generate_pdf_report(payload:dict, output_path:str,
                        logo_path:str|None=None) -> str:
    path=Path(output_path); path.parent.mkdir(parents=True,exist_ok=True)
    if logo_path is None:
        candidate=Path(output_path).parent.parent/"logo.png"
        if candidate.exists(): logo_path=str(candidate)

    doc=_Doc(str(path),leftMargin=MARGIN,rightMargin=MARGIN,
              topMargin=MARGIN+1.2*cm,bottomMargin=MARGIN+1.1*cm)
    story: list=[]
    # PATCH 9: cover → ToC → sections, each with its own page template (PATCH 8)
    story.append(NextPageTemplate("Cover"))
    story += _cover(payload, logo_path=logo_path)

    # Table of Contents (PATCH 9) — on its own Content page
    story.append(NextPageTemplate("Content"))
    story.append(PageBreak())
    story += _toc_section(payload, getattr(doc, "_page_map", None))
    story.append(PageBreak())

    # Each section switches to its named template (PATCH 8: dynamic header label)
    # PATCH 7: every section starts on a clean page (PageBreak before each)
    story.append(NextPageTemplate("ExecSummary"))
    story.append(_TocBookmark("Executive Summary"))
    story += _exec_summary(payload)
    story.append(PageBreak())

    story.append(NextPageTemplate("TopCauses"))
    story.append(_TocBookmark("Top Root Causes"))
    story += _top_root_causes_section(payload)
    story.append(PageBreak())

    story.append(NextPageTemplate("Compliance"))
    story.append(_TocBookmark("Compliance Mapping"))
    story += _compliance(payload)
    story.append(PageBreak())

    story.append(NextPageTemplate("AttackPaths"))
    story.append(_TocBookmark("Attack Path Correlation"))
    story += _attack_paths_section(payload)
    story.append(PageBreak())

    story.append(NextPageTemplate("Findings"))
    story.append(_TocBookmark("Detailed Findings"))
    story += _findings_section(payload)
    story.append(PageBreak())

    story.append(NextPageTemplate("SBOM"))
    story.append(_TocBookmark("SBOM & Dependencies"))
    story += _sbom_section(payload)
    story.append(PageBreak())

    story.append(NextPageTemplate("Conclusion"))
    story.append(_TocBookmark("Conclusion & Remediation SLA"))
    story += _conclusion(payload)

    doc.build(story)
    return str(path)
