"""
reporting/excel_report.py  v3

FIX LOG (v2 → v3):
  1. BUG  — SBOM sheet: pkg.get("direct", True) replaced with pkg.get("type", "Direct")
             to match the string field now produced by sbom.py v3
  2. BUG  — File column: str(Path(...).name) fails on Windows-style backslash paths
             on Linux/macOS; replaced with os.path.basename() (cross-platform)
  3. WARN — Findings sheet: "Confidence" and "Score Rationale" columns added,
             surfacing score_finding() breakdown and taint confidence per finding
  4. WARN — Findings sheet: "Affected Files" column added, showing all files
             from the grouped finding's affected_files[] list
  5. ENH  — Summary sheet: risk score model description rows added so auditors
             can understand and challenge the portfolio score without the PDF
"""
from __future__ import annotations

BIG4_REPORT_COMPLIANCE_FALLBACKS = {
    "tls": ("Req 4.2 / Req 6.2.4", "SC-8 / SC-13 / SI-10", "A.8.24 / A.8.20", "CC6.7 / CC6.6"),
    "actuator": ("Req 6.2.4 / Req 7", "CM-7 / AC-3 / SC-7", "A.8.9 / A.8.20", "CC6.6 / CC7.2"),
    "xxe": ("Req 6.2.4", "SI-10 / SC-7", "A.14.2.5 / A.13.1.1", "CC6.6 / CC7.2"),
    "prototype": ("Req 6.2.4", "SI-10 / CM-7", "A.8.28 / A.8.29", "CC6.6 / CC7.2"),
    "redos": ("Req 6.2.4", "SC-5 / SI-10", "A.8.16 / A.8.20", "CC7.2 / CC6.6"),
    "async": ("Req 7 / Req 8", "AC-3 / AC-6", "A.5.15 / A.8.2", "CC6.1 / CC6.6"),
    "missing @valid": ("Req 6.2.4", "SI-10", "A.8.28 / A.8.29", "CC6.6"),
}

import os
from pathlib import Path
from reporting.report_mappings import (
    BUSINESS_IMPACT_BY_RULE,
    REMEDIATION_BY_RULE,
    rule_key as _report_rule_key,
    needs_business_impact_replacement as _needs_bi_replace,
    needs_remediation_replacement as _needs_rem_replace,
)

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

C_NAVY = "1B3A5C"; C_BLUE = "2563A8"; C_LBLUE = "D6E8F7"
C_RED  = "C0392B"; C_ORG  = "E67E22"; C_YEL   = "F1C40F"
C_GRN  = "27AE60"; C_WHT  = "FFFFFF"; C_GRY   = "F4F6F8"
C_BDR  = "B8CCE4"; C_BLK  = "1A1A2E"; C_GOLD  = "C9A84C"
# Confidence cell colours
C_CONF_HIGH = "E8F5E9"  # light green
C_CONF_MED  = "FFF8E1"  # light amber
C_CONF_LOW  = "FFEBEE"  # light red

def _fill(h):  return PatternFill("solid", fgColor=h)
def _font(bold=False, color=C_WHT, size=10):
    return Font(name="Calibri", bold=bold, color=color, size=size)
def _bdr():
    t = Side(style="thin", color=C_BDR)
    return Border(left=t, right=t, top=t, bottom=t)
def _ctr(): return Alignment(horizontal="center", vertical="center", wrap_text=True)
def _lft(): return Alignment(horizontal="left",   vertical="center", wrap_text=True)

SEV_FILL = {
    "Critical": _fill(C_RED), "High": _fill(C_ORG), "Medium": _fill(C_YEL),
    "Low": _fill(C_GRN), "Info": _fill("808080"), "None": _fill(C_GRN),
}
SEV_FONT = {
    "Critical": _font(True), "High": _font(True),
    "Medium":   _font(True, color=C_BLK), "Low": _font(True),
    "Info":     _font(True), "None": _font(True),
}
CONF_FILL = {
    "High":   _fill(C_CONF_HIGH),
    "Medium": _fill(C_CONF_MED),
    "Low":    _fill(C_CONF_LOW),
}
CONF_FONT = {
    "High":   _font(color="1B5E20"),
    "Medium": _font(color="E65100"),
    "Low":    _font(color="B71C1C"),
}

def _pkg_cve_list(pkg):
    values = []
    if pkg.get("cve"):
        values.append(str(pkg.get("cve")))
    for key in ("cves", "additional_cves", "vulnerability_ids"):
        val = pkg.get(key)
        if isinstance(val, list):
            values.extend(str(x) for x in val if x)
        elif isinstance(val, str) and val.strip():
            values.extend(x.strip() for x in val.split(",") if x.strip())
    vulns = pkg.get("vulnerabilities") or []
    if isinstance(vulns, list):
        for vuln in vulns:
            if isinstance(vuln, dict):
                vid = vuln.get("cve") or vuln.get("id") or vuln.get("advisory_id")
                if vid:
                    values.append(str(vid))
    return sorted(set(values))


def _first_value(pkg, *keys, default="--"):
    for key in keys:
        val = pkg.get(key)
        if val not in (None, "", [], {}, "Unknown"):
            return val
    return default


def _is_reachable_vulnerable(pkg):
    return bool(pkg.get("reachable")) or str(pkg.get("reachability_priority", "")).upper() == "REACHABLE_VULNERABLE"


def _is_exploitable_dependency(pkg):
    epss_priority = str(pkg.get("epss_priority") or "").upper()
    patch_urgency = str(pkg.get("patch_urgency") or "").upper()
    decision = str(pkg.get("exploitability_decision") or pkg.get("exploitability_action") or "").upper()
    return (
        _is_reachable_vulnerable(pkg)
        or bool(pkg.get("kev_status"))
        or epss_priority == "P0_IMMEDIATE"
        or patch_urgency == "IMMEDIATE"
        or decision in {"IMMEDIATE_REMEDIATE", "PRIORITY_PATCH"}
    )


def _fmt_float(value, digits=3):
    try:
        if value in (None, "", "--", "N/A"):
            return "--"
        return f"{float(value):.{digits}f}"
    except Exception:
        return str(value) if value not in (None, "") else "--"

def _hdr(ws, row, headers, col=1):
    for i, h in enumerate(headers):
        c = ws.cell(row=row, column=col + i, value=h)
        c.fill = _fill(C_NAVY); c.font = _font(True); c.alignment = _ctr(); c.border = _bdr()

def _title_row(ws, text, cols):
    ws.merge_cells(f"A1:{get_column_letter(cols)}1")
    c = ws["A1"]; c.value = text
    c.fill = _fill(C_NAVY); c.font = _font(True, size=12)
    c.alignment = _ctr(); ws.row_dimensions[1].height = 30

def _title(ws, text):
    # Backward-compatible helper used by privacy/IOC sheets.
    # Keeps layout consistent with existing workbook title rows.
    _title_row(ws, text, 12)


def _supplemental_counts(payload):
    ps = payload.get("privacy_data_exposure_summary", {}) or {}
    is_ = payload.get("ioc_malware_intelligence_summary", {}) or {}
    return int(ps.get("total_privacy_indicators", 0) or 0), int(is_.get("total_ioc_indicators", 0) or 0)


def _classify_data(item: dict) -> str:
    text = " ".join(str(item.get(k, "")) for k in ("title", "vuln_type", "description", "snippet", "evidence")).lower()
    pii_types = item.get("pii_types") or []
    if pii_types:
        joined = " ".join(str(x).lower() for x in pii_types)
        if any(x in joined for x in ["card", "pci", "cvv"]): return "PCI"
        if any(x in joined for x in ["health", "medical", "phi"]): return "PHI"
        return "PII"
    if any(x in text for x in ["password", "secret", "token", "api key", "credential"]): return "Secrets"
    if any(x in text for x in ["ssn", "aadhaar", "pan", "email", "phone", "address", "dob", "pii", "personal"]): return "PII"
    if any(x in text for x in ["card", "cvv", "stripe"]): return "PCI"
    if any(x in text for x in ["system prompt", "internal", "admin", "private"]): return "Internal"
    if any(x in text for x in ["regulated", "privacy", "gdpr", "dpdp"]): return "Regulated"
    return "Internal" if item.get("severity") in {"Critical", "High"} else "Public"


def _evidence_confidence(item: dict) -> str:
    if item.get("taint_path") or str(_display_detection(item)).upper() == "TAINT-VALIDATED": return "Confirmed"
    if item.get("correlation_evidence") or item.get("blast_radius") or item.get("chains_to"): return "Correlated"
    det = str(_display_detection(item)).lower()
    if "heuristic" in det or "privacy" in det or "ioc" in det: return "Heuristic"
    return "Pattern"


def _display_detection(item: dict) -> str:
    det = str(item.get("detection") or "").strip()
    if det.lower() not in {"", "none", "null", "n/a", "na", "not applicable", "unknown"}:
        return "TAINT-VALIDATED" if det == "AST Taint Analysis" else det
    engine = str(item.get("engine") or "").lower()
    if item.get("taint_path") and "->" in str(item.get("taint_path")):
        return "TAINT-VALIDATED"
    if "framework" in engine:
        return "Framework-Aware Static Enrichment"
    if "api_abuse" in engine:
        return "API Abuse Heuristic"
    if "data_flow" in engine:
        return "Data Flow Correlation"
    return "Enterprise SAST Pattern"


def _fallback_compliance(item: dict) -> dict:
    title = str(item.get("title") or "").lower()
    vt = str(item.get("vuln_type") or item.get("rule_id") or "").lower()
    det = str(item.get("detection") or "").lower()
    rid = str(item.get("rule_id") or "").lower()
    text = " ".join([title, vt, det, rid])

    def _val(*keys):
        for key in keys:
            v = item.get(key)
            if str(v or "").strip() and str(v).strip().lower() not in {"not applicable", "n/a", "na", "none", "null", "unknown", "-"}:
                return v
        return "Not Applicable"

    m = {
        "pci_dss": _val("pci_dss"),
        "nist": _val("nist", "nist_800_53"),
        "iso27001": _val("iso27001", "iso_27001"),
        "soc2": _val("soc2"),
    }

    def set_if_empty(pci, nist, iso, soc2):
        if m["pci_dss"] == "Not Applicable": m["pci_dss"] = pci
        if m["nist"] == "Not Applicable": m["nist"] = nist
        if m["iso27001"] == "Not Applicable": m["iso27001"] = iso
        if m["soc2"] == "Not Applicable": m["soc2"] = soc2

    # Direct reporting fallbacks for findings that previously rendered as Not Applicable.
    if "tenant" in text and "isolation" in text:
        set_if_empty(
            "Req 7 / Req 8 - Access control and tenant data segregation",
            "AC-3 / AC-6 / SC-7",
            "A.5.15 / A.8.3 / A.8.20",
            "CC6.1 / CC6.6 / CC7.2",
        )
    if "graphql" in text and "introspection" in text:
        set_if_empty(
            "Req 6.2.4 - Secure API configuration",
            "CM-7 / AC-3 / SC-7",
            "A.8.9 / A.8.20",
            "CC6.6 / CC7.2",
        )
    if "graphql" in text and ("idor" in text or "bola" in text):
        set_if_empty(
            "Req 7 / Req 8 - Access control",
            "AC-3 / AC-6 / SI-10",
            "A.5.15 / A.8.3 / A.8.20",
            "CC6.1 / CC6.6",
        )
    if "setaccessible" in text or "set_accessible" in text or "dangerous reflection" in text:
        set_if_empty(
            "Req 6.2.4 - Secure coding and unsafe reflection prevention",
            "SI-10 / CM-7 / SA-11",
            "A.8.28 / A.8.29",
            "CC7.1 / CC7.2",
        )

    if any(x in text for x in ["privacy", "pii", "personal", "sensitive information", "prompt response logging"]):
        set_if_empty("Req 3.2 / Req 10", "PT-2 / SI-12", "A.8.2 / A.18.1.4", "CC6.1 / CC8.1")
    if any(x in text for x in ["ioc", "malware", "backdoor", "reverse shell", "payload", "persistence"]):
        set_if_empty("Req 5", "SI-3 / SI-4", "A.12.2.1", "CC7.2 / CC7.3")
    if any(x in text for x in ["rate limit", "ratelimit", "rate-limit", "abuse-prone", "api_rate_limit", "api_abuse", "brute force", "otp", "mfa", "password reset", "token refresh", "coupon", "replay", "resource consumption", "api4"]):
        set_if_empty("Req 6.2.4 / Req 8 - Abuse prevention and authentication controls", "AC-7 / SC-5 / SI-10", "A.8.16 / A.8.20", "CC7.2 / CC6.6")
    if any(x in text for x in ["llm", "prompt", "rag", "model", "agent", "autonomous", "tool"]):
        set_if_empty("Req 6.2.4", "SI-10 / CM-7", "A.14.2.5", "CC7.2 / CC6.6")
    if any(x in text for x in ["kubernetes", "container", "privileged", "host network", "read-only", "non-root", "image pull"]):
        set_if_empty("Req 6.2.4", "CM-7 / AC-6", "A.12.6.1", "CC6.6")
    if any(x in text for x in ["terraform", "security group", "s3", "rds", "ebs", "public", "encryption"]):
        set_if_empty("Req 1.3 / Req 3.5", "SC-7 / AC-3 / SC-13", "A.13.1.1 / A.10.1.1", "CC6.6 / CC6.1")
    if any(x in text for x in ["mass assignment", "overposting", "field binding", "model binding"]):
        set_if_empty("Req 6.2.4 / Req 7 - Access control", "AC-3 / SI-10", "A.9.4.1 / A.14.2.5", "CC6.1 / CC6.6")
    if any(x in text for x in ["secret", "credential", "api key", "password", "token"]):
        set_if_empty("Req 8.3.2", "IA-5", "A.9.4.3", "CC6.1")
    if any(x in text for x in ["injection", "exec", "eval", "subprocess", "shell", "ssrf"]):
        set_if_empty("Req 6.2.4", "SI-10", "A.14.2.5", "CC6.6")
    return m


def _mapped_business_impact(item: dict) -> str:
    raw = str(item.get("business_impact") or "").strip()
    if _needs_bi_replace(raw):
        return BUSINESS_IMPACT_BY_RULE.get(
            _report_rule_key(item),
            "Security impact requires manual triage based on reachable context and exposed asset criticality."
        )
    return raw


def _mapped_remediation(item: dict) -> str:
    rem = item.get("remediation") or []
    if _needs_rem_replace(rem):
        rem = REMEDIATION_BY_RULE.get(_report_rule_key(item), rem)
    if isinstance(rem, list):
        return "\n".join(str(x) for x in rem if str(x).strip())
    return str(rem or "Follow secure coding best practices.")

def _root_cause_id(item: dict) -> str:
    text = " ".join(str(item.get(k, "")) for k in ("title", "vuln_type", "rule_id", "cwe", "owasp", "description")).lower()
    families = [
        ("DESERIALIZATION", ["deserialization", "objectinputstream", "binaryformatter", "typenamehandling", "unserialize", "phar", "gob"]),
        ("COMMAND_CODE_INJECTION", ["command injection", "code injection", "exec", "eval", "spel", "jndi", "template injection"]),
        ("SQL_ORM_NOSQL_INJECTION", ["sql", "hql", "jpql", "nosql", "fromsqlraw", "orm"]),
        ("BROKEN_ACCESS_CONTROL", ["idor", "bola", "mass assignment", "overposting", "open redirect", "tenant", "privilege", "workflow", "csrf"]),
        ("SSRF", ["ssrf", "server-side request forgery", "outbound request"]),
        ("CRYPTOGRAPHIC_WEAKNESS", ["tls", "insecureskipverify", "trustmanager", "hostnameverifier", "md5", "sha-1", "crypto"]),
        ("RESOURCE_EXHAUSTION", ["redos", "rate limit", "resource exhaustion", "readall", "complexity"]),
        ("SECURITY_MISCONFIGURATION", ["actuator", "xxe", "dtd", "misconfiguration", "exposed", "debug"]),
        ("SECRETS_CREDENTIALS", ["secret", "credential", "password", "token", "private key", "api key"]),
    ]
    for family, words in families:
        if any(w in text for w in words):
            return "ROOT_" + family
    base = str(item.get("vuln_type") or item.get("rule_id") or item.get("title") or "unknown").upper().replace(" ", "_")
    return "ROOT_" + "".join(ch for ch in base if ch.isalnum() or ch == "_")[:40]


def _engine_name(item: dict) -> str:
    det = str(_display_detection(item) or "").lower()
    vt = str(item.get("vuln_type", "") or "").lower()
    if "privacy" in det or "privacy" in vt: return "Privacy Data Exposure"
    if "ioc" in det or "malware" in vt or "backdoor" in vt: return "IOC / Malware Intelligence"
    if "llm" in det or "llm" in vt or "ai_" in vt: return "AI / LLM Security"
    if "kubernetes" in det: return "Kubernetes IaC"
    if "terraform" in det: return "Terraform IaC"
    if "docker" in det: return "Dockerfile IaC"
    if item.get("cve"): return "SCA / Dependency Intelligence"
    return "SAST"



# ── Sheet 1: Summary ─────────────────────────────────────────────────────────
def _summary(ws, payload):
    ws.title = "Summary"
    for col, w in zip("ABCDE", [28, 20, 16, 30, 30]):
        ws.column_dimensions[col].width = w

    meta  = payload.get("metadata", {})
    dist  = meta.get("severity_distribution", {})
    model = meta.get("risk_score_model", {})

    _title_row(ws, "SECURITY ASSESSMENT — EXECUTIVE SUMMARY", 5)

    # FIX #5: include scoring model rows so auditors can understand the score
    rows = [
        ("Tool",                meta.get("tool", "")),
        ("Target",              meta.get("target", "")),
        ("Scan Date",           meta.get("scan_date", "")[:10]),
        ("SAST Findings",       meta.get("sast_findings", meta.get("total_findings", 0))),
        ("SCA Findings",        meta.get("sca_findings", 0)),
        ("Total Findings",      meta.get("total_findings", 0)),
        ("Supplemental Privacy Indicators", _supplemental_counts(payload)[0]),
        ("Supplemental IOC / Backdoor Indicators", _supplemental_counts(payload)[1]),
        ("Portfolio Risk Score", f"{meta.get('risk_score', 0)}/100"),
        ("Scoring Model",       model.get("model", "")),
        ("Score Formula",       model.get("portfolio_method", "")),
        ("Confidence Multipliers", "High=1.0×  Medium=0.85×  Low=0.70×"),
        ("Methodology Note", "Pattern-only Critical findings are severity-critical because the sink is dangerous; exploitability/confidence may remain Medium/Low until taint or runtime validation confirms reachability."),
    ]
    for i, (lbl, val) in enumerate(rows, 2):
        ws.cell(row=i, column=1, value=lbl).font  = _font(True, color=C_BLK)
        ws.cell(row=i, column=1).fill              = _fill(C_GRY)
        ws.cell(row=i, column=1).alignment         = _lft()
        ws.cell(row=i, column=2, value=val).font   = _font(color=C_BLK)
        ws.cell(row=i, column=2).alignment         = _lft()

    sr = len(rows) + 3
    ws.merge_cells(f"A{sr}:E{sr}")
    h = ws[f"A{sr}"]; h.value = "SEVERITY DISTRIBUTION"
    h.fill = _fill(C_BLUE); h.font = _font(True, size=11); h.alignment = _ctr()
    ws.row_dimensions[sr].height = 22

    _hdr(ws, sr + 1, ["Severity", "Count", "Priority", "SLA", "Risk Action"])
    slas = {"Critical": "< 24 hours", "High": "7 days", "Medium": "30 days",
            "Low": "90 days", "Info": "Next sprint"}
    pris = {"Critical": "P1", "High": "P2", "Medium": "P3", "Low": "P4", "Info": "P4"}
    acts = {
        "Critical": "Remediate immediately — block release",
        "High":     "Fix within 7 days — escalate to security lead",
        "Medium":   "Fix within 30 days — add to sprint backlog",
        "Low":      "Fix within 90 days — track in backlog",
        "Info":     "Review at convenience",
    }
    for j, sev in enumerate(["Critical", "High", "Medium", "Low", "Info"]):
        r = sr + 2 + j
        for col, val in enumerate([sev, dist.get(sev, 0), pris[sev], slas[sev], acts[sev]], 1):
            c = ws.cell(row=r, column=col, value=val)
            c.border = _bdr()
            if col == 1:
                c.fill = SEV_FILL.get(sev, _fill(C_GRY))
                c.font = SEV_FONT.get(sev, _font(color=C_BLK))
                c.alignment = _ctr()
            else:
                c.fill = _fill(C_GRY); c.font = _font(color=C_BLK)
                c.alignment = _lft() if col == 5 else _ctr()

    ir = sr + 9
    ws.merge_cells(f"A{ir}:E{ir}")
    ih = ws[f"A{ir}"]; ih.value = "INTELLIGENCE INSIGHTS"
    ih.fill = _fill(C_NAVY); ih.font = _font(True, size=11); ih.alignment = _ctr()
    for k, ins in enumerate(payload.get("insights", []), 1):
        r = ir + k
        ws.merge_cells(f"A{r}:E{r}")
        c = ws[f"A{r}"]; c.value = f"* {ins}"
        c.font = _font(color=C_BLK, size=9)
        c.fill = _fill(C_GRY if k % 2 else C_WHT)
        c.alignment = _lft(); c.border = _bdr()
        ws.row_dimensions[r].height = 28


# ── Sheet 2: Findings ─────────────────────────────────────────────────────────
def _findings(ws, payload):
    ws.title = "Findings"
    # FIX #3: added Confidence and Score Rationale columns
    # FIX #4: added Affected Files column
    headers = [
        "#", "Issue", "Severity", "Priority", "Risk Score",
        "File", "Affected Files", "Line",
        "CWE", "OWASP", "MITRE",
        "PCI DSS", "NIST", "ISO 27001", "SOC2",
        "CVE", "CVSS",
        "Confidence", "Evidence Confidence", "Data Classification", "Detection Source", "Engine Name",
        "Primary Root Cause", "Secondary Chained Risk", "Instances", "Score Rationale", "Fix Summary",
    ]
    widths = [
        4,   32,   12,   10,   10,
        28,  42,   6,
        14,  28,   12,
        30,  28,   24,   20,
        18,  8,
        12,  10,   52,   45,
    ]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    _title_row(ws, "DETAILED SECURITY FINDINGS — ALL COMPLIANCE FIELDS", len(headers))
    _hdr(ws, 2, headers)
    ws.row_dimensions[2].height = 22
    ws.freeze_panes = "A3"

    for i, f in enumerate(payload.get("grouped", []), start=3):
        sev        = f.get("severity", "Medium")
        confidence = f.get("confidence", "")
        bg         = C_LBLUE if i % 2 == 0 else C_WHT
        rem        = f.get("remediation", [])
        instances  = f.get("instances", 1)

        # FIX #2: cross-platform file name extraction
        primary_file   = os.path.basename(f.get("file", ""))
        # FIX #4: show all affected files (basename of each)
        affected_files = f.get("affected_files", [f.get("file", "")])
        affected_str   = "; ".join(os.path.basename(fp) for fp in affected_files)

        score_explanation = f.get("score_breakdown", {}).get("explanation", "")
        cm = _fallback_compliance(f)
        chains = ", ".join(f.get("chains_to") or []) if isinstance(f.get("chains_to"), list) else (f.get("chains_to") or "")

        row_vals = [
            i - 2,
            f.get("title", ""),
            sev,
            f.get("priority", ""),
            f.get("risk_score", ""),
            primary_file,
            affected_str,             # FIX #4
            f.get("line", ""),
            f.get("cwe", ""),
            f.get("owasp", ""),
            f.get("mitre", ""),
            cm.get("pci_dss", "Not Applicable"),
            cm.get("nist", "Not Applicable"),
            cm.get("iso27001", "Not Applicable"),
            cm.get("soc2", "Not Applicable"),
            f.get("cve") or "N/A",
            f.get("cvss") or "N/A",
            confidence,               # FIX #3
            _evidence_confidence(f),
            _classify_data(f),
            _display_detection(f),
            _engine_name(f),
            _root_cause_id(f),
            chains or "--",
            instances,
            score_explanation,        # FIX #3
            rem[0] if rem else "",
        ]
        for j, val in enumerate(row_vals, 1):
            cell = ws.cell(row=i, column=j, value=val)
            cell.border    = _bdr()
            cell.font      = Font(name="Calibri", size=9, color=C_BLK)
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
            if j == 3:   # Severity
                cell.fill = SEV_FILL.get(sev, _fill(bg))
                cell.font = SEV_FONT.get(sev, _font(color=C_BLK))
                cell.alignment = _ctr()
            elif j == 18:  # Confidence — colour-coded cell
                cell.fill = CONF_FILL.get(confidence, _fill(bg))
                cell.font = CONF_FONT.get(confidence, _font(color=C_BLK))
                cell.alignment = _ctr()
            elif j in {19, 20}:
                cell.fill = _fill("EAF4FB")
                cell.alignment = _ctr()
            else:
                cell.fill = _fill(bg)
        ws.row_dimensions[i].height = 30


# ── Sheet 3: SBOM ─────────────────────────────────────────────────────────────
def _sbom(ws, payload):
    ws.title = "SBOM"
    headers = [
        "Package", "Version", "Type", "Parent", "CVE / Advisory", "CVSS", "EPSS",
        "KEV", "Reachable Vulnerable", "Exploitability Decision", "Patch Urgency",
        "Severity", "Fixed In", "Additional CVEs", "NVD Link",
    ]
    widths = [22, 14, 12, 18, 26, 8, 8, 8, 18, 24, 16, 12, 16, 28, 52]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    _title_row(ws, "SOFTWARE BILL OF MATERIALS (SBOM) — WITH CVE + EPSS", len(headers))
    _hdr(ws, 2, headers)
    ws.row_dimensions[2].height = 22
    ws.freeze_panes = "A3"

    for i, pkg in enumerate(payload.get("sbom", []), start=3):
        sev    = pkg.get("severity", "None")
        bg     = C_LBLUE if i % 2 == 0 else C_WHT
        epss_s = _fmt_float(_first_value(pkg, "epss_score", "epss", default="--"), 3)
        pkg_type = pkg.get("dependency_type") or pkg.get("type", "Direct")
        parent = pkg.get("parent") or pkg.get("introduced_by") or "--"
        cves = _pkg_cve_list(pkg)
        additional_cve = ", ".join(pkg.get("additional_cves", [])) if isinstance(pkg.get("additional_cves"), list) else "--"
        if not additional_cve:
            additional_cve = "--"
        row_vals = [
            pkg.get("name", ""),
            pkg.get("version", ""),
            pkg_type,
            parent,
            ", ".join(cves[:4]) or "--",
            _fmt_float(_first_value(pkg, "cvss", "cvss_score", default="--"), 1),
            epss_s,
            "Yes" if pkg.get("kev_status") else "No",
            "Yes" if _is_reachable_vulnerable(pkg) else "No",
            _first_value(pkg, "exploitability_decision", "exploitability_action", default="Review" if cves else "--"),
            _first_value(pkg, "patch_urgency", "epss_priority", default="--"),
            sev,
            _first_value(pkg, "fixed_in", "fixed_versions", default="Unknown" if cves else "--"),
            additional_cve,
            pkg.get("nvd") or pkg.get("nvd_url") or "--",
        ]
        for j, val in enumerate(row_vals, 1):
            cell = ws.cell(row=i, column=j, value=val)
            cell.border    = _bdr()
            cell.font      = Font(name="Calibri", size=9, color=C_BLK)
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
            if j == 12:   # Severity
                cell.fill = SEV_FILL.get(sev, _fill(bg))
                cell.font = SEV_FONT.get(sev, _font(color=C_BLK))
                cell.alignment = _ctr()
            elif j in {8, 9}:  # KEV / Reachable Vulnerable
                cell.fill = _fill("FFE5E5") if val == "Yes" else _fill(bg)
                cell.alignment = _ctr()
            else:
                cell.fill = _fill(bg)
        ws.row_dimensions[i].height = 22


# ── Sheet 4: Attack Paths ─────────────────────────────────────────────────────
def _attack_paths(ws, payload):
    ws.title = "Attack Paths"
    headers = [
        "#", "Attack Path", "Severity", "Risk Score",
        "Entry Point", "Exploit", "Pivot", "Impact", "Chains To",
    ]
    widths = [4, 30, 12, 10, 28, 24, 20, 35, 25]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    _title_row(ws, "ATTACK PATH CORRELATION — EXPLOIT CHAINS", len(headers))
    _hdr(ws, 2, headers)
    ws.row_dimensions[2].height = 22
    ws.freeze_panes = "A3"

    paths = payload.get("attack_paths", [])
    if not paths:
        ws.merge_cells(f"A3:{get_column_letter(len(headers))}3")
        c = ws["A3"]; c.value = "No multi-step attack chains detected."
        c.font = _font(color=C_BLK); c.alignment = _lft()
        return

    for i, ap in enumerate(paths, start=3):
        sev    = ap.get("severity", "Medium")
        bg     = C_LBLUE if i % 2 == 0 else C_WHT
        steps  = ap.get("steps", [])
        chains = ", ".join(ap.get("chains_to", []))
        row_vals = [
            i - 2,
            ap.get("title", ""),
            sev,
            ap.get("risk_score", ""),
            steps[0] if len(steps) > 0 else "",
            steps[1] if len(steps) > 1 else "",
            steps[2] if len(steps) > 2 else "",
            steps[3] if len(steps) > 3 else "",
            chains or "--",
        ]
        for j, val in enumerate(row_vals, 1):
            cell = ws.cell(row=i, column=j, value=val)
            cell.border    = _bdr()
            cell.font      = Font(name="Calibri", size=9, color=C_BLK)
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
            if j == 3:
                cell.fill = SEV_FILL.get(sev, _fill(bg))
                cell.font = SEV_FONT.get(sev, _font(color=C_BLK))
                cell.alignment = _ctr()
            else:
                cell.fill = _fill(bg)
        ws.row_dimensions[i].height = 28



# ── Shared intelligence helpers ──────────────────────────────────────────────
LATEST_SUMMARY_KEYS = [
    "sbom_summary", "cbom_summary", "ai_bom_summary", "ml_bom_summary",
    "api_bom_summary", "abom_summary", "iac_summary", "kubernetes_iac_summary",
    "terraform_iac_summary", "dockerfile_iac_summary", "reachability_summary",
    "kev_intelligence_summary", "epss_intelligence_summary",
    "exploitability_decision_summary", "license_policy_summary",
    "copyright_ip_compliance_summary", "supply_chain_trust_summary",
    "runtime_artifact_integrity_summary", "data_flow_sensitivity_summary",
    "data_flow_correlation_summary", "identity_access_risk_summary",
    "identity_access_correlation_summary", "auth_hardening_risk_summary",
    "auth_hardening_correlation_summary", "ai_model_risk_summary",
    "business_logic_risk_summary", "business_logic_correlation_summary",
    "api_abuse_risk_summary", "security_control_coverage_summary",
    "crypto_misuse_summary", "secret_intelligence_summary",
    "secret_blast_radius_correlation_summary", "framework_enrichment_summary",
    "governance_signal_summary", "release_readiness_summary",
    "executive_decision_summary",
]

def _jsonish(value):
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple, set)):
        import json
        return json.dumps(value, ensure_ascii=False, default=str)
    return str(value)

def _latest_summary_items(payload):
    items = []
    meta = payload.get("metadata", {}) or {}
    for key in LATEST_SUMMARY_KEYS:
        value = payload.get(key)
        if value in (None, {}, [], ""):
            value = meta.get(key)
        if value not in (None, {}, [], ""):
            items.append((key, value))
    # Pick up future engines without another report patch.
    for key in sorted(k for k in payload.keys() if k.endswith("_summary") and k not in dict(items)):
        value = payload.get(key)
        if value not in (None, {}, [], ""):
            items.append((key, value))
    return items

def _latest_results(ws, payload):
    ws.title = "Latest Results"
    widths = [34, 26, 90]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    _title_row(ws, "LATEST ENGINE RESULTS — SOURCE CODE REVIEW DECISION GRAPH", 3)
    _hdr(ws, 2, ["Engine", "Status / Key Signal", "Full Summary"])
    ws.freeze_panes = "A3"
    r = 3
    for key, value in _latest_summary_items(payload):
        status = ""
        if isinstance(value, dict):
            status = str(value.get("summary_status") or value.get("status") or value.get("decision") or value.get("executive_decision") or value.get("release_decision") or "")
        vals = [key.replace("_summary", "").replace("_", " ").title(), status, _jsonish(value)]
        bg = C_LBLUE if r % 2 == 0 else C_WHT
        for cidx, val in enumerate(vals, 1):
            c = ws.cell(row=r, column=cidx, value=val)
            c.border = _bdr(); c.font = Font(name="Calibri", size=9, color=C_BLK)
            c.alignment = _lft(); c.fill = _fill(bg)
        ws.row_dimensions[r].height = 42
        r += 1
    if r == 3:
        ws.merge_cells("A3:C3")
        c = ws["A3"]; c.value = "No latest engine summary blocks were found in payload."
        c.font = _font(color=C_BLK); c.alignment = _lft(); c.fill = _fill(C_GRY)


def _executive_kpis(ws, payload):
    ws.title = "Executive KPIs"
    for i, w in enumerate([32, 18, 70], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    _title_row(ws, "EXECUTIVE RISK KPIS — BUSINESS AND REGULATORY EXPOSURE", 3)
    _hdr(ws, 2, ["KPI", "Value", "Interpretation"])
    grouped = payload.get("grouped", []) or []
    total = max(len(grouped), 1)
    def pct(n): return f"{round((n/total)*100, 1)}%"
    exploitable = sum(1 for f in grouped if str(f.get("exploitability", "")).lower() == "high" or f.get("taint_path"))
    cred = sum(1 for f in grouped if any(x in str(f.get("title","")).lower()+str(f.get("vuln_type","")).lower() for x in ["secret", "credential", "password", "token", "api key"]))
    auth = sum(1 for f in grouped if any(x in str(f.get("title","")).lower()+str(f.get("vuln_type","")).lower() for x in ["auth", "jwt", "idor", "permission", "role"]))
    breach = sum(1 for f in grouped if any(x in str(f.get("business_impact","")).lower()+str(f.get("title","")).lower() for x in ["data breach", "exfiltration", "pii", "sensitive", "database"]))
    privacy, ioc = _supplemental_counts(payload)
    rows = [
        ("Exploitable / High-confidence Risk", pct(exploitable), "Findings with taint validation, high exploitability, or directly exploitable behavior."),
        ("Credential-related Risk", pct(cred), "Secrets, tokens, passwords, API keys, or credential exposure patterns."),
        ("Auth / Access-control Risk", pct(auth), "Authentication, authorization, JWT, IDOR, role, and permission issues."),
        ("Data Breach Capable Risk", pct(breach), "Findings that can plausibly lead to sensitive data disclosure or exfiltration."),
        ("Privacy Indicators", privacy, "Supplemental PII/privacy findings detected by privacy intelligence."),
        ("IOC / Backdoor Indicators", ioc, "Supplemental malicious-behavior or backdoor-like source-code indicators."),
        ("Financial / Operational Exposure", "High" if payload.get("metadata",{}).get("risk_score",0) >= 60 else "Medium", "Based on portfolio risk, critical findings, attack paths, privacy exposure, and IOC indicators."),
        ("Regulatory Exposure", "High" if privacy or cred or breach else "Medium", "Potential exposure to PCI, GDPR/DPDP-style privacy obligations, SOC2, ISO 27001, and NIST controls."),
    ]
    for r, row in enumerate(rows, 3):
        bg = C_LBLUE if r % 2 == 0 else C_WHT
        for cidx, val in enumerate(row, 1):
            c = ws.cell(r, cidx, val); c.border = _bdr(); c.alignment = _lft(); c.font = Font(name="Calibri", size=9, color=C_BLK); c.fill = _fill(bg)
        ws.row_dimensions[r].height = 34

def _release_readiness(ws, payload):
    ws.title = "Release Readiness"
    for i, w in enumerate([28, 30, 80], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    _title_row(ws, "RELEASE READINESS — GOVERNANCE DECISION", 3)
    _hdr(ws, 2, ["Decision Area", "Value", "Evidence"])
    meta = payload.get("metadata", {}) or {}
    rel = payload.get("release_readiness_summary", {}) or payload.get("release_readiness", {}) or {}
    exe = payload.get("executive_decision_summary", {}) or payload.get("executive_decision", {}) or {}
    gov = payload.get("governance_signal_summary", {}) or {}
    rows = [
        ("Portfolio Risk Score", meta.get("risk_score", ""), meta.get("risk_score_model", "")),
        ("Release Decision", rel.get("release_decision") or rel.get("decision") or meta.get("release_decision", ""), rel),
        ("Executive Decision", exe.get("executive_decision") or exe.get("decision") or meta.get("executive_decision", ""), exe),
        ("Governance Signals", gov.get("summary_status") or gov.get("status") or "", gov),
        ("Blocking Gates", rel.get("blocking_gates") or rel.get("total_blocking_gates") or "", rel.get("blocking_gate_reasons") or rel.get("gates") or ""),
        ("Review Gates", rel.get("review_gates") or rel.get("total_review_gates") or "", rel.get("review_gate_reasons") or ""),
    ]
    for r, vals in enumerate(rows, 3):
        bg = C_LBLUE if r % 2 == 0 else C_WHT
        for cidx, val in enumerate(vals, 1):
            c = ws.cell(row=r, column=cidx, value=_jsonish(val))
            c.border = _bdr(); c.font = Font(name="Calibri", size=9, color=C_BLK)
            c.alignment = _lft(); c.fill = _fill(bg)

def _technical_evidence(ws, payload):
    ws.title = "Technical Evidence"
    headers = ["#", "Type", "Severity", "File", "Line", "Evidence", "Correlation / Blast Radius", "Detection Source", "Engine Name", "Evidence Confidence", "Data Classification", "Primary Root Cause"]
    widths = [5, 26, 12, 38, 8, 70, 70, 24, 24, 18, 18, 28]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    _title_row(ws, "TECHNICAL EVIDENCE — LATEST RAW FINDINGS", len(headers))
    _hdr(ws, 2, headers)
    ws.freeze_panes = "A3"
    findings = payload.get("findings") or payload.get("grouped") or []
    for i, f in enumerate(findings, 3):
        sev = f.get("severity", "")
        row = [i-2, f.get("vuln_type") or f.get("rule_id") or f.get("title", ""), sev,
               f.get("file") or f.get("file_path") or "", f.get("line", ""),
               f.get("snippet") or f.get("evidence") or f.get("description") or "",
               f.get("taint_path") or f.get("blast_radius") or f.get("correlation_evidence") or "",
               _display_detection(f), _engine_name(f), _evidence_confidence(f), _classify_data(f), _root_cause_id(f)]
        bg = C_LBLUE if i % 2 == 0 else C_WHT
        for cidx, val in enumerate(row, 1):
            c = ws.cell(row=i, column=cidx, value=_jsonish(val))
            c.border = _bdr(); c.font = Font(name="Calibri", size=9, color=C_BLK)
            c.alignment = _lft(); c.fill = _fill(bg)
            if cidx == 3:
                c.fill = SEV_FILL.get(sev, _fill(bg)); c.font = SEV_FONT.get(sev, _font(color=C_BLK)); c.alignment = _ctr()
        ws.row_dimensions[i].height = 36

# ── Exploitable CVEs / Advisories ─────────────────────────────────────────────
def _exploitable_cves(ws, payload):
    ws.title = "Exploitable CVEs"
    headers = [
        "#", "Package", "Version", "Dependency Type", "CVE / Advisory", "CVSS", "EPSS",
        "KEV", "Reachable Vulnerable", "Exploitability Decision", "Patch Urgency",
        "Fixed In", "Evidence / Reason",
    ]
    widths = [4, 24, 14, 16, 30, 8, 8, 8, 18, 24, 16, 18, 52]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    _title_row(ws, "TOP REACHABLE / EXPLOITABLE CVES AND ADVISORIES", len(headers))
    _hdr(ws, 2, headers)
    ws.freeze_panes = "A3"

    rows = []
    for pkg in payload.get("sbom", []) or []:
        cves = _pkg_cve_list(pkg)
        if not cves or not _is_exploitable_dependency(pkg):
            continue
        reasons = []
        if _is_reachable_vulnerable(pkg):
            reasons.append("reachable vulnerable")
        if pkg.get("kev_status"):
            reasons.append("CISA KEV")
        if str(pkg.get("epss_priority") or "").upper() == "P0_IMMEDIATE":
            reasons.append("EPSS P0")
        if str(pkg.get("patch_urgency") or "").upper() == "IMMEDIATE":
            reasons.append("immediate patch")
        rows.append((pkg, reasons))

    if not rows:
        ws.merge_cells(f"A3:{get_column_letter(len(headers))}3")
        c = ws["A3"]
        c.value = "No reachable/KEV/EPSS-prioritized exploitable dependency CVEs were identified in this scan. Code-level findings may still be exploitable and are listed in Findings/Attack Paths."
        c.font = _font(color=C_BLK); c.fill = _fill(C_GRY); c.alignment = _lft(); c.border = _bdr()
        return

    for r, (pkg, reasons) in enumerate(rows, start=3):
        bg = C_LBLUE if r % 2 == 0 else C_WHT
        vals = [
            r - 2,
            pkg.get("name", ""),
            pkg.get("version", ""),
            pkg.get("dependency_type") or pkg.get("type", ""),
            ", ".join(_pkg_cve_list(pkg)[:6]),
            _fmt_float(_first_value(pkg, "cvss", "cvss_score", default="--"), 1),
            _fmt_float(_first_value(pkg, "epss_score", "epss", default="--"), 3),
            "Yes" if pkg.get("kev_status") else "No",
            "Yes" if _is_reachable_vulnerable(pkg) else "No",
            _first_value(pkg, "exploitability_decision", "exploitability_action", default="Review"),
            _first_value(pkg, "patch_urgency", "epss_priority", default="--"),
            _first_value(pkg, "fixed_in", "fixed_versions", default="Unknown"),
            "; ".join(reasons) or "dependency vulnerability requires review",
        ]
        for cidx, val in enumerate(vals, 1):
            cell = ws.cell(row=r, column=cidx, value=_jsonish(val) if '_jsonish' in globals() else str(val))
            cell.border = _bdr(); cell.font = Font(name="Calibri", size=9, color=C_BLK)
            cell.alignment = _lft(); cell.fill = _fill(bg)
            if cidx in {8, 9} and val == "Yes":
                cell.fill = _fill("FFE5E5"); cell.alignment = _ctr()
        ws.row_dimensions[r].height = 30



# ── Privacy / IOC Intelligence ───────────────────────────────────────────────
def _privacy_findings(ws, payload):
    ws.title = "Privacy Findings"
    _title(ws, "Privacy / PII Exposure Findings")
    summary = payload.get("privacy_data_exposure_summary", {}) or {}
    rows = summary.get("indicators", []) or []
    meta = [
        ("Status", summary.get("summary_status", "NOT_AVAILABLE")),
        ("Total Privacy Indicators", summary.get("total_privacy_indicators", 0)),
        ("Critical Privacy Indicators", summary.get("critical_privacy_indicators", 0)),
        ("High Privacy Indicators", summary.get("high_privacy_indicators", 0)),
        ("Third-Party Transfer Indicators", summary.get("third_party_transfer_indicators", 0)),
        ("Engine Mode", summary.get("engine_mode", "STATIC_PRIVACY_PATTERN_AND_CONTEXT_ANALYSIS_V1")),
    ]
    r = 3
    for k, v in meta:
        ws.cell(r, 1, k).fill = _fill(C_NAVY); ws.cell(r, 1).font = _font(True); ws.cell(r, 1).alignment = _lft(); ws.cell(r, 1).border = _bdr()
        ws.cell(r, 2, _jsonish(v)).fill = _fill(C_LBLUE); ws.cell(r, 2).font = Font(name="Calibri", size=10, color=C_BLK); ws.cell(r, 2).alignment = _lft(); ws.cell(r, 2).border = _bdr()
        r += 1
    r += 1
    headers = ["#", "Risk", "Indicator", "PII Types", "Data Classification", "Evidence Confidence", "File", "Line", "Third Party", "Description", "Evidence", "Recommended Actions", "Frameworks"]
    _hdr(ws, r, headers); r += 1
    if not rows:
        ws.cell(r, 1, "No privacy / PII exposure indicators identified."); return
    for idx, item in enumerate(rows, 1):
        bg = C_LBLUE if idx % 2 == 0 else C_WHT
        vals = [
            idx,
            item.get("risk_level") or item.get("severity", ""),
            item.get("indicator", ""),
            ", ".join(item.get("pii_types") or []),
            _classify_data(item),
            _evidence_confidence({**item, "detection": "Privacy Heuristic"}),
            item.get("file", ""),
            item.get("line", ""),
            "Yes" if item.get("third_party_transfer_hint") else "No",
            item.get("description", ""),
            item.get("snippet", ""),
            "\n".join(item.get("recommended_actions") or []),
            _jsonish(item.get("framework_mappings", {})),
        ]
        for c, val in enumerate(vals, 1):
            cell = ws.cell(r, c, _jsonish(val)); cell.border = _bdr(); cell.alignment = _lft(); cell.font = Font(name="Calibri", size=9, color=C_BLK); cell.fill = _fill(bg)
            if c == 2 and str(val).upper() in {"CRITICAL", "HIGH"}:
                cell.fill = _fill(C_RED if str(val).upper() == "CRITICAL" else C_ORG); cell.font = _font(True)
        ws.row_dimensions[r].height = 45
        r += 1
    for col in range(1, len(headers)+1):
        ws.column_dimensions[get_column_letter(col)].width = 22
    ws.column_dimensions['K'].width = 45
    ws.column_dimensions['L'].width = 55


def _ioc_malware_findings(ws, payload):
    ws.title = "IOC Malware"
    _title(ws, "IOC / Backdoor / Malware Heuristic Indicators")
    summary = payload.get("ioc_malware_intelligence_summary", {}) or {}
    rows = summary.get("indicators", []) or []
    meta = [
        ("Status", summary.get("summary_status", "NOT_AVAILABLE")),
        ("Total IOC Indicators", summary.get("total_ioc_indicators", 0)),
        ("Critical IOC Indicators", summary.get("critical_ioc_indicators", 0)),
        ("High IOC Indicators", summary.get("high_ioc_indicators", 0)),
        ("Malware Behavior Indicators", summary.get("malware_behavior_indicators", 0)),
        ("Suspicious Domains Observed", ", ".join(summary.get("suspicious_domains", [])[:20])),
        ("Public IPs Observed", ", ".join(summary.get("public_ips", [])[:20])),
        ("Engine Mode", summary.get("engine_mode", "STATIC_IOC_BACKDOOR_HEURISTIC_ANALYSIS_V1_OFFLINE")),
    ]
    r = 3
    for k, v in meta:
        ws.cell(r, 1, k).fill = _fill(C_NAVY); ws.cell(r, 1).font = _font(True); ws.cell(r, 1).alignment = _lft(); ws.cell(r, 1).border = _bdr()
        ws.cell(r, 2, _jsonish(v)).fill = _fill(C_LBLUE); ws.cell(r, 2).font = Font(name="Calibri", size=10, color=C_BLK); ws.cell(r, 2).alignment = _lft(); ws.cell(r, 2).border = _bdr()
        r += 1
    r += 1
    headers = ["#", "Risk", "Indicator", "IOC Type", "IOC Value", "MITRE", "Data Classification", "Evidence Confidence", "File", "Line", "Description", "Evidence", "Recommended Actions", "Confidence"]
    _hdr(ws, r, headers); r += 1
    if not rows:
        ws.cell(r, 1, "No IOC / backdoor / malware heuristic indicators identified."); return
    for idx, item in enumerate(rows, 1):
        bg = C_LBLUE if idx % 2 == 0 else C_WHT
        vals = [
            idx,
            item.get("risk_level") or item.get("severity", ""),
            item.get("indicator", ""),
            item.get("ioc_type", ""),
            item.get("ioc_value", ""),
            item.get("mitre_attack", ""),
            _classify_data(item),
            _evidence_confidence({**item, "detection": "IOC Heuristic"}),
            item.get("file", ""),
            item.get("line", ""),
            item.get("description", ""),
            item.get("snippet", ""),
            "\n".join(item.get("recommended_actions") or []),
            item.get("confidence", ""),
        ]
        for c, val in enumerate(vals, 1):
            cell = ws.cell(r, c, _jsonish(val)); cell.border = _bdr(); cell.alignment = _lft(); cell.font = Font(name="Calibri", size=9, color=C_BLK); cell.fill = _fill(bg)
            if c == 2 and str(val).upper() in {"CRITICAL", "HIGH"}:
                cell.fill = _fill(C_RED if str(val).upper() == "CRITICAL" else C_ORG); cell.font = _font(True)
        ws.row_dimensions[r].height = 45
        r += 1
    for col in range(1, len(headers)+1):
        ws.column_dimensions[get_column_letter(col)].width = 22
    ws.column_dimensions['L'].width = 45
    ws.column_dimensions['M'].width = 55

# ── Public interface ──────────────────────────────────────────────────────────
def _save_workbook(wb: Workbook, output_path: str) -> str:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(path))
    return str(path)


def generate_excel_report(payload: dict, output_path: str) -> str:
    """Combined workbook: executive + technical sheets using existing theme."""
    wb = Workbook()
    wb.remove(wb.active)
    _summary(wb.create_sheet("Summary"),          payload)
    _executive_kpis(wb.create_sheet("Executive KPIs"), payload)
    _release_readiness(wb.create_sheet("Release Readiness"), payload)
    _latest_results(wb.create_sheet("Latest Results"), payload)
    _findings(wb.create_sheet("Findings"),         payload)
    _technical_evidence(wb.create_sheet("Technical Evidence"), payload)
    _exploitable_cves(wb.create_sheet("Exploitable CVEs"), payload)
    _privacy_findings(wb.create_sheet("Privacy Findings"), payload)
    _ioc_malware_findings(wb.create_sheet("IOC Malware"), payload)
    _sbom(wb.create_sheet("SBOM"),                 payload)
    _attack_paths(wb.create_sheet("Attack Paths"), payload)
    return _save_workbook(wb, output_path)


def generate_executive_excel_report(payload: dict, output_path: str) -> str:
    """Executive workbook with decision, release, and latest engine summaries."""
    wb = Workbook()
    wb.remove(wb.active)
    _summary(wb.create_sheet("Summary"), payload)
    _executive_kpis(wb.create_sheet("Executive KPIs"), payload)
    _release_readiness(wb.create_sheet("Release Readiness"), payload)
    _latest_results(wb.create_sheet("Latest Results"), payload)
    _exploitable_cves(wb.create_sheet("Exploitable CVEs"), payload)
    _privacy_findings(wb.create_sheet("Privacy Findings"), payload)
    _ioc_malware_findings(wb.create_sheet("IOC Malware"), payload)
    _attack_paths(wb.create_sheet("Attack Paths"), payload)
    return _save_workbook(wb, output_path)


def generate_technical_excel_report(payload: dict, output_path: str) -> str:
    """Technical workbook for engineers and security analysts."""
    wb = Workbook()
    wb.remove(wb.active)
    _findings(wb.create_sheet("Findings"), payload)
    _technical_evidence(wb.create_sheet("Technical Evidence"), payload)
    _exploitable_cves(wb.create_sheet("Exploitable CVEs"), payload)
    _privacy_findings(wb.create_sheet("Privacy Findings"), payload)
    _ioc_malware_findings(wb.create_sheet("IOC Malware"), payload)
    _sbom(wb.create_sheet("SBOM"), payload)
    _latest_results(wb.create_sheet("Latest Results"), payload)
    _attack_paths(wb.create_sheet("Attack Paths"), payload)
    return _save_workbook(wb, output_path)


# Backward-compatible aliases
write_excel_report = generate_excel_report
