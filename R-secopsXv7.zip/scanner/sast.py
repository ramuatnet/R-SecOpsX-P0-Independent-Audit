"""
scanner/sast.py
R-SecOpsX enterprise SAST regex layer.

Backward compatible public API:
- scan_file(filepath) -> list[dict]
- scan_directory(target_path, workers=2) -> list[dict]
- summarize_enterprise_controls(findings) -> dict

This file intentionally keeps high-risk pattern checks here and leaves source-to-sink
validation to scanner/taint_engine.py. Offline static analysis only.
"""
from __future__ import annotations

import re
from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    from core.mapper import get_mapping
except Exception:  # fallback for standalone compile/use
    def get_mapping(vuln_type: str) -> dict:
        return {}

try:
    from core.deduplicator import group_findings
except Exception:
    def group_findings(findings: list[dict]) -> list[dict]:
        seen: set[str] = set()
        out: list[dict] = []
        for f in findings:
            k = f.get("group_key") or f"{f.get('rule_id')}|{f.get('file')}|{f.get('line')}|{f.get('snippet')}"
            if k not in seen:
                seen.add(k)
                out.append(f)
        return out

_F = re.IGNORECASE | re.MULTILINE | re.DOTALL

SCANNABLE_EXT = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".kt", ".scala", ".go",
    ".rb", ".php", ".cs", ".vb", ".cpp", ".c", ".h", ".hpp", ".sh",
    ".env", ".yml", ".yaml", ".properties", ".xml", ".json", ".graphql", ".gql",
    ".gradle", ".csproj", ".config", ".tf", ".Dockerfile", "Dockerfile",
}
EXCLUDED_DIRS = {
    ".git", ".svn", "node_modules", "__pycache__", ".tox", "venv", ".venv",
    "env", ".env", "dist", "build", ".cache", "vendor", "third_party", "migrations",
}

LANG_BY_EXT = {
    ".py": "python", ".js": "javascript", ".jsx": "javascript", ".ts": "typescript", ".tsx": "typescript",
    ".java": "java", ".kt": "kotlin", ".scala": "scala", ".go": "go", ".php": "php",
    ".cs": "csharp", ".vb": "vbnet", ".xml": "xml", ".properties": "properties",
    ".yml": "yaml", ".yaml": "yaml", ".json": "json", ".graphql": "graphql", ".gql": "graphql",
}

BASE_REMEDIATION = {
    "xxe": ["Disable DTD and external entity resolution in XML parsers.", "Use safe parser factories with secure processing enabled.", "Reject untrusted XML or convert to JSON where possible."],
    "insecure_deserialization": ["Do not deserialize untrusted data.", "Use safe serializers and strict type allow-lists.", "Authenticate and integrity-protect serialized payloads."],
    "tls_bypass": ["Never disable certificate or hostname validation.", "Use platform trust stores and certificate pinning where appropriate.", "Fail closed on TLS validation errors."],
    "open_redirect": ["Validate redirect destinations against a server-side allow-list.", "Prefer relative redirects.", "Reject user-controlled absolute URLs."],
    "log_injection": ["Normalize CR/LF and control characters before logging.", "Use structured logging and encode untrusted fields.", "Avoid logging secrets or raw request payloads."],
    "zipslip": ["Canonicalize extracted paths and enforce destination directory containment.", "Reject entries containing .. or absolute paths.", "Use safe extraction helpers."],
    "redos": ["Rewrite catastrophic regex patterns using bounded quantifiers or safe regex engines.", "Avoid building RegExp from user input.", "Add input length limits and timeouts."],
    "mass_assignment": ["Bind request bodies to explicit DTOs, not persistence/domain entities.", "Use allow-listed fields and validation annotations.", "Reject privileged fields such as role, tenantId, isAdmin, status."],
    "dangerous_reflection": ["Avoid bypassing access checks through reflection.", "Do not call setAccessible(true) on user-influenced classes or members.", "Use explicit allow-lists for reflective operations."],
    "template_injection": ["Do not evaluate user-controlled templates.", "Use safe template contexts and escaping.", "Separate template names from template content."],
    "graphql_exposure": ["Disable GraphQL introspection in production unless explicitly required.", "Require authentication and authorization on GraphQL endpoints.", "Add query depth, complexity and rate limits."],
    "resource_exhaustion": ["Enforce body size, upload size, query depth and timeout limits.", "Stream large inputs instead of unbounded reads.", "Apply rate limits to expensive operations."],
    "race_condition": ["Protect shared mutable state with locks/transactions.", "Use idempotency keys for duplicate actions.", "Make check-and-act operations atomic."],
    "api_rate_limit": ["Add per-user, per-IP and per-tenant rate limits.", "Throttle login, OTP, reset, payment and invite endpoints.", "Monitor abuse and lock suspicious workflows."],
}

def _priority(sev: str) -> str:
    return {"Critical": "P1", "High": "P2", "Medium": "P3", "Low": "P4"}.get(sev, "P3")

ENTERPRISE_RULES: list[dict] = [
    # Java / Spring Boot
    {"id":"JAVA_OBJECTINPUTSTREAM_DESERIALIZATION","title":"Java ObjectInputStream Insecure Deserialization","vuln":"insecure_deserialization","sev":"Critical","langs":["java"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"new\s+ObjectInputStream\s*\(|\.readObject\s*\("},
    {"id":"JAVA_JACKSON_DEFAULT_TYPING","title":"Jackson Unsafe Default Typing","vuln":"insecure_deserialization","sev":"Critical","langs":["java"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"enableDefaultTyping\s*\(|activateDefaultTyping\s*\(|DefaultTyping\.|@JsonTypeInfo"},
    {"id":"JAVA_SNAKEYAML_UNSAFE_LOAD","title":"SnakeYAML Unsafe Load","vuln":"insecure_deserialization","sev":"Critical","langs":["java"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"new\s+Yaml\s*\([^)]*\)\s*\.load\s*\(|Yaml\s+\w+\s*=\s*new\s+Yaml\s*\([^)]*\)"},
    {"id":"JAVA_XSTREAM_DESERIALIZATION","title":"XStream Insecure Deserialization","vuln":"insecure_deserialization","sev":"Critical","langs":["java"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"new\s+XStream\s*\(|\.fromXML\s*\("},
    {"id":"JAVA_JNDI_LOG4SHELL_LOOKUP","title":"JNDI / Log4Shell-style Lookup Pattern","vuln":"jndi_injection","sev":"Critical","langs":["java","properties","xml","yaml"],"cwe":"CWE-917","owasp":"A03:2021 - Injection","pat":r"\$\{\s*jndi\s*:\s*(?:ldap|rmi|dns|iiop)://|InitialContext\s*\(|\.lookup\s*\("},
    {"id":"JAVA_JDBC_SQL_CONCAT","title":"JDBC SQL Concatenation","vuln":"sql_injection","sev":"High","langs":["java"],"cwe":"CWE-89","owasp":"A03:2021 - Injection","pat":r"(?:createStatement\s*\(\s*\)|prepareStatement\s*\(\s*\"[^\"]*\"\s*\+|executeQuery\s*\(\s*\"[^\"]*\"\s*\+)"},
    {"id":"JAVA_HQL_JPQL_INJECTION","title":"Hibernate HQL / JPQL Injection","vuln":"orm_injection","sev":"High","langs":["java"],"cwe":"CWE-89","owasp":"A03:2021 - Injection","pat":r"createQuery\s*\(\s*\"[^\"]*(?:from|select|where)[^\"]*\"\s*\+|@Query\s*\(\s*\"[^\"]*\"\s*\+"},
    {"id":"JAVA_JOOQ_RAW_SQL","title":"jOOQ Raw SQL Injection Indicator","vuln":"orm_injection","sev":"High","langs":["java"],"cwe":"CWE-89","owasp":"A03:2021 - Injection","pat":r"DSL\.query\s*\(\s*\"[^\"]*\"\s*\+|fetch\s*\(\s*\"[^\"]*\"\s*\+"},
    {"id":"JAVA_XXE_PARSER","title":"Java XML Parser XXE Risk","vuln":"xxe","sev":"High","langs":["java"],"cwe":"CWE-611","owasp":"A05:2021 - Security Misconfiguration","pat":r"DocumentBuilderFactory\.newInstance\s*\(|SAXParserFactory\.newInstance\s*\(|XMLInputFactory\.newInstance\s*\(|SAXReader\s*\("},
    {"id":"JAVA_REFLECTION_SETACCESSIBLE","title":"Dangerous Reflection setAccessible(true)","vuln":"dangerous_reflection","sev":"High","langs":["java"],"cwe":"CWE-470","owasp":"A01:2021 - Broken Access Control","pat":r"\.setAccessible\s*\(\s*true\s*\)"},
    {"id":"JAVA_PATH_TRAVERSAL_FILE","title":"Java Path Traversal File Access","vuln":"path_traversal","sev":"High","langs":["java"],"cwe":"CWE-22","owasp":"A01:2021 - Broken Access Control","pat":r"new\s+File\s*\([^)]*(?:request|getParameter|path|filename)|Paths\.get\s*\([^)]*(?:request|getParameter|path|filename)"},
    {"id":"JAVA_TLS_TRUST_BYPASS","title":"Java TLS TrustManager / HostnameVerifier Bypass","vuln":"tls_bypass","sev":"Critical","langs":["java"],"cwe":"CWE-295","owasp":"A02:2021 - Cryptographic Failures","pat":r"X509TrustManager|HostnameVerifier|verify\s*\([^)]*\)\s*\{\s*return\s+true|checkServerTrusted\s*\([^)]*\)\s*\{\s*\}"},
    {"id":"SPRING_SPEL_INJECTION","title":"Spring SpEL Injection Indicator","vuln":"spel_injection","sev":"Critical","langs":["java"],"cwe":"CWE-94","owasp":"A03:2021 - Injection","pat":r"SpelExpressionParser|parseExpression\s*\([^)]*(?:request|getParameter|input|param)"},
    {"id":"SPRING_MASS_ASSIGNMENT_ENTITY_BINDING","title":"Spring MVC Mass Assignment Entity Binding","vuln":"mass_assignment","sev":"High","langs":["java"],"cwe":"CWE-915","owasp":"A01:2021 - Broken Access Control","pat":r"@(RequestBody|ModelAttribute)\s+(?:User|Account|Admin|Role|Customer|Order|.*Entity)\b"},
    {"id":"SPRING_SECURITY_CSRF_DISABLED","title":"Spring Security CSRF Disabled","vuln":"auth_misconfiguration","sev":"Critical","langs":["java"],"cwe":"CWE-352","owasp":"A01:2021 - Broken Access Control","pat":r"csrf\s*\(\s*\)\s*\.disable\s*\(|csrf\s*\(\s*csrf\s*->\s*csrf\.disable\s*\("},
    {"id":"SPRING_PERMITALL_BROAD_MATCHER","title":"Spring Security Broad permitAll Exposure","vuln":"auth_misconfiguration","sev":"Critical","langs":["java"],"cwe":"CWE-284","owasp":"A01:2021 - Broken Access Control","pat":r"(?:antMatchers|requestMatchers)\s*\([^)]*(?:/\*\*|\*)[^)]*\)\s*\.permitAll\s*\("},
    {"id":"SPRING_ACTUATOR_EXPOSE_ALL","title":"Spring Actuator All Endpoints Exposed","vuln":"actuator_exposure","sev":"Critical","langs":["properties","yaml","java"],"cwe":"CWE-200","owasp":"A05:2021 - Security Misconfiguration","pat":r"management\.endpoints\.web\.exposure\.include\s*=\s*\*|exposure:\s*\n\s*include:\s*[\"']?\*[\"']?"},
    {"id":"SPRING_MULTIPART_TRAVERSAL","title":"Spring MultipartFile Unsafe Upload Path","vuln":"path_traversal","sev":"High","langs":["java"],"cwe":"CWE-22","owasp":"A01:2021 - Broken Access Control","pat":r"MultipartFile|getOriginalFilename\s*\(\s*\)|transferTo\s*\(\s*new\s+File"},
    {"id":"SPRING_ASYNC_CONTEXT_LOSS","title":"Spring @Async Security Context Loss Indicator","vuln":"async_security_context_loss","sev":"High","langs":["java"],"cwe":"CWE-362","owasp":"A04:2021 - Insecure Design","pat":r"@Async(?![\s\S]{0,250}(DelegatingSecurityContext|SecurityContextHolder))"},
    {"id":"SPRING_CACHEABLE_USER_KEY","title":"Spring @Cacheable User-Controlled Key","vuln":"cache_key_injection","sev":"Medium","langs":["java"],"cwe":"CWE-20","owasp":"A04:2021 - Insecure Design","pat":r"@Cacheable\s*\([^)]*key\s*=\s*[\"'][^\"']*#(?:user|request|param|id)"},
    {"id":"JAVA_TEMPLATE_INJECTION","title":"Java Template Injection Indicator","vuln":"template_injection","sev":"High","langs":["java"],"cwe":"CWE-94","owasp":"A03:2021 - Injection","pat":r"TemplateEngine\.process\s*\([^)]*(?:request|getParameter)|Freemarker|VelocityEngine|StringTemplateResolver"},
    {"id":"SPRING_WEBFLUX_AUTH_GAP","title":"Spring WebFlux Authorization Propagation Gap","vuln":"auth_misconfiguration","sev":"High","langs":["java"],"cwe":"CWE-284","owasp":"A01:2021 - Broken Access Control","pat":r"RouterFunctions\.route\s*\(|SecurityWebFilterChain|authorizeExchange\s*\(\s*\)\s*\.anyExchange\s*\(\s*\)\s*\.permitAll"},
    {"id":"SPRING_MISSING_VALIDATION","title":"Spring Missing @Valid / @Validated Indicator","vuln":"missing_validation","sev":"Medium","langs":["java"],"cwe":"CWE-20","owasp":"A04:2021 - Insecure Design","pat":r"@(PostMapping|PutMapping|PatchMapping)[\s\S]{0,250}@(RequestBody|ModelAttribute)(?![\s\S]{0,80}@(?:Valid|Validated))"},

    # C# / .NET
    {"id":"DOTNET_BINARYFORMATTER","title":".NET BinaryFormatter Deserialization","vuln":"insecure_deserialization","sev":"Critical","langs":["csharp"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"BinaryFormatter\s*\(|\.Deserialize\s*\("},
    {"id":"DOTNET_TYPENAMEHANDLING","title":"Json.NET TypeNameHandling Unsafe","vuln":"insecure_deserialization","sev":"Critical","langs":["csharp"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"TypeNameHandling\s*=\s*TypeNameHandling\.(?:All|Auto|Objects|Arrays)"},
    {"id":"DOTNET_DATACONTRACT_DESERIALIZER","title":"DataContractSerializer Unsafe Deserialization","vuln":"insecure_deserialization","sev":"High","langs":["csharp"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"DataContractSerializer\s*\(|NetDataContractSerializer\s*\("},
    {"id":"DOTNET_ADO_SQL_CONCAT","title":"ADO.NET SQL Concatenation","vuln":"sql_injection","sev":"High","langs":["csharp"],"cwe":"CWE-89","owasp":"A03:2021 - Injection","pat":r"SqlCommand\s*\(\s*\"[^\"]*\"\s*\+|CommandText\s*=\s*\"[^\"]*\"\s*\+"},
    {"id":"DOTNET_EF_FROMSQLRAW_INTERPOLATION","title":"Entity Framework FromSqlRaw Interpolation","vuln":"orm_injection","sev":"High","langs":["csharp"],"cwe":"CWE-89","owasp":"A03:2021 - Injection","pat":r"FromSqlRaw\s*\(\s*\$\"|FromSqlRaw\s*\([^)]*\+"},
    {"id":"DOTNET_XXE_DTD_PROCESSING","title":".NET XML DTD Processing / XXE","vuln":"xxe","sev":"High","langs":["csharp"],"cwe":"CWE-611","owasp":"A05:2021 - Security Misconfiguration","pat":r"DtdProcessing\s*=\s*DtdProcessing\.Parse|XmlResolver\s*=\s*new\s+XmlUrlResolver|XmlDocument\s*\("},
    {"id":"DOTNET_PATH_COMBINE_TRAVERSAL","title":".NET Path.Combine Traversal Indicator","vuln":"path_traversal","sev":"High","langs":["csharp"],"cwe":"CWE-22","owasp":"A01:2021 - Broken Access Control","pat":r"Path\.Combine\s*\([^)]*(?:Request|Query|Form|Route|file|path|name)"},
    {"id":"DOTNET_ZIPSLIP_EXTRACT","title":".NET ZipSlip Extraction Risk","vuln":"zipslip","sev":"High","langs":["csharp"],"cwe":"CWE-22","owasp":"A01:2021 - Broken Access Control","pat":r"ZipFile\.ExtractToDirectory\s*\("},
    {"id":"DOTNET_OVERPOSTING","title":"ASP.NET Mass Assignment / Overposting","vuln":"mass_assignment","sev":"High","langs":["csharp"],"cwe":"CWE-915","owasp":"A01:2021 - Broken Access Control","pat":r"public\s+(?:IActionResult|Task<[^>]+>)\s+\w+\s*\([^)]*(?:User|Account|Role|Admin|.*Entity)\s+\w+"},
    {"id":"DOTNET_OPEN_REDIRECT","title":"ASP.NET Open Redirect","vuln":"open_redirect","sev":"High","langs":["csharp"],"cwe":"CWE-601","owasp":"A01:2021 - Broken Access Control","pat":r"Redirect\s*\(\s*(?:returnUrl|url|Request\.)"},
    {"id":"DOTNET_CERT_VALIDATION_BYPASS","title":"HttpClient Certificate Validation Bypass","vuln":"tls_bypass","sev":"Critical","langs":["csharp"],"cwe":"CWE-295","owasp":"A02:2021 - Cryptographic Failures","pat":r"ServerCertificateCustomValidationCallback\s*=\s*.*=>\s*true|DangerousAcceptAnyServerCertificateValidator"},
    {"id":"DOTNET_LOG_INJECTION","title":"ILogger Raw User Input Log Injection","vuln":"log_injection","sev":"Medium","langs":["csharp"],"cwe":"CWE-117","owasp":"A09:2021 - Security Logging and Monitoring Failures","pat":r"ILogger|_logger\.(?:Information|Error|Warning|Debug)\s*\([^)]*(?:Request|Query|Form|Headers|userInput)"},

    # Node / TypeScript
    {"id":"NODE_PROTOTYPE_POLLUTION_MERGE","title":"Node Prototype Pollution Merge","vuln":"prototype_pollution","sev":"High","langs":["javascript","typescript"],"cwe":"CWE-1321","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"Object\.assign\s*\([^)]*(?:req\.|body|query)|(?:lodash|_|deepmerge|merge)\.merge\s*\([^)]*(?:req\.|body|query)|qs\.parse\s*\("},
    {"id":"NODE_CHILD_PROCESS_EXEC","title":"Node child_process.exec Command Injection","vuln":"command_injection","sev":"Critical","langs":["javascript","typescript"],"cwe":"CWE-78","owasp":"A03:2021 - Injection","pat":r"child_process\.(?:exec|execSync)\s*\(|(?:exec|execSync)\s*\([^)]*(?:req\.|query|body)"},
    {"id":"NODE_UNSAFE_EVAL_VM_FUNCTION","title":"Node Unsafe eval/vm/new Function","vuln":"code_injection","sev":"Critical","langs":["javascript","typescript"],"cwe":"CWE-94","owasp":"A03:2021 - Injection","pat":r"\beval\s*\(|new\s+Function\s*\(|vm\.runIn(?:This|New)Context\s*\("},
    {"id":"NODE_FS_TRAVERSAL","title":"Node fs Path Traversal Indicator","vuln":"path_traversal","sev":"High","langs":["javascript","typescript"],"cwe":"CWE-22","owasp":"A01:2021 - Broken Access Control","pat":r"fs\.(?:readFile|writeFile|createReadStream|unlink)\s*\([^)]*(?:req\.|query|body|params)"},
    {"id":"NODE_SERIALIZE_UNSERIALIZE","title":"node-serialize Unsafe Unserialize","vuln":"insecure_deserialization","sev":"Critical","langs":["javascript","typescript"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"node-serialize|\.unserialize\s*\("},
    {"id":"NODE_JSYAML_UNSAFE_LOAD","title":"js-yaml Unsafe load","vuln":"insecure_deserialization","sev":"High","langs":["javascript","typescript"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"jsyaml\.load\s*\(|yaml\.load\s*\("},
    {"id":"NODE_SSRF_DYNAMIC_URL","title":"Node SSRF Dynamic URL","vuln":"ssrf","sev":"High","langs":["javascript","typescript"],"cwe":"CWE-918","owasp":"A10:2021 - Server-Side Request Forgery","pat":r"(?:fetch|axios\.(?:get|post|request)|http\.request|https\.request)\s*\([^)]*(?:req\.|query|body|params|url)"},
    {"id":"NODE_REDOS_REGEX","title":"Node ReDoS Catastrophic Regex","vuln":"redos","sev":"High","langs":["javascript","typescript"],"cwe":"CWE-1333","owasp":"A05:2021 - Security Misconfiguration","pat":r"new\s+RegExp\s*\([^)]*(?:req\.|query|body)|/\([^/]*\+\)[+*]|/\([^/]*\*\)[+*]"},
    {"id":"NPM_SUPPLY_CHAIN_SCRIPT","title":"NPM Supply Chain Lifecycle Script / Unpinned Dependency","vuln":"supply_chain_script","sev":"Medium","langs":["json"],"cwe":"CWE-829","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"\"(?:preinstall|postinstall|prepare)\"\s*:|\"(?:dependencies|devDependencies)\"\s*:\s*\{[\s\S]*\"[^\"]+\"\s*:\s*\"(?:\*|latest|http|git\+)"},

    # Go
    {"id":"GO_EXEC_SH_C","title":"Go exec.Command sh -c / User-Controlled Args","vuln":"command_injection","sev":"Critical","langs":["go"],"cwe":"CWE-78","owasp":"A03:2021 - Injection","pat":r"exec\.Command\s*\(\s*\"(?:sh|bash|cmd)\"\s*,\s*\"-c\"|exec\.Command\s*\([^)]*(?:r\.URL|r\.Form|Query\()"},
    {"id":"GO_FILEPATH_JOIN_TRAVERSAL","title":"Go filepath.Join Traversal","vuln":"path_traversal","sev":"High","langs":["go"],"cwe":"CWE-22","owasp":"A01:2021 - Broken Access Control","pat":r"filepath\.Join\s*\([^)]*(?:r\.URL|FormValue|Query\(|filename|path)"},
    {"id":"GO_SQL_FMT_SPRINTF","title":"Go fmt.Sprintf SQL Injection","vuln":"sql_injection","sev":"High","langs":["go"],"cwe":"CWE-89","owasp":"A03:2021 - Injection","pat":r"fmt\.Sprintf\s*\(\s*\"[^\"]*(?:SELECT|UPDATE|DELETE|INSERT)[^\"]*\"|db\.Query\s*\([^)]*\+"},
    {"id":"GO_GOB_DECODE","title":"Go gob Decode Untrusted Data","vuln":"insecure_deserialization","sev":"High","langs":["go"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"gob\.NewDecoder\s*\(|\.Decode\s*\(&"},
    {"id":"GO_JSON_UNMARSHAL_INTERFACE","title":"Go json.Unmarshal into interface{} / any","vuln":"insecure_deserialization","sev":"Medium","langs":["go"],"cwe":"CWE-20","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"var\s+\w+\s+(?:interface\{\}|any)|json\.Unmarshal\s*\([^)]*,\s*&\w+\s*\)"},
    {"id":"GO_SSRF_HTTP_GET","title":"Go SSRF Dynamic HTTP Request","vuln":"ssrf","sev":"High","langs":["go"],"cwe":"CWE-918","owasp":"A10:2021 - Server-Side Request Forgery","pat":r"http\.(?:Get|Post)\s*\([^)]*(?:r\.URL|FormValue|Query\(|url)|http\.NewRequest\s*\([^)]*(?:r\.URL|Query\()"},
    {"id":"GO_OPEN_REDIRECT","title":"Go Open Redirect","vuln":"open_redirect","sev":"High","langs":["go"],"cwe":"CWE-601","owasp":"A01:2021 - Broken Access Control","pat":r"http\.Redirect\s*\([^)]*(?:r\.URL|FormValue|Query\()"},
    {"id":"GO_SHARED_MAP_RACE","title":"Go Shared Map/Slice Race Indicator","vuln":"race_condition","sev":"High","langs":["go"],"cwe":"CWE-362","owasp":"A04:2021 - Insecure Design","pat":r"var\s+\w+\s+map\[|go\s+func\s*\(|\w+\s*\[.*\]\s*=\s*"},
    {"id":"GO_UNBOUNDED_READALL","title":"Go Unbounded io.ReadAll / ioutil.ReadAll","vuln":"resource_exhaustion","sev":"High","langs":["go"],"cwe":"CWE-400","owasp":"A05:2021 - Security Misconfiguration","pat":r"(?:io|ioutil)\.ReadAll\s*\(\s*r\.Body\s*\)(?![\s\S]{0,200}MaxBytesReader)"},
    {"id":"GO_TLS_INSECURE_SKIP_VERIFY","title":"Go TLS InsecureSkipVerify true","vuln":"tls_bypass","sev":"Critical","langs":["go"],"cwe":"CWE-295","owasp":"A02:2021 - Cryptographic Failures","pat":r"InsecureSkipVerify\s*:\s*true"},

    # PHP
    {"id":"PHP_LFI_RFI_INCLUDE","title":"PHP LFI/RFI include/require","vuln":"path_traversal","sev":"High","langs":["php"],"cwe":"CWE-98","owasp":"A03:2021 - Injection","pat":r"(?:include|require)(?:_once)?\s*\(?\s*\$_(?:GET|POST|REQUEST|COOKIE)"},
    {"id":"PHP_COMMAND_INJECTION","title":"PHP Command Injection Sink","vuln":"command_injection","sev":"Critical","langs":["php"],"cwe":"CWE-78","owasp":"A03:2021 - Injection","pat":r"(?:shell_exec|system|exec|passthru|popen|proc_open)\s*\([^)]*\$_(?:GET|POST|REQUEST)|`[^`]*\$_(?:GET|POST|REQUEST)"},
    {"id":"PHP_SQL_CONCAT","title":"PHP SQL Concatenation","vuln":"sql_injection","sev":"High","langs":["php"],"cwe":"CWE-89","owasp":"A03:2021 - Injection","pat":r"(?:mysqli_query|->query|PDO::query)\s*\([^)]*\$_(?:GET|POST|REQUEST)|\"\s*\.\s*\$_(?:GET|POST|REQUEST)"},
    {"id":"PHP_UNSERIALIZE","title":"PHP unserialize Object Injection","vuln":"insecure_deserialization","sev":"Critical","langs":["php"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"unserialize\s*\([^)]*\$_(?:GET|POST|REQUEST|COOKIE)"},
    {"id":"PHP_SSRF_CURL_FILEGET","title":"PHP SSRF Dynamic URL","vuln":"ssrf","sev":"High","langs":["php"],"cwe":"CWE-918","owasp":"A10:2021 - Server-Side Request Forgery","pat":r"(?:curl_exec|file_get_contents|fopen)\s*\([^)]*\$_(?:GET|POST|REQUEST)|CURLOPT_URL\s*,\s*\$_"},
    {"id":"PHP_FILE_TRAVERSAL","title":"PHP File Path Traversal","vuln":"path_traversal","sev":"High","langs":["php"],"cwe":"CWE-22","owasp":"A01:2021 - Broken Access Control","pat":r"(?:fopen|unlink|file_get_contents|readfile)\s*\([^)]*\$_(?:GET|POST|REQUEST)"},
    {"id":"PHP_PHAR_DESERIALIZATION","title":"PHP PHAR Deserialization","vuln":"insecure_deserialization","sev":"Critical","langs":["php"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"phar://|Phar\s*\("},
    {"id":"PHP_RAW_ECHO_XSS","title":"PHP Raw echo/print XSS","vuln":"xss","sev":"High","langs":["php"],"cwe":"CWE-79","owasp":"A03:2021 - Injection","pat":r"(?:echo|print)\s+\$_(?:GET|POST|REQUEST)(?![\s\S]{0,80}htmlspecialchars)"},
    {"id":"PHP_CURL_SSL_VERIFY_DISABLED","title":"PHP curl TLS Verification Disabled","vuln":"tls_bypass","sev":"Critical","langs":["php"],"cwe":"CWE-295","owasp":"A02:2021 - Cryptographic Failures","pat":r"CURLOPT_SSL_VERIFYPEER\s*,\s*(?:false|0)|CURLOPT_SSL_VERIFYHOST\s*,\s*0"},

    # Generic / GraphQL / messaging / abuse
    {"id":"GENERIC_NOSQL_INJECTION","title":"NoSQL Injection Indicator","vuln":"nosql_injection","sev":"High","langs":["javascript","typescript","python","java","php"],"cwe":"CWE-943","owasp":"A03:2021 - Injection","pat":r"\$(?:where|ne|gt|lt|regex)\b|findOne\s*\([^)]*(?:req\.|request\.|\$_)|find\s*\([^)]*(?:req\.|request\.|\$_)"},
    {"id":"GRAPHQL_INTROSPECTION_ENABLED","title":"GraphQL Introspection Exposure","vuln":"graphql_exposure","sev":"High","langs":["graphql","javascript","typescript","java","python","csharp"],"cwe":"CWE-200","owasp":"A05:2021 - Security Misconfiguration","pat":r"introspection\s*:\s*true|GraphQLPlayground|graphiql\s*:\s*true|__schema|__type"},
    {"id":"GRAPHQL_QUERY_DEPTH_MISSING","title":"GraphQL Query Depth / Complexity Limit Missing","vuln":"resource_exhaustion","sev":"High","langs":["javascript","typescript","java","python","csharp"],"cwe":"CWE-400","owasp":"A05:2021 - Security Misconfiguration","pat":r"new\s+ApolloServer\s*\(|GraphQLServer\s*\((?![\s\S]{0,300}(depthLimit|complexity|validationRules))"},
    {"id":"GRAPHQL_RESOLVER_BOLA","title":"GraphQL Resolver BOLA / IDOR Indicator","vuln":"idor","sev":"High","langs":["javascript","typescript","java","python","csharp"],"cwe":"CWE-639","owasp":"A01:2021 - Broken Access Control","pat":r"resolver|Query:\s*\{|Mutation:\s*\{|findById\s*\([^)]*(?:args\.id|id)"},
    {"id":"KAFKA_RABBITMQ_UNSAFE_DESERIALIZATION","title":"Kafka/RabbitMQ Unsafe Message Deserialization","vuln":"insecure_deserialization","sev":"Critical","langs":["java","python","javascript","typescript","csharp"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"KafkaConsumer|@KafkaListener|RabbitListener|BasicConsume|JSON\.parse\s*\([^)]*message|ObjectMapper\s*\.readValue\s*\([^)]*(?:record|message|payload)"},
    {"id":"TENANT_ISOLATION_MISSING","title":"Tenant Isolation Failure Indicator","vuln":"tenant_isolation_failure","sev":"High","langs":["python","javascript","typescript","java","csharp","go","php"],"cwe":"CWE-639","owasp":"A01:2021 - Broken Access Control","pat":r"tenantId|tenant_id|organizationId|org_id"},
    {"id":"PRIVILEGE_ESCALATION_FIELD_BINDING","title":"Privilege Escalation Field Binding","vuln":"privilege_escalation","sev":"Critical","langs":["python","javascript","typescript","java","csharp","go","php"],"cwe":"CWE-269","owasp":"A01:2021 - Broken Access Control","pat":r"(?:isAdmin|role|roles|permission|permissions|privilege|is_superuser)\s*[:=]\s*(?:req\.|request\.|body|params|\$_)"},
    {"id":"WORKFLOW_APPROVAL_BYPASS","title":"Workflow / Approval Bypass Indicator","vuln":"workflow_bypass","sev":"High","langs":["python","javascript","typescript","java","csharp","go","php"],"cwe":"CWE-840","owasp":"A04:2021 - Insecure Design","pat":r"approval_required\s*[:=]\s*false|skip_approval|auto_approve|approved\s*[:=]\s*true"},
    {"id":"DUPLICATE_ACTION_RACE","title":"Duplicate Action Race Indicator","vuln":"race_condition","sev":"High","langs":["python","javascript","typescript","java","csharp","go","php"],"cwe":"CWE-362","owasp":"A04:2021 - Insecure Design","pat":r"(?:payment|transfer|coupon|redeem|invite|otp|reset)[\s\S]{0,120}(?:save|insert|update|create)(?![\s\S]{0,160}(transaction|lock|idempotency|unique))"},
    {"id":"MISSING_RATE_LIMIT_ENDPOINT","title":"Missing Rate Limit on Abuse-Prone Endpoint","vuln":"api_rate_limit","sev":"High","langs":["python","javascript","typescript","java","csharp","go","php"],"cwe":"CWE-770","owasp":"API4:2023 - Unrestricted Resource Consumption","pat":r"(?:/login|/otp|/password-reset|/reset|/invite|/coupon|/refresh|/payment)(?![\s\S]{0,200}(rateLimit|throttle|Bucket4j|RateLimiter|limit_req|slow_down))"},
]

# Backward-compatible existing rules retained. These are intentionally simple.
REGEX_RULES: list[dict] = [
    {"id":"AWS_ACCESS_KEY","name":"AWS Access Key","pattern":re.compile(r"AKIA[0-9A-Z]{16}", _F),"vuln_type":"hardcoded_secret","note":"AWS access key ID detected in source code.","severity":"Critical","cwe":"CWE-798","owasp":"A07:2021 - Identification and Authentication Failures"},
    {"id":"GITHUB_TOKEN","name":"GitHub Token","pattern":re.compile(r"ghp_[A-Za-z0-9]{36}", _F),"vuln_type":"hardcoded_secret","note":"GitHub personal access token detected in source code.","severity":"Critical","cwe":"CWE-798","owasp":"A07:2021 - Identification and Authentication Failures"},
    {"id":"GENERIC_API_KEY_PASSWORD","name":"Generic API Key/Password","pattern":re.compile(r'(?:api[_-]?key|api[_-]?token|secret[_-]?key|auth[_-]?token|access[_-]?token|password|passwd|pwd)\s*[:=]\s*["\'][A-Za-z0-9@#$%^&+=!_.\-/]{8,}["\']', _F),"vuln_type":"hardcoded_secret","note":"Possible hardcoded credential or API key.","severity":"Critical","cwe":"CWE-798","owasp":"A07:2021 - Identification and Authentication Failures"},
    {"id":"PRIVATE_KEY_HEADER","name":"Private Key Header","pattern":re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----", _F),"vuln_type":"hardcoded_secret","note":"Private key material in source code.","severity":"Critical","cwe":"CWE-798","owasp":"A07:2021 - Identification and Authentication Failures"},
    {"id":"MD5_USAGE","name":"MD5 Usage","pattern":re.compile(r"hashlib\.md5\s*\(|MessageDigest\.getInstance\s*\(\s*[\"']MD5|MD5CryptoServiceProvider|crypto\.createHash\s*\(\s*[\"']md5", _F),"vuln_type":"weak_crypto","note":"MD5 is cryptographically broken.","severity":"High","cwe":"CWE-327","owasp":"A02:2021 - Cryptographic Failures"},
    {"id":"SHA1_USAGE","name":"SHA-1 Usage","pattern":re.compile(r"hashlib\.sha1\s*\(|MessageDigest\.getInstance\s*\(\s*[\"']SHA-?1|SHA1CryptoServiceProvider|crypto\.createHash\s*\(\s*[\"']sha1", _F),"vuln_type":"weak_crypto","note":"SHA-1 is deprecated for cryptographic use.","severity":"High","cwe":"CWE-327","owasp":"A02:2021 - Cryptographic Failures"},
    {"id":"FLASK_DEBUG","name":"Flask Debug Mode","pattern":re.compile(r"app\.run\s*\([^)]*debug\s*=\s*True", _F),"vuln_type":"debug_exposure","note":"Flask debug=True exposes interactive debugger in production.","severity":"High","cwe":"CWE-215","owasp":"A05:2021 - Security Misconfiguration"},
    {"id":"SUBPROCESS_SHELL_TRUE","name":"subprocess shell=True","pattern":re.compile(r"subprocess\.\w+\s*\([^)]*shell\s*=\s*True", _F),"vuln_type":"command_injection","note":"subprocess with shell=True enables shell injection.","severity":"Critical","cwe":"CWE-78","owasp":"A03:2021 - Injection"},
    {"id":"OS_SYSTEM","name":"os.system Call","pattern":re.compile(r"os\.system\s*\(", _F),"vuln_type":"command_injection","note":"os.system executes shell commands.","severity":"Critical","cwe":"CWE-78","owasp":"A03:2021 - Injection"},
    {"id":"EVAL_CALL","name":"eval() Call","pattern":re.compile(r"\beval\s*\(", _F),"vuln_type":"code_injection","note":"eval() executes arbitrary code.","severity":"Critical","cwe":"CWE-94","owasp":"A03:2021 - Injection"},
    {"id":"EXEC_CALL","name":"exec() Call","pattern":re.compile(r"\bexec\s*\(", _F),"vuln_type":"code_injection","note":"exec() executes arbitrary code.","severity":"Critical","cwe":"CWE-94","owasp":"A03:2021 - Injection"},
]


# ---- Big4 enterprise gap patch: rule hardening, evidence targeting, controls ----
BIG4_CONTROL_FALLBACKS = {
    "tls_bypass": {"pci_dss":"Req 4.2 / Req 6.2.4 - Protect transmission and prevent insecure crypto", "nist":"SC-8 / SC-13 / SI-10", "iso27001":"A.8.24 / A.8.20", "soc2":"CC6.7 / CC6.6"},
    "actuator_exposure": {"pci_dss":"Req 6.2.4 / Req 7 - Secure configuration and access control", "nist":"CM-7 / AC-3 / SC-7", "iso27001":"A.8.9 / A.8.20", "soc2":"CC6.6 / CC7.2"},
    "xxe": {"pci_dss":"Req 6.2.4 - Prevent XML external entity attacks", "nist":"SI-10 / SC-7", "iso27001":"A.14.2.5 / A.13.1.1", "soc2":"CC6.6 / CC7.2"},
    "redos": {"pci_dss":"Req 6.2.4 - Prevent resource exhaustion", "nist":"SC-5 / SI-10", "iso27001":"A.8.16 / A.8.20", "soc2":"CC7.2 / CC6.6"},
    "prototype_pollution": {"pci_dss":"Req 6.2.4 - Secure development", "nist":"SI-10 / CM-7", "iso27001":"A.8.28 / A.8.29", "soc2":"CC6.6 / CC7.2"},
    "async_security_context_loss": {"pci_dss":"Req 7 / Req 8 - Access control", "nist":"AC-3 / AC-6 / AU-12", "iso27001":"A.5.15 / A.8.2", "soc2":"CC6.1 / CC6.6"},
    "missing_validation": {"pci_dss":"Req 6.2.4 - Input validation", "nist":"SI-10", "iso27001":"A.8.28 / A.8.29", "soc2":"CC6.6"},
    "resource_exhaustion": {"pci_dss":"Req 6.2.4 / Req 8 - Abuse prevention", "nist":"AC-7 / SC-5 / SI-10", "iso27001":"A.8.16 / A.8.20", "soc2":"CC7.2 / CC6.6"},
    "race_condition": {"pci_dss":"Req 6.2.4 - Secure transaction processing", "nist":"SI-10 / AC-3", "iso27001":"A.8.28 / A.8.29", "soc2":"CC7.2 / CC6.6"},
    "template_injection": {"pci_dss":"Req 6.2.4 - Prevent injection attacks", "nist":"SI-10", "iso27001":"A.14.2.5", "soc2":"CC6.6"},
    "log_injection": {"pci_dss":"Req 10 / Req 6.2.4 - Secure logging", "nist":"AU-9 / SI-10", "iso27001":"A.8.15 / A.8.16", "soc2":"CC7.2 / CC7.4"},
    "zipslip": {"pci_dss":"Req 6.2.4 - File handling security", "nist":"SI-10 / AC-3", "iso27001":"A.8.28", "soc2":"CC6.6"},
}

BIG4_REMEDIATION_BY_RULE = {
    "SPRING_ACTUATOR_EXPOSE_ALL": ["Do not expose all actuator endpoints in production.", "Set management.endpoints.web.exposure.include to a minimal allow-list such as health/info only.", "Protect actuator endpoints with Spring Security and network ACLs.", "Disable sensitive endpoints such as env, beans, heapdump, threaddump, mappings and configprops."],
    "SPRING_SECURITY_CSRF_DISABLED": ["Do not globally disable CSRF protection for browser-based sessions.", "Enable CSRF for state-changing endpoints or use stateless token-based APIs with explicit compensating controls.", "Avoid broad anyRequest().permitAll() and require authenticated authorization rules by default.", "Add security tests for unauthenticated state-changing requests."],
    "SPRING_SPEL_INJECTION": ["Never evaluate user-controlled input with SpEL parseExpression().", "Replace dynamic expressions with allow-listed operations or server-side enum choices.", "Use SimpleEvaluationContext where expression evaluation is unavoidable.", "Reject expressions containing type references, method calls, constructors or bean references."],
    "SPRING_MASS_ASSIGNMENT_ENTITY_BINDING": ["Bind requests to explicit DTOs rather than JPA/domain entities.", "Use allow-listed fields and ignore role, tenantId, isAdmin, status, balance and permission fields.", "Validate with @Valid/@Validated and enforce server-side authorization after binding."],
    "JAVA_TEMPLATE_INJECTION": ["Do not treat user input as template source or template name.", "Use fixed server-side template names and pass user input only as escaped model data.", "Disable unrestricted template resolvers and expression utilities."],
    "JAVA_TLS_TRUST_BYPASS": ["Remove permissive TrustManager and HostnameVerifier implementations.", "Use the default JVM trust store or managed certificate pinning.", "Fail closed on certificate and hostname validation errors."],
    "DOTNET_CERT_VALIDATION_BYPASS": ["Remove DangerousAcceptAnyServerCertificateValidator and callbacks returning true.", "Use default HttpClient certificate validation and trusted roots.", "Pin certificates only with explicit rotation procedures."],
    "DOTNET_LOG_INJECTION": ["Use structured logging placeholders instead of concatenating raw user input.", "Normalize CR/LF and control characters before logging.", "Do not log secrets, tokens, cookies or raw request bodies."],
    "NODE_UNSAFE_EVAL_VM_FUNCTION": ["Remove eval(), vm execution and new Function() for untrusted input.", "Use schema-validated data, safe interpreters or fixed allow-listed commands.", "Apply CSP and runtime sandboxing where dynamic execution cannot be avoided."],
    "NODE_SERIALIZE_UNSERIALIZE": ["Do not unserialize untrusted node-serialize payloads.", "Use JSON.parse for data-only payloads and reject functions/prototypes.", "Apply integrity checks and strict type allow-lists."],
    "NODE_JSYAML_UNSAFE_LOAD": ["Use safe schema loading for YAML and reject custom tags/types.", "Do not parse untrusted YAML with unsafe constructors.", "Prefer JSON for external data interchange."],
    "GO_SHARED_MAP_RACE": ["Protect shared maps/slices using sync.Mutex, sync.RWMutex, channels or sync.Map.", "Run go test -race in CI.", "Make check-and-act workflows atomic with transactions or locks."],
    "GO_GOB_DECODE": ["Do not gob-decode untrusted network or message-bus payloads.", "Use JSON/protobuf with explicit schemas and validation.", "Authenticate and integrity-protect serialized messages."],
    "GENERIC_ZIPSLIP": ["Canonicalize archive entry paths before extraction.", "Reject absolute paths and entries containing .. segments.", "Verify the resolved destination remains under the intended extraction directory."],
    "GENERIC_TOCTOU_RACE": ["Avoid check-then-use filesystem and workflow patterns.", "Use atomic file operations, transactions or locks.", "Re-check authorization and object state inside the final transaction."],
}

BIG4_RULE_PATCHES = {
    "SPRING_SPEL_INJECTION": {"pat": r"parseExpression\s*\([^)]*(?:request|getParameter|@RequestParam|@PathVariable|param|input)|SpelExpressionParser[\s\S]{0,240}parseExpression\s*\(", "evidence_pat": r"parseExpression\s*\("},
    "SPRING_ACTUATOR_EXPOSE_ALL": {"pat": r"management\.endpoints\.web\.exposure\.include\s*[:=]\s*[\"']?\*[\"']?|exposure:\s*\n\s*include:\s*[\"']?\*[\"']?", "evidence_pat": r"include\s*[:=]\s*[\"']?\*[\"']?"},
    "JAVA_SNAKEYAML_UNSAFE_LOAD": {"pat": r"(?:new\s+Yaml\s*\([^)]*\)|Yaml\s+\w+\s*=\s*new\s+Yaml\s*\([^)]*\))[\s\S]{0,240}\.load\s*\(|\.load\s*\([^)]*(?:request|getParameter|input|payload|body)"},
    "JAVA_XSTREAM_DESERIALIZATION": {"pat": r"new\s+XStream\s*\(|\.fromXML\s*\([^)]*(?:request|getParameter|input|payload|body)?"},
    "JAVA_JACKSON_DEFAULT_TYPING": {"pat": r"enableDefaultTyping\s*\(|activateDefaultTyping\s*\(|DefaultTyping\.|@JsonTypeInfo|ObjectMapper[\s\S]{0,200}enableDefaultTyping"},
    "DOTNET_DATACONTRACT_DESERIALIZER": {"pat": r"(?:DataContractSerializer|NetDataContractSerializer)\s*\(|\.ReadObject\s*\([^)]*(?:Request|Body|Stream|input|payload)?"},
    "DOTNET_ZIPSLIP_EXTRACT": {"pat": r"ZipFile\.ExtractToDirectory\s*\(|ZipArchive[\s\S]{0,300}(?:ExtractToFile|FullName)"},
    "DOTNET_LOG_INJECTION": {"sev":"High", "pat": r"(?:ILogger|_logger)\.(?:Information|Error|Warning|Debug|LogInformation|LogError|LogWarning)\s*\([^)]*(?:Request|Query|Form|Headers|userInput|returnUrl|User\.Identity)"},
    "NODE_UNSAFE_EVAL_VM_FUNCTION": {"pat": r"\beval\s*\([^)]*(?:req\.|request|body|query|params)?|new\s+Function\s*\([^)]*(?:req\.|request|body|query|params)?|vm\.runIn(?:This|New)Context\s*\("},
    "NODE_JSYAML_UNSAFE_LOAD": {"pat": r"(?:jsyaml|js_yaml|yaml)\.load\s*\([^)]*(?:req\.|request|body|query|payload)?"},
    "GO_GOB_DECODE": {"pat": r"gob\.NewDecoder\s*\([^)]*(?:r\.Body|conn|msg|payload|reader)?[\s\S]{0,200}\.Decode\s*\("},
    "GO_SHARED_MAP_RACE": {"pat": r"var\s+\w+\s*=\s*map\[|var\s+\w+\s+map\[|go\s+func\s*\([\s\S]{0,300}\w+\s*\[[^\]]+\]\s*="},
    "GRAPHQL_QUERY_DEPTH_MISSING": {"pat": r"new\s+ApolloServer\s*\((?![\s\S]{0,400}(depthLimit|queryComplexity|complexity|validationRules))|GraphQLServer\s*\((?![\s\S]{0,400}(depthLimit|queryComplexity|complexity|validationRules))"},
}
for _rule in ENTERPRISE_RULES:
    _patch = BIG4_RULE_PATCHES.get(_rule.get("id"))
    if _patch:
        _rule.update(_patch)
    if _rule.get("id") in BIG4_REMEDIATION_BY_RULE:
        _rule["remediation"] = BIG4_REMEDIATION_BY_RULE[_rule["id"]]

_existing_rule_ids = {r.get("id") for r in ENTERPRISE_RULES}
_EXTRA_BIG4_RULES = [
    {"id":"JAVA_TRUSTMANAGER_EMPTY_METHOD","title":"Java TrustManager Empty Certificate Validation","vuln":"tls_bypass","sev":"Critical","langs":["java"],"cwe":"CWE-295","owasp":"A02:2021 - Cryptographic Failures","pat":r"checkServerTrusted\s*\([^)]*\)\s*\{\s*\}|verify\s*\([^)]*\)\s*\{\s*return\s+true\s*;?\s*\}","remediation":BIG4_REMEDIATION_BY_RULE.get("JAVA_TLS_TRUST_BYPASS")},
    {"id":"JAVA_SPRING_QUERY_ANNOTATION_CONCAT","title":"Spring Data @Query Concatenation Injection","vuln":"orm_injection","sev":"High","langs":["java"],"cwe":"CWE-89","owasp":"A03:2021 - Injection","pat":r"@Query\s*\(\s*(?:value\s*=\s*)?[\"'][^\"']*[\"']\s*\+|@Query[\s\S]{0,160}(?:nativeQuery\s*=\s*true)[\s\S]{0,160}\+"},
    {"id":"JAVA_THYMELEAF_FREEMARKER_VELOCITY_INJECTION","title":"Spring Template Injection: Thymeleaf/Freemarker/Velocity","vuln":"template_injection","sev":"High","langs":["java"],"cwe":"CWE-94","owasp":"A03:2021 - Injection","pat":r"(?:TemplateEngine|SpringTemplateEngine|FreeMarkerTemplateUtils|VelocityEngine|StringTemplateResolver)[\s\S]{0,240}(?:process|evaluate|mergeTemplate|setTemplateMode|setTemplateResolver)\s*\([^)]*(?:request|getParameter|param|input|body)?","remediation":BIG4_REMEDIATION_BY_RULE.get("JAVA_TEMPLATE_INJECTION")},
    {"id":"DOTNET_HTTPCLIENT_CERT_CALLBACK_TRUE","title":".NET HttpClient Certificate Validation Bypass","vuln":"tls_bypass","sev":"Critical","langs":["csharp"],"cwe":"CWE-295","owasp":"A02:2021 - Cryptographic Failures","pat":r"ServerCertificateCustomValidationCallback\s*=\s*(?:HttpClientHandler\.)?DangerousAcceptAnyServerCertificateValidator|ServerCertificateCustomValidationCallback\s*=\s*[^;]*=>\s*true","remediation":BIG4_REMEDIATION_BY_RULE.get("DOTNET_CERT_VALIDATION_BYPASS")},
    {"id":"GO_JSON_UNMARSHAL_INTERFACE","title":"Go json.Unmarshal into interface{} / any","vuln":"insecure_deserialization","sev":"High","langs":["go"],"cwe":"CWE-502","owasp":"A08:2021 - Software and Data Integrity Failures","pat":r"var\s+\w+\s+(?:interface\s*\{\s*\}|any)\s*\n[\s\S]{0,160}json\.Unmarshal\s*\(|json\.Unmarshal\s*\([^,]+,\s*&\w+\s*\)[\s\S]{0,120}(?:map\[string\]interface|interface\s*\{\s*\}|any)"},
    {"id":"GENERIC_ZIPSLIP","title":"Generic ZipSlip Archive Extraction","vuln":"zipslip","sev":"High","langs":["java","csharp","javascript","typescript","python","go","php"],"cwe":"CWE-22","owasp":"A01:2021 - Broken Access Control","pat":r"(?:ZipEntry|getNextEntry|ZipArchive|adm-zip|unzipper|zipfile|archive/zip)[\s\S]{0,300}(?:extract|Extract|writeFile|FileOutputStream|createWriteStream|OpenFile)","remediation":BIG4_REMEDIATION_BY_RULE.get("GENERIC_ZIPSLIP")},
    {"id":"GENERIC_TOCTOU_RACE","title":"TOCTOU Race Condition Check-Then-Use","vuln":"race_condition","sev":"High","langs":["java","csharp","javascript","typescript","python","go","php"],"cwe":"CWE-367","owasp":"A04:2021 - Insecure Design","pat":r"(?:exists|existsSync|File\.exists|os\.path\.exists|stat\(|access\(|file_exists)[\s\S]{0,160}(?:open\(|writeFile|delete|remove|rename|move|save|update)","remediation":BIG4_REMEDIATION_BY_RULE.get("GENERIC_TOCTOU_RACE")},
]
for _r in _EXTRA_BIG4_RULES:
    if _r["id"] not in _existing_rule_ids:
        ENTERPRISE_RULES.append(_r)
        _existing_rule_ids.add(_r["id"])
# ---- end Big4 enterprise gap patch ----

COMPILED_ENTERPRISE_RULES = [{**r, "pattern": re.compile(r["pat"], _F)} for r in ENTERPRISE_RULES]


def _skip(path: Path) -> bool:
    return any(p in EXCLUDED_DIRS for p in path.parts)


def _should_scan(path: Path) -> bool:
    name = path.name
    return (path.suffix.lower() in SCANNABLE_EXT or name in SCANNABLE_EXT) and not _skip(path)


def _language(path: Path) -> str:
    if path.name == "Dockerfile":
        return "dockerfile"
    return LANG_BY_EXT.get(path.suffix.lower(), path.suffix.lower().lstrip(".") or "unknown")


def _line_for(source: str, offset: int) -> int:
    return source[:offset].count("\n") + 1


def _is_comment(snippet: str, language: str) -> bool:
    s = snippet.strip()
    if not s:
        return True
    if s.startswith(("#", "//", "*", "<!--")):
        return True
    return False




def _snippet_for_match(rule: dict, source: str, lines: list[str], start: int, end: int) -> tuple[int, str]:
    """Return the most meaningful evidence line for a multiline rule match."""
    evidence_pat = rule.get("evidence_pat")
    segment = source[start:end]
    if evidence_pat:
        em = re.search(evidence_pat, segment, re.IGNORECASE | re.MULTILINE | re.DOTALL)
        if em:
            offset = start + em.start()
            line = _line_for(source, offset)
            return line, (lines[line - 1].strip() if line <= len(lines) else em.group(0).strip())
    # Prefer the line containing a dangerous sink/config rather than an import/header line.
    focus_patterns = [
        r"parseExpression\s*\(", r"include\s*[:=]\s*[\"']?\*[\"']?",
        r"enableDefaultTyping", r"activateDefaultTyping", r"TypeNameHandling",
        r"InsecureSkipVerify", r"DangerousAcceptAnyServerCertificateValidator",
        r"setAccessible\s*\(", r"fromXML\s*\(", r"\.load\s*\(",
        r"ExtractToDirectory", r"ExtractToFile", r"curl_setopt", r"CURLOPT_SSL",
        r"introspection\s*:\s*true", r"graphiql\s*:\s*true", r"__schema",
        r"depthLimit", r"complexity", r"new\s+Function\s*\(", r"eval\s*\(",
        r"vm\.runIn", r"unserialize\s*\(", r"gob\.NewDecoder", r"json\.Unmarshal",
        r"ZipFile", r"ZipEntry", r"file_exists", r"existsSync"
    ]
    base_line = _line_for(source, start)
    for idx, txt in enumerate(segment.splitlines()):
        if any(re.search(pat, txt, re.I) for pat in focus_patterns):
            line = base_line + idx
            return line, txt.strip()
    line = _line_for(source, start)
    return line, (lines[line - 1].strip() if line <= len(lines) else segment.strip().splitlines()[0] if segment.strip() else "")

def _remediation(vuln: str, mapping: dict, custom: list[str] | None = None) -> list[str]:
    if custom:
        return custom
    m = mapping.get("remediation") if isinstance(mapping, dict) else None
    if isinstance(m, list) and m:
        return m
    return BASE_REMEDIATION.get(vuln, ["Validate all user-controlled input at trust boundaries.", "Use safe framework APIs and least privilege.", "Add unit tests and security regression tests for this pattern."])


def _make_finding(rule: dict, filepath: str, lineno: int, snippet: str, language: str) -> dict:
    vuln = rule.get("vuln_type") or rule.get("vuln") or "enterprise_control"
    mapping = get_mapping(vuln)
    fallback_controls = BIG4_CONTROL_FALLBACKS.get(vuln, {})
    title = rule.get("name") or rule.get("title") or rule.get("id") or vuln
    sev = rule.get("severity") or rule.get("sev") or mapping.get("severity", "Medium")
    cwe = rule.get("cwe") or mapping.get("cwe", "")
    owasp = rule.get("owasp") or mapping.get("owasp", "")
    rule_id = rule.get("id") or re.sub(r"[^A-Z0-9]+", "_", title.upper()).strip("_")
    confidence = "High" if sev == "Critical" else rule.get("confidence", "Medium")
    return {
        "rule_id": rule_id,
        "title": title,
        "vuln_type": vuln,
        "severity": sev,
        "priority": _priority(sev),
        "confidence": confidence,
        "language": language,
        "file": filepath,
        "line": lineno,
        "snippet": snippet,
        "description": rule.get("note") or rule.get("description") or f"Enterprise static control matched: {title}.",
        "remediation": _remediation(vuln, mapping, rule.get("remediation")),
        "owasp": owasp,
        "owasp_id": mapping.get("owasp_id", ""),
        "cwe": cwe,
        "cwe_desc": mapping.get("cwe_desc", ""),
        "mitre": mapping.get("mitre", ""),
        "mitre_desc": mapping.get("mitre_desc", ""),
        "pci_dss": mapping.get("pci_dss") or fallback_controls.get("pci_dss", ""),
        "nist": mapping.get("nist") or fallback_controls.get("nist", ""),
        "iso27001": mapping.get("iso27001") or fallback_controls.get("iso27001", ""),
        "iso_27001": mapping.get("iso_27001") or mapping.get("iso27001") or fallback_controls.get("iso27001", ""),
        "nist_800_53": mapping.get("nist_800_53") or mapping.get("nist") or fallback_controls.get("nist", ""),
        "soc2": mapping.get("soc2") or fallback_controls.get("soc2", ""),
        "business_impact": mapping.get("business_impact", ""),
        "exploitability": "High" if sev in {"Critical", "High"} else "Medium",
        "evidence": f"{filepath}:{lineno}: {snippet}",
        "data_flow": "",
        "taint_path": "",
        "detection": rule.get("detection", "Enterprise SAST Pattern"),
        "engine": "scanner.sast",
        "cvss": None,
        "cve": None,
        "cve_note": "Code-level vulnerability (no CVE).",
        "group_key": f"{rule_id}|{filepath}|{lineno}|{snippet[:120]}",
        "enterprise_control": True,
    }


def scan_file(filepath: str) -> list[dict]:
    path = Path(filepath)
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    lines = source.splitlines()
    language = _language(path)
    findings: list[dict] = []

    # Existing rules
    for rule in REGEX_RULES:
        for match in rule["pattern"].finditer(source):
            lineno, snippet = _snippet_for_match(rule, source, lines, match.start(), match.end())
            if _is_comment(snippet, language):
                continue
            findings.append(_make_finding(rule, filepath, lineno, snippet, language))

    # Enterprise controls. Apply only to relevant languages to avoid noise.
    for rule in COMPILED_ENTERPRISE_RULES:
        langs = rule.get("langs") or []
        if langs and language not in langs:
            # config files sometimes have language yaml/properties/json but path matters
            if not (language in {"yaml", "properties", "json", "xml", "graphql"} and any(l in langs for l in [language])):
                continue
        for match in rule["pattern"].finditer(source):
            lineno, snippet = _snippet_for_match(rule, source, lines, match.start(), match.end())
            if _is_comment(snippet, language):
                continue
            findings.append(_make_finding(rule, filepath, lineno, snippet, language))
            break  # avoid floods per rule per file; dedup later handles repeated files

    return findings


def summarize_enterprise_controls(findings: list[dict]) -> dict:
    ef = [f for f in findings if f.get("enterprise_control") or str(f.get("rule_id", "")).startswith(("JAVA_","SPRING_","DOTNET_","NODE_","GO_","PHP_","GRAPHQL_","KAFKA_","GENERIC_"))]
    by_language = Counter(f.get("language", "unknown") for f in ef)
    by_rule = Counter(f.get("rule_id", "UNKNOWN") for f in ef)
    by_sev = Counter(f.get("severity", "Unknown") for f in ef)
    by_engine = Counter(f.get("engine", "scanner.sast") for f in ef)
    def cnt(pred):
        return sum(1 for f in ef if pred(f))
    return {
        "total_new_enterprise_controls": len(ef),
        "by_language": dict(by_language),
        "by_rule_id": dict(by_rule),
        "by_severity": dict(by_sev),
        "by_engine": dict(by_engine),
        "spring_boot_findings": cnt(lambda f: str(f.get("rule_id", "")).startswith("SPRING_") or "Spring" in f.get("title", "")),
        "deserialization_findings": cnt(lambda f: "deserialization" in f.get("vuln_type", "")),
        "xxe_findings": cnt(lambda f: f.get("vuln_type") == "xxe"),
        "mass_assignment_findings": cnt(lambda f: f.get("vuln_type") == "mass_assignment"),
        "redos_findings": cnt(lambda f: f.get("vuln_type") == "redos"),
        "race_async_findings": cnt(lambda f: f.get("vuln_type") in {"race_condition", "async_security_context_loss"}),
        "api_abuse_findings": cnt(lambda f: f.get("vuln_type") == "api_rate_limit"),
    }


def scan_directory(target_path: str, workers: int = 2) -> list[dict]:
    target = Path(target_path)
    all_files = [f for f in target.rglob("*") if f.is_file() and _should_scan(f)]
    all_findings: list[dict] = []

    def _scan(fp: Path) -> list[dict]:
        results = scan_file(str(fp))
        # Keep existing Python taint integration and add non-Python taint-like scanner.
        try:
            from scanner.taint_engine import analyze_file as taint_analyze
            results += taint_analyze(str(fp))
        except Exception:
            pass
        return results

    with ThreadPoolExecutor(max_workers=max(1, int(workers or 1))) as pool:
        futures = {pool.submit(_scan, fp): fp for fp in all_files}
        for future in as_completed(futures):
            try:
                all_findings.extend(future.result())
            except Exception:
                continue

    grouped = group_findings(all_findings)
    return grouped


if __name__ == "__main__":
    import json, sys
    target = sys.argv[1] if len(sys.argv) > 1 else "."
    data = scan_directory(target)
    print(json.dumps({"findings": data, "enterprise_control_summary": summarize_enterprise_controls(data)}, indent=2))
