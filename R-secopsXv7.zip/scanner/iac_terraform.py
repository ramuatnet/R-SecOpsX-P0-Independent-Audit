from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any


TF_EXTENSIONS = {".tf", ".tfvars"}


RULES = [
    {
        "rule_id": "TF_OPEN_SECURITY_GROUP_INGRESS",
        "title": "Security Group Allows Ingress From 0.0.0.0/0",
        "severity": "Critical",
        "pattern": re.compile(r'cidr_blocks\s*=\s*\[.*0\.0\.0\.0/0.*\]', re.IGNORECASE),
        "description": "Security group ingress allows traffic from the public internet.",
        "remediation": "Restrict cidr_blocks to trusted IP ranges only.",
        "cwe": "CWE-284",
        "framework": "CIS AWS Foundations Benchmark",
        "control": "Network Access Control",
    },
    {
        "rule_id": "TF_OPEN_IPV6_INGRESS",
        "title": "Security Group Allows IPv6 Ingress From ::/0",
        "severity": "Critical",
        "pattern": re.compile(r'ipv6_cidr_blocks\s*=\s*\[.*::/0.*\]', re.IGNORECASE),
        "description": "Security group ingress allows traffic from all IPv6 addresses.",
        "remediation": "Restrict ipv6_cidr_blocks to trusted IPv6 ranges only.",
        "cwe": "CWE-284",
        "framework": "CIS AWS Foundations Benchmark",
        "control": "Network Access Control",
    },
    {
        "rule_id": "TF_PUBLIC_S3_ACL",
        "title": "S3 Bucket Allows Public ACL",
        "severity": "High",
        "pattern": re.compile(r'acl\s*=\s*["\']public-(read|read-write)["\']', re.IGNORECASE),
        "description": "S3 bucket ACL is publicly accessible.",
        "remediation": "Use private ACL and enable S3 Block Public Access.",
        "cwe": "CWE-284",
        "framework": "CIS AWS Foundations Benchmark",
        "control": "S3 Public Access",
    },
    {
        "rule_id": "TF_S3_BLOCK_PUBLIC_ACCESS_DISABLED",
        "title": "S3 Block Public Access Disabled",
        "severity": "High",
        "pattern": re.compile(
            r'(block_public_acls|block_public_policy|ignore_public_acls|restrict_public_buckets)\s*=\s*false',
            re.IGNORECASE,
        ),
        "description": "S3 public access protection is disabled.",
        "remediation": "Set all S3 public access block settings to true.",
        "cwe": "CWE-284",
        "framework": "CIS AWS Foundations Benchmark",
        "control": "S3 Public Access",
    },
    {
        "rule_id": "TF_UNENCRYPTED_S3_BUCKET",
        "title": "S3 Bucket Encryption Not Configured",
        "severity": "Medium",
        "pattern": re.compile(r'resource\s+["\']aws_s3_bucket["\']', re.IGNORECASE),
        "description": "S3 bucket resource detected. Confirm server-side encryption is configured.",
        "remediation": "Add aws_s3_bucket_server_side_encryption_configuration.",
        "cwe": "CWE-311",
        "framework": "CIS AWS Foundations Benchmark",
        "control": "Data Encryption",
        "requires_absence": "aws_s3_bucket_server_side_encryption_configuration",
    },
    {
        "rule_id": "TF_RDS_PUBLICLY_ACCESSIBLE",
        "title": "RDS Instance Publicly Accessible",
        "severity": "High",
        "pattern": re.compile(r'publicly_accessible\s*=\s*true', re.IGNORECASE),
        "description": "RDS instance is publicly accessible.",
        "remediation": "Set publicly_accessible = false and place RDS in private subnets.",
        "cwe": "CWE-284",
        "framework": "CIS AWS Foundations Benchmark",
        "control": "Database Network Exposure",
    },
    {
        "rule_id": "TF_RDS_STORAGE_NOT_ENCRYPTED",
        "title": "RDS Storage Encryption Disabled",
        "severity": "High",
        "pattern": re.compile(r'storage_encrypted\s*=\s*false', re.IGNORECASE),
        "description": "RDS storage encryption is disabled.",
        "remediation": "Set storage_encrypted = true and use a managed KMS key.",
        "cwe": "CWE-311",
        "framework": "CIS AWS Foundations Benchmark",
        "control": "Database Encryption",
    },
    {
        "rule_id": "TF_EBS_ENCRYPTION_DISABLED",
        "title": "EBS Volume Encryption Disabled",
        "severity": "High",
        "pattern": re.compile(r'encrypted\s*=\s*false', re.IGNORECASE),
        "description": "Storage encryption appears disabled.",
        "remediation": "Enable encryption using KMS-managed keys.",
        "cwe": "CWE-311",
        "framework": "CIS AWS Foundations Benchmark",
        "control": "Storage Encryption",
    },
    {
        "rule_id": "TF_IAM_WILDCARD_ACTION",
        "title": "IAM Policy Allows Wildcard Action",
        "severity": "High",
        "pattern": re.compile(r'actions?\s*=\s*\[.*["\']\*["\'].*\]', re.IGNORECASE),
        "description": "IAM policy allows wildcard actions.",
        "remediation": "Replace wildcard actions with least-privilege actions.",
        "cwe": "CWE-732",
        "framework": "CIS AWS Foundations Benchmark",
        "control": "IAM Least Privilege",
    },
    {
        "rule_id": "TF_IAM_WILDCARD_RESOURCE",
        "title": "IAM Policy Allows Wildcard Resource",
        "severity": "Medium",
        "pattern": re.compile(r'resources?\s*=\s*\[.*["\']\*["\'].*\]', re.IGNORECASE),
        "description": "IAM policy applies to wildcard resources.",
        "remediation": "Restrict resources to specific ARNs.",
        "cwe": "CWE-732",
        "framework": "CIS AWS Foundations Benchmark",
        "control": "IAM Least Privilege",
    },
    
    {
    "rule_id": "TF_ADMIN_POLICY_ATTACHED",
    "title": "Administrator Policy Attached",
    "severity": "Critical",
    "pattern": re.compile(
        r"arn:aws:iam::aws:policy/AdministratorAccess",
        re.IGNORECASE
    ),
    "description": "AdministratorAccess policy is attached.",
    "remediation": "Replace AdministratorAccess with scoped least-privilege permissions.",
    "cwe": "CWE-266",
    "framework": "CIS AWS Foundations Benchmark",
    "control": "Privileged Access Management",
    },

    {
        "rule_id": "TF_HARDCODED_AWS_ACCESS_KEY",
        "title": "Hardcoded AWS Access Key in Terraform",
        "severity": "Critical",
        "pattern": re.compile(r'AKIA[0-9A-Z]{16}', re.IGNORECASE),
        "description": "AWS access key appears hardcoded in Terraform.",
        "remediation": "Remove hardcoded keys and use IAM roles or secure variable injection.",
        "cwe": "CWE-798",
        "framework": "Secret Management",
        "control": "Credential Protection",
    },
    {
        "rule_id": "TF_HARDCODED_SECRET_VALUE",
        "title": "Hardcoded Secret Value in Terraform",
        "severity": "High",
        "pattern": re.compile(
            r'(password|secret|token|access_key|secret_key)\s*=\s*["\'][^"\']{6,}["\']',
            re.IGNORECASE,
        ),
        "description": "Potential secret value is hardcoded in Terraform.",
        "remediation": "Use sensitive variables, Vault, AWS Secrets Manager, or CI/CD secret injection.",
        "cwe": "CWE-798",
        "framework": "Secret Management",
        "control": "Credential Protection",
    },
    {
        "rule_id": "TF_USER_DATA_SECRET",
        "title": "Sensitive Data in user_data",
        "severity": "Medium",
        "pattern": re.compile(r'user_data\s*=', re.IGNORECASE),
        "description": "EC2 user_data may contain bootstrap secrets or credentials.",
        "remediation": "Avoid secrets in user_data; use instance roles and secure secret retrieval.",
        "cwe": "CWE-798",
        "framework": "Secret Management",
        "control": "Credential Protection",
    },
]


def _iter_files(target: Path):
    if target.is_file():
        yield target
        return

    for path in target.rglob("*"):
        if path.is_file() and path.suffix.lower() in TF_EXTENSIONS:
            yield path


def _is_terraform_file(text: str, path: Path) -> bool:
    if path.suffix.lower() in TF_EXTENSIONS:
        return True

    markers = [
        "resource ",
        "provider ",
        "variable ",
        "module ",
        "terraform {",
        "aws_",
        "azurerm_",
        "google_",
    ]
    return any(marker in text for marker in markers)


def _report_path(file_path: Path, target_root: Path) -> str:
    try:
        return str(Path(target_root.name) / file_path.relative_to(target_root))
    except Exception:
        return str(file_path)


def _priority(severity: str) -> str:
    return {
        "Critical": "P1",
        "High": "P2",
        "Medium": "P3",
        "Low": "P4",
        "Info": "P4",
    }.get(severity, "P3")


def _finding(
    rule: dict[str, Any],
    file_path: Path,
    line: int,
    snippet: str,
    target_root: Path,
) -> dict[str, Any]:
    rel_path = _report_path(file_path, target_root)
    absolute_path = str(file_path.resolve())

    return {
        "title": rule["title"],
        "rule_id": rule["rule_id"],
        "vuln_type": rule["rule_id"].lower(),
        "category": "Cloud Infrastructure Security",
        "issue_group": "Infrastructure / IaC",
        "issue_type": rule["title"],
        "severity": rule["severity"],
        "priority": _priority(rule["severity"]),
        "confidence": "HIGH",
        "language": "terraform",
        "file": rel_path,
        "file_name": file_path.name,
        "file_path": rel_path,
        "full_path": absolute_path,
        "line": line,
        "snippet": snippet.strip(),
        "evidence": snippet.strip(),
        "description": rule["description"],
        "remediation": [rule["remediation"]],
        "recommendation": rule["remediation"],
        "cwe": rule["cwe"],
        "framework": rule["framework"],
        "control": rule["control"],
        "detection": "Terraform IaC Static Analysis",
        "occurrences": [
            {
                "file": rel_path,
                "file_name": file_path.name,
                "file_path": rel_path,
                "full_path": absolute_path,
                "line": line,
                "snippet": snippet.strip(),
            }
        ],
        "affected_files": [rel_path],
        "instances": 1,
    }


def scan_terraform(target_path: str) -> list[dict[str, Any]]:
    target = Path(target_path)
    target_root = target if target.is_dir() else target.parent
    findings: list[dict[str, Any]] = []

    for file_path in _iter_files(target):
        try:
            text = file_path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue

        if not _is_terraform_file(text, file_path):
            continue

        lines = text.splitlines()

        for rule in RULES:
            absence = rule.get("requires_absence")
            if absence and absence in text:
                continue

            for idx, line in enumerate(lines, start=1):
                if rule["pattern"].search(line):
                    findings.append(
                        _finding(
                            rule=rule,
                            file_path=file_path,
                            line=idx,
                            snippet=line,
                            target_root=target_root,
                        )
                    )

    return findings


def main() -> None:
    parser = argparse.ArgumentParser(description="R-SecOpsX Terraform IaC Scanner")
    parser.add_argument("target", help="Target Terraform file or directory")
    parser.add_argument("--output", help="Output JSON file", default=None)
    args = parser.parse_args()

    findings = scan_terraform(args.target)

    if args.output:
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(findings, indent=2), encoding="utf-8")
        print(f"[TF-IAC] Findings found: {len(findings)}")
        print(f"[TF-IAC] Output written: {output}")
    else:
        print(json.dumps(findings, indent=2))


if __name__ == "__main__":
    main()