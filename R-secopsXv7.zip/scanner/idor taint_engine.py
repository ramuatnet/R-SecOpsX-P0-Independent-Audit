"""
scanner/taint_engine.py  v7

Real data-flow taint tracking with fixes for previously missed patterns:

  FIX 1 — Inline tainted expressions in call args (no prior assignment):
           subprocess.run('ls ' + sys.argv[1], shell=True)
           Detects taint directly inside BinOp / JoinedStr passed to sink.

  FIX 2 — AugAssign propagation: cmd += request.args.get('x')
           LHS becomes tainted after any augmented assignment that includes
           a tainted RHS.

  FIX 3 — Module-level (outside functions) taint tracking already worked;
           confirmed and kept.

  KEEP  — All v6 multi-hop propagation logic retained unchanged.
           taint_path format: "source -> a -> b -> sink"
"""
from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from core.mapper import get_mapping

TAINT_SOURCES = {
    # Flask / generic HTTP
    "request.args", "request.form", "request.json", "request.data",
    "request.headers", "request.cookies", "request.values",
    "request.get_json", "request.files", "request.view_args",
    # Django
    "request.GET", "request.POST", "request.data",
    # Generic
    "input", "sys.argv", "os.environ", "os.getenv",
    "params", "query", "kwargs",
    # Path / URL params (Django CBV pk, Flask route vars)
    "pk", "uid", "user_id", "account_id", "item_id",
    # Node-style (for JS taint if added later)
    "req.query", "req.params", "req.body",
}

DANGEROUS_SINKS: dict[str, str] = {
    # SQL
    "execute":                  "sql_injection",
    "executemany":              "sql_injection",
    "raw":                      "sql_injection",
    "cursor.execute":           "sql_injection",
    # OS command
    "subprocess.call":          "command_injection",
    "subprocess.run":           "command_injection",
    "subprocess.Popen":         "command_injection",
    "os.system":                "command_injection",
    "os.popen":                 "command_injection",
    # File system
    "open":                     "path_traversal",
    "os.path.join":             "path_traversal",
    "os.listdir":               "path_traversal",
    "os.remove":                "path_traversal",
    "os.rename":                "path_traversal",
    # Code execution
    "eval":                     "code_injection",
    "exec":                     "code_injection",
    "compile":                  "code_injection",
    # Deserialization
    "pickle.load":              "insecure_deserialization",
    "pickle.loads":             "insecure_deserialization",
    "yaml.load":                "insecure_deserialization",
    "marshal.loads":            "insecure_deserialization",
    "jsonpickle.decode":        "insecure_deserialization",
    # SSRF (Issue 8: expanded)
    "requests.get":              "ssrf",
    "requests.post":             "ssrf",
    "requests.put":              "ssrf",
    "requests.delete":           "ssrf",
    "requests.request":          "ssrf",
    "urllib.request.urlopen":    "ssrf",
    "http.client.HTTPConnection":"ssrf",
    "http.client.HTTPSConnection":"ssrf",
    # IDOR sinks removed from taint_engine — owned exclusively by scanner/idor_detector.py
    # which applies proper auth suppression before flagging.
    # Redirect / XSS
    "redirect":                 "open_redirect",
    "render_template_string":   "xss",
    "Markup":                   "xss",
}


@dataclass
class TaintedVar:
    """Tracks one tainted variable and its full propagation chain."""
    name:   str
    source: str       # original source expression e.g. "request.args.get('id')"
    lineno: int
    chain:  list[str] = field(default_factory=list)

    def full_chain(self) -> list[str]:
        """[source, ...intermediates, name] — deduplicated."""
        parts = [self.source] + self.chain + [self.name]
        out: list[str] = []
        for p in parts:
            if not out or out[-1] != p:
                out.append(p)
        return out


@dataclass
class TaintFinding:
    vuln_type:   str
    source_var:  str
    source_expr: str
    sink_call:   str
    file:        str
    line:        int
    snippet:     str
    taint_path:  str    # "request.args -> a -> b -> subprocess.run"
    chain:       list[str]
    function:    str = ""


class TaintVisitor(ast.NodeVisitor):
    """
    AST visitor with variable-chain taint tracking.

    Tracks:
      - Direct source assignments: x = request.args.get('k')
      - Propagation: b = a (where a is tainted) → b also tainted
      - AugAssign: cmd += user_input → cmd becomes tainted  [FIX 2]
      - Inline tainted expressions in sink call args         [FIX 1]
      - Return value propagation: if a function returns a tainted
        variable, call sites that assign the result are also tainted.
    """

    def __init__(self, lines: list[str], filepath: str):
        self.lines     = lines
        self.filepath  = filepath
        self.tainted:  dict[str, TaintedVar] = {}
        self.findings: list[TaintFinding]    = []
        self._cur_func: str = ""
        # Maps function_name -> taint source label when it returns tainted data
        self._tainted_returns: dict[str, str] = {}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _unparse(self, node) -> str:
        try:    return ast.unparse(node)
        except: return "<expr>"

    def _snippet(self, lineno: int) -> str:
        idx = lineno - 1
        return self.lines[idx].rstrip() if 0 <= idx < len(self.lines) else ""

    def _match_source(self, node) -> Optional[str]:
        """Return source label if node is/calls a known taint source."""
        expr = self._unparse(node)

        # Exact name match (e.g. bare `input`, `query`, `kwargs`)
        for src in TAINT_SOURCES:
            if expr == src:
                return src

        # Call on a source: input(), os.getenv('X'), request.args.get('id')
        if isinstance(node, ast.Call):
            func_str = self._unparse(node.func)
            for src in TAINT_SOURCES:
                if (func_str == src
                        or func_str.startswith(src + ".")
                        or func_str.startswith(src + "[")):
                    return expr   # full call expression as source label

            # Cross-function: call to a function that is known to return taint
            if func_str in self._tainted_returns:
                return f"{func_str}() [returns tainted: {self._tainted_returns[func_str]}]"

        # Attribute/subscript on a source: request.form['username'], sys.argv[1]
        if isinstance(node, (ast.Attribute, ast.Subscript)):
            base = self._unparse(node)
            for src in TAINT_SOURCES:
                if base == src or base.startswith(src + ".") or base.startswith(src + "["):
                    return base

        return None

    def _tainted_names_in(self, node) -> list[str]:
        """Return names of all tainted variables referenced inside an expression."""
        seen: list[str] = []
        for child in ast.walk(node):
            if isinstance(child, ast.Name) and child.id in self.tainted:
                if child.id not in seen:
                    seen.append(child.id)
        return seen

    def _source_exprs_in(self, node) -> list[str]:
        """
        FIX 1: Find taint sources embedded directly inside an expression
        (without a prior assignment variable).
        E.g. in: subprocess.run('ls ' + sys.argv[1], shell=True)
        sys.argv[1] is a source used inline.
        """
        sources: list[str] = []
        for child in ast.walk(node):
            src = self._match_source(child)
            if src and src not in sources:
                sources.append(src)
        return sources

    def _chain_for(self, var_name: str) -> list[str]:
        if var_name in self.tainted:
            return self.tainted[var_name].full_chain()
        return [var_name]

    def _make_path(self, chain: list[str], sink: str) -> str:
        parts = chain + [sink]
        out: list[str] = []
        for p in parts:
            if not out or out[-1] != p:
                out.append(p)
        return " -> ".join(out)

    def _record(self, vuln_type: str, chain: list[str],
                sink_str: str, call_node: ast.Call):
        lineno  = call_node.lineno
        snippet = self._snippet(lineno)
        path    = self._make_path(chain, sink_str)
        self.findings.append(TaintFinding(
            vuln_type=vuln_type,
            source_var=chain[0] if chain else "",
            source_expr=chain[0] if chain else "",
            sink_call=sink_str,
            file=self.filepath,
            line=lineno,
            snippet=snippet,
            taint_path=path,
            chain=chain,
            function=self._cur_func,
        ))

    # ------------------------------------------------------------------
    # Sink detection
    # ------------------------------------------------------------------

    def _check_sink(self, call: ast.Call):
        call_str = self._unparse(call.func)

        for sink_key, vuln_type in DANGEROUS_SINKS.items():
            if call_str != sink_key and not call_str.endswith("." + sink_key):
                continue

            all_args = list(call.args) + [kw.value for kw in call.keywords]

            # Primary: tainted variable in argument
            for arg in all_args:
                names = self._tainted_names_in(arg)
                if names:
                    chain = self._chain_for(names[0])
                    self._record(vuln_type, chain, call_str, call)
                    return

            # FIX 1: inline source expression in argument (no prior variable)
            for arg in all_args:
                srcs = self._source_exprs_in(arg)
                if srcs:
                    self._record(vuln_type, [srcs[0]], call_str, call)
                    return

    # ------------------------------------------------------------------
    # Assignment tracking
    # ------------------------------------------------------------------

    def visit_Assign(self, node: ast.Assign):
        rhs = node.value
        src_label = self._match_source(rhs)

        if src_label is not None:
            # Fresh taint: x = request.args.get('k')
            for t in node.targets:
                if isinstance(t, ast.Name):
                    self.tainted[t.id] = TaintedVar(
                        name=t.id, source=src_label,
                        lineno=node.lineno, chain=[],
                    )
        else:
            # Propagation: b = a  (where a is tainted)
            names = self._tainted_names_in(rhs)
            if names:
                parent = self.tainted[names[0]]
                for t in node.targets:
                    if isinstance(t, ast.Name):
                        new_chain = parent.full_chain() + [t.id]
                        self.tainted[t.id] = TaintedVar(
                            name=t.id, source=parent.source,
                            lineno=node.lineno,
                            chain=new_chain[1:],  # source already in .source
                        )

        self.generic_visit(node)

    def visit_AugAssign(self, node: ast.AugAssign):
        """
        FIX 2: cmd += request.args.get('x')
        If either the LHS is already tainted OR the RHS contains a source/
        tainted variable, mark LHS as tainted.
        """
        if not isinstance(node.target, ast.Name):
            self.generic_visit(node)
            return

        t_name = node.target.id
        rhs    = node.value

        src_label = self._match_source(rhs)
        names_in_rhs = self._tainted_names_in(rhs)

        if src_label is not None:
            # RHS is a source: cmd += input()
            if t_name in self.tainted:
                # extend existing chain
                existing = self.tainted[t_name]
                existing.chain.append(src_label)
            else:
                self.tainted[t_name] = TaintedVar(
                    name=t_name, source=src_label,
                    lineno=node.lineno, chain=[],
                )
        elif names_in_rhs:
            # RHS contains a tainted variable: cmd += tainted_var
            parent = self.tainted[names_in_rhs[0]]
            if t_name not in self.tainted:
                new_chain = parent.full_chain() + [t_name]
                self.tainted[t_name] = TaintedVar(
                    name=t_name, source=parent.source,
                    lineno=node.lineno, chain=new_chain[1:],
                )
        elif t_name in self.tainted:
            # LHS already tainted, += clean value — taint persists
            pass

        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef):
        prev = self._cur_func
        self._cur_func = node.name
        self.generic_visit(node)
        self._cur_func = prev

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_Return(self, node: ast.Return):
        """
        Cross-function taint: if a function returns tainted data (either a
        tainted variable OR a direct taint source expression), record it so
        call sites can propagate taint to their LHS.
        """
        if node.value is not None and self._cur_func:
            # Case 1: returning a tainted variable
            names = self._tainted_names_in(node.value)
            if names:
                src_chain = self._chain_for(names[0])
                self._tainted_returns[self._cur_func] = " -> ".join(src_chain)
            else:
                # Case 2: returning a direct source (e.g. return request.args.get('x'))
                src_label = self._match_source(node.value)
                if src_label and "[returns tainted" not in src_label:
                    self._tainted_returns[self._cur_func] = src_label
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        self._check_sink(node)
        self.generic_visit(node)


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def analyze_file(filepath: str) -> list[dict]:
    """Run taint analysis on a single Python file."""
    path = Path(filepath)
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    lines = source.splitlines()

    # ── Pre-scan pass: collect which functions return tainted data ────────────
    # This allows the main pass to propagate taint across function call
    # boundaries (e.g. cmd = get_user_input() → subprocess.run(cmd)).
    pre = TaintVisitor(lines, filepath)
    pre.visit(tree)
    tainted_returns = dict(pre._tainted_returns)

    # ── Main pass: full taint analysis with cross-function context ────────────
    visitor = TaintVisitor(lines, filepath)
    visitor._tainted_returns = tainted_returns  # seed from pre-scan
    visitor.visit(tree)

    findings = []
    for tf in visitor.findings:
        m       = get_mapping(tf.vuln_type)
        snippet = tf.snippet.strip()
        group_key = f"{tf.vuln_type}|{tf.sink_call}"  # sink-based key for cross-file dedup

        findings.append({
            "title":           m.get("title", tf.vuln_type),
            "vuln_type":       tf.vuln_type,
            "severity":        m.get("severity",        "High"),
            "priority":        m.get("priority",        "P2"),
            "confidence":      "High",
            "language":        "python",
            "file":            tf.file,
            "line":            tf.line,
            "snippet":         snippet,
            "group_key":       group_key,
            "function":        tf.function,
            "description":     f"Taint flow: {tf.taint_path}",
            "owasp":           m.get("owasp",           ""),
            "owasp_id":        m.get("owasp_id",        ""),
            "mitre":           m.get("mitre",           ""),
            "mitre_desc":      m.get("mitre_desc",      ""),
            "cwe":             m.get("cwe",             ""),
            "cwe_desc":        m.get("cwe_desc",        ""),
            "pci_dss":         m.get("pci_dss",         ""),
            "nist":            m.get("nist",            ""),
            "iso27001":        m.get("iso27001",        ""),
            "soc2":            m.get("soc2",            ""),
            "business_impact": m.get("business_impact", ""),
            "remediation":     m.get("remediation",     []),
            "exploitability":  m.get("exploitability",  "High"),
            "taint_path":      tf.taint_path,
            "taint_chain":     tf.chain,
            "source_expr":     tf.source_expr,
            "sink_call":       tf.sink_call,
            "detection":       (
                "TAINT-VALIDATED"   # real source→sink data flow confirmed
                if tf.taint_path and "->" in str(tf.taint_path)
                else "AST Taint Analysis"
            ),
            "cvss":            None,
            "cve":             None,
        })

    return findings
