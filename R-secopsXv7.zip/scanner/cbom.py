from __future__ import annotations

import re
from pathlib import Path


SCANNABLE_EXT = {
    ".py", ".js", ".ts", ".java", ".go", ".rb", ".php",
    ".cs", ".cpp", ".c", ".h", ".yml", ".yaml", ".xml",
    ".config", ".properties", ".env"
}


CRYPTO_RULES = [
    {
        "component": "MD5",
        "category": "Weak Hashing",
        "pattern": re.compile(r"\b(hashlib\.md5|MD5|md5)\s*\(", re.I),
        "risk": "HIGH",
        "recommendation": "Replace MD5 with SHA-256 or stronger approved hashing."
    },
    {
        "component": "SHA1",
        "category": "Weak Hashing",
        "pattern": re.compile(r"\b(hashlib\.sha1|SHA1|sha1)\s*\(", re.I),
        "risk": "HIGH",
        "recommendation": "Replace SHA-1 with SHA-256 or SHA-3."
    },
    {
        "component": "DES / 3DES",
        "category": "Weak Encryption",
        "pattern": re.compile(r"\b(DES|TripleDES|3DES|DESede)\b", re.I),
        "risk": "CRITICAL",
        "recommendation": "Replace DES/3DES with AES-256-GCM or ChaCha20-Poly1305."
    },
    {
        "component": "RC4",
        "category": "Weak Encryption",
        "pattern": re.compile(r"\bRC4\b", re.I),
        "risk": "CRITICAL",
        "recommendation": "Remove RC4. Use modern authenticated encryption."
    },
    {
        "component": "AES",
        "category": "Approved Encryption",
        "pattern": re.compile(r"\bAES\b|AES\.new|Cipher\.getInstance\([\"']AES", re.I),
        "risk": "LOW",
        "recommendation": "Verify AES mode is GCM/CTR with secure key management."
    },
    {
        "component": "RSA",
        "category": "Asymmetric Cryptography",
        "pattern": re.compile(r"\bRSA\b|generate_private_key|RSAPrivateKey", re.I),
        "risk": "MEDIUM",
        "recommendation": "Verify RSA key size is at least 2048-bit; plan PQC migration."
    },
    {
        "component": "ECC",
        "category": "Asymmetric Cryptography",
        "pattern": re.compile(r"\b(ECDSA|ECDH|EllipticCurve|secp256r1|prime256v1)\b", re.I),
        "risk": "MEDIUM",
        "recommendation": "Verify approved curves and plan post-quantum transition."
    },
    {
        "component": "TLS / SSL",
        "category": "Transport Cryptography",
        "pattern": re.compile(r"\b(ssl|SSLContext|TLS|PROTOCOL_TLS|PROTOCOL_SSL)\b", re.I),
        "risk": "MEDIUM",
        "recommendation": "Ensure TLS 1.2+ only; disable SSL/TLS 1.0/1.1."
    },
    {
        "component": "Hardcoded Private Key",
        "category": "Key Material",
        "pattern": re.compile(r"-----BEGIN (RSA |EC |DSA )?PRIVATE KEY-----", re.I),
        "risk": "CRITICAL",
        "recommendation": "Remove private key from source and rotate exposed key material."
    },
    {
        "component": "Hardcoded Certificate",
        "category": "Certificate Material",
        "pattern": re.compile(r"-----BEGIN CERTIFICATE-----", re.I),
        "risk": "MEDIUM",
        "recommendation": "Verify certificate purpose and avoid embedding sensitive material."
    },
]


def _should_scan(path: Path) -> bool:
    return path.is_file() and path.suffix.lower() in SCANNABLE_EXT


def _make_cbom_item(rule: dict, filepath: str, line: int, evidence: str) -> dict:
    return {
        "bom_type": "CBOM",
        "component": rule["component"],
        "category": rule["category"],
        "file": filepath,
        "line": line,
        "evidence": evidence.strip(),
        "risk": rule["risk"],
        "recommendation": rule["recommendation"],
    }


def scan_file(filepath: str) -> list[dict]:
    path = Path(filepath)

    if not _should_scan(path):
        return []

    try:
        source = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    findings = []
    lines = source.splitlines()

    for rule in CRYPTO_RULES:
        for match in rule["pattern"].finditer(source):
            line_no = source[:match.start()].count("\n") + 1
            evidence = lines[line_no - 1] if 0 <= line_no - 1 < len(lines) else ""

            if evidence.lstrip().startswith(("#", "//", "*")):
                continue

            findings.append(
                _make_cbom_item(
                    rule,
                    str(path),
                    line_no,
                    evidence
                )
            )

    return findings


def generate_cbom(target_path: str) -> list[dict]:
    target = Path(target_path)

    results = []

    if target.is_file():
        return scan_file(str(target))

    if not target.exists():
        return []

    for path in target.rglob("*"):
        if _should_scan(path):
            results.extend(scan_file(str(path)))

    return results


if __name__ == "__main__":
    import argparse
    import json

    parser = argparse.ArgumentParser()
    parser.add_argument("target")
    parser.add_argument("--output", default="cbom.json")
    args = parser.parse_args()

    cbom = generate_cbom(args.target)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(cbom, f, indent=2)

    print(f"[CBOM] Items found: {len(cbom)}")
    print(f"[CBOM] Output written: {args.output}")