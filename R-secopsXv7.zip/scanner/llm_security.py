from __future__ import annotations

import re


LLM_RULES = [
    {
        "rule_id": "LLM01_PROMPT_INJECTION",
        "title": "LLM Prompt Injection Risk",
        "patterns": [
            r"ignore\s+previous\s+instructions",
            r"system\s*prompt",
            r"override\s+instructions",
            r"jailbreak",
            r"prompt\s*=\s*input\(",
        ],
        "severity": "High",
        "vuln_type": "llm_prompt_injection",
    },
    {
        "rule_id": "LLM02_INSECURE_OUTPUT_HANDLING",
        "title": "LLM Insecure Output Handling",
        "patterns": [
            r"eval\(",
            r"exec\(",
            r"os\.system\(",
            r"subprocess\.",
        ],
        "severity": "Critical",
        "vuln_type": "llm_insecure_output",
    },
    {
        "rule_id": "LLM03_TRAINING_DATA_POISONING",
        "title": "LLM Training Data Poisoning Risk",
        "patterns": [
            r"load_training_data",
            r"train_model",
            r"fine_tune",
            r"external_dataset",
        ],
        "severity": "High",
        "vuln_type": "llm_data_poisoning",
    },
    {
        "rule_id": "LLM04_MODEL_DENIAL_OF_SERVICE",
        "title": "LLM Model DoS Risk",
        "patterns": [
            r"max_tokens\s*=\s*999999",
            r"while\s+True",
            r"for\s+.*range\(999999",
        ],
        "severity": "High",
        "vuln_type": "llm_model_dos",
    },
    {
        "rule_id": "LLM05_SUPPLY_CHAIN_VULNERABILITY",
        "title": "LLM Supply Chain Risk",
        "patterns": [
            r"from\s+langchain",
            r"from\s+llama_index",
            r"pip\s+install",
            r"model_download",
        ],
        "severity": "High",
        "vuln_type": "llm_supply_chain",
    },
    {
        "rule_id": "LLM06_SENSITIVE_INFORMATION_DISCLOSURE",
        "title": "LLM Sensitive Information Disclosure",
        "patterns": [
            r"print\(.*api[_-]?key",
            r"print\(.*secret",
            r"print\(.*system[_-]?prompt",
            r"return.*api[_-]?key",
            r"return.*secret",
            r"return.*token",
            r"system[_-]?prompt\s*=",
            r"prompt_template.*secret",
            r"memory.*secret",
            r"vector.*secret",
            r"OPENAI_API_KEY\s*=",
            r"ANTHROPIC_API_KEY\s*=",
        ],
        "severity": "Critical",
        "vuln_type": "llm_sensitive_disclosure",
    },
    {
        "rule_id": "LLM07_INSECURE_PLUGIN_DESIGN",
        "title": "LLM Insecure Plugin Design",
        "patterns": [
            r"plugin.execute",
            r"tool.run",
            r"browser.open",
            r"shell.exec",
        ],
        "severity": "High",
        "vuln_type": "llm_insecure_plugin",
    },
    {
        "rule_id": "LLM08_EXCESSIVE_AGENCY",
        "title": "LLM Excessive Agency",
        "patterns": [
            r"auto_approve\s*=\s*True",
            r"approval_required\s*=\s*False",
            r"run_shell\s*=\s*True",
        ],
        "severity": "Critical",
        "vuln_type": "llm_excessive_agency",
    },
    {
        "rule_id": "LLM09_OVERRELIANCE",
        "title": "LLM Overreliance Risk",
        "patterns": [
            r"accept_response_without_validation",
            r"trust_model_output",
            r"auto_execute_response",
        ],
        "severity": "Medium",
        "vuln_type": "llm_overreliance",
    },
    
    {
    "rule_id": "LLM10_MODEL_THEFT",
    "title": "LLM Model Theft Risk",
    "patterns": [
        r"download_model",
        r"export_model_weights",
        r"model\.state_dict",
        r"torch\.save\(.*model",
        r"pickle\.dump\(.*model",
        r"save_pretrained",
        r"dump_embeddings",
        r"copy_checkpoint",
        r"checkpoint.*copy",
    ],
    "severity": "Critical",
    "vuln_type": "llm_model_theft",
},

{
    "rule_id": "RAG_UNTRUSTED_RETRIEVAL",
    "title": "RAG Untrusted Retrieval Source",
    "patterns": [
        r"retriever\.add_documents\(.*user",
        r"vectorstore\.add_documents\(.*user",
        r"load_documents\(.*external",
        r"untrusted_retrieval",
    ],
    "severity": "High",
    "vuln_type": "rag_untrusted_retrieval",
},
{
    "rule_id": "RAG_NO_SOURCE_GROUNDING",
    "title": "RAG Missing Source Grounding",
    "patterns": [
        r"return\s+answer\s*$",
        r"source_required\s*=\s*False",
        r"citations_required\s*=\s*False",
        r"without_source_grounding",
    ],
    "severity": "Medium",
    "vuln_type": "rag_no_source_grounding",
},
{
    "rule_id": "MEMORY_PERSISTENCE_RISK",
    "title": "AI Memory Persistence Risk",
    "patterns": [
        r"memory\.save_context",
        r"persistent_memory\s*=\s*True",
        r"store_user_memory",
        r"save_chat_history",
    ],
    "severity": "High",
    "vuln_type": "ai_memory_persistence",
},
{
    "rule_id": "MEMORY_CROSS_TENANT_LEAKAGE",
    "title": "AI Memory Cross-Tenant Leakage Risk",
    "patterns": [
        r"global_memory",
        r"shared_memory",
        r"tenant_id\s*=\s*None",
        r"cross_tenant_memory",
    ],
    "severity": "Critical",
    "vuln_type": "ai_memory_cross_tenant_leakage",
},
{
    "rule_id": "TOOL_APPROVAL_BYPASS",
    "title": "AI Tool Approval Bypass",
    "patterns": [
        r"approval_required\s*=\s*False",
        r"human_approval\s*=\s*False",
        r"skip_approval\s*=\s*True",
        r"auto_approve\s*=\s*True",
    ],
    "severity": "Critical",
    "vuln_type": "ai_tool_approval_bypass",
},
{
    "rule_id": "AUTONOMOUS_TOOL_EXECUTION",
    "title": "Autonomous Tool Execution Risk",
    "patterns": [
        r"run_shell\s*=\s*True",
        r"shell\.exec",
        r"tool\.run\(.*user",
        r"os\.system\(.*user",
    ],
    "severity": "Critical",
    "vuln_type": "ai_autonomous_tool_execution",
},
{
    "rule_id": "EMBEDDING_DATA_EXPOSURE",
    "title": "Embedding Data Exposure Risk",
    "patterns": [
        r"dump_embeddings",
        r"export_embeddings",
        r"embedding_store\.dump",
        r"vectorstore\.persist",
    ],
    "severity": "High",
    "vuln_type": "embedding_data_exposure",
},
{
    "rule_id": "MODEL_GOVERNANCE_MISSING_OWNER",
    "title": "Model Governance Missing Owner",
    "patterns": [
        r"model_owner\s*=\s*None",
        r"owner\s*=\s*\"\"",
        r"missing_model_owner",
    ],
    "severity": "Medium",
    "vuln_type": "model_governance_missing_owner",
},
{
    "rule_id": "MODEL_GOVERNANCE_MISSING_MODEL_CARD",
    "title": "Model Governance Missing Model Card",
    "patterns": [
        r"model_card\s*=\s*None",
        r"model_card_required\s*=\s*False",
        r"missing_model_card",
    ],
    "severity": "Medium",
    "vuln_type": "model_governance_missing_model_card",
},

{
    "rule_id": "RAG_POISONING",
    "title": "RAG Poisoning Risk",
    "patterns": [
        r"retriever\.add_documents\(.*user",
        r"vectorstore\.add_documents\(.*user",
        r"rag_poisoning",
        r"untrusted_documents",
    ],
    "severity": "High",
    "vuln_type": "rag_poisoning",
},
{
    "rule_id": "SOURCE_GROUNDING_MISSING",
    "title": "Source Grounding Missing",
    "patterns": [
        r"source_required\s*=\s*False",
        r"citations_required\s*=\s*False",
        r"without_source_grounding",
        r"return\s+answer\s*$",
    ],
    "severity": "Medium",
    "vuln_type": "source_grounding_missing",
},
{
    "rule_id": "UNSAFE_FUNCTION_CALLING",
    "title": "Unsafe Function Calling",
    "patterns": [
        r"function_call\s*=\s*[\"']auto[\"']",
        r"tool_choice\s*=\s*[\"']auto[\"']",
        r"allow_arbitrary_input\s*=\s*True",
        r"execute_function\(.*user",
    ],
    "severity": "High",
    "vuln_type": "unsafe_function_calling",
},
{
    "rule_id": "UNSAFE_AUTONOMOUS_DECISION",
    "title": "Unsafe Autonomous Decision",
    "patterns": [
        r"auto_execute_decision\s*=\s*True",
        r"autonomous_decision\s*=\s*True",
        r"decision_review_required\s*=\s*False",
    ],
    "severity": "High",
    "vuln_type": "unsafe_autonomous_decision",
},
{
    "rule_id": "NO_HUMAN_REVIEW",
    "title": "No Human Review for AI Decision",
    "patterns": [
        r"human_review_required\s*=\s*False",
        r"human_in_the_loop\s*=\s*False",
        r"skip_human_review\s*=\s*True",
    ],
    "severity": "High",
    "vuln_type": "no_human_review",
},
{
    "rule_id": "SYSTEM_PROMPT_EXPOSURE",
    "title": "System Prompt Exposure",
    "patterns": [
        r"print\(.*system[_-]?prompt",
        r"return.*system[_-]?prompt",
        r"system[_-]?prompt.*response",
        r"expose_system_prompt",
    ],
    "severity": "Critical",
    "vuln_type": "system_prompt_exposure",
},
{
    "rule_id": "PROMPT_TEMPLATE_SECRET_EXPOSURE",
    "title": "Prompt Template Secret Exposure",
    "patterns": [
        r"prompt_template.*api[_-]?key",
        r"prompt_template.*secret",
        r"template.*password",
        r"template.*token",
    ],
    "severity": "Critical",
    "vuln_type": "prompt_template_secret_exposure",
},
{
    "rule_id": "MODEL_GOVERNANCE_INCOMPLETE",
    "title": "Model Governance Incomplete",
    "patterns": [
        r"model_owner\s*=\s*None",
        r"model_card\s*=\s*None",
        r"model_approval\s*=\s*False",
        r"governance_review\s*=\s*False",
    ],
    "severity": "Medium",
    "vuln_type": "model_governance_incomplete",
},
{
    "rule_id": "UNSIGNED_OR_UNTRUSTED_MODEL_LOADING",
    "title": "Unsigned or Untrusted Model Loading",
    "patterns": [
        r"torch\.load\(.*http",
        r"load_model\(.*http",
        r"from_pretrained\(.*trust_remote_code\s*=\s*True",
        r"untrusted_model_source",
    ],
    "severity": "High",
    "vuln_type": "unsigned_or_untrusted_model_loading",
},
{
    "rule_id": "PROMPT_RESPONSE_LOGGING_SENSITIVE_DATA",
    "title": "Prompt Response Logging Sensitive Data",
    "patterns": [
        r"log.*prompt",
        r"log.*response",
        r"logger.*api[_-]?key",
        r"logger.*secret",
    ],
    "severity": "High",
    "vuln_type": "prompt_response_logging_sensitive_data",
},

{
    "rule_id": "SOURCE_GROUNDING_MISSING",
    "title": "Source Grounding Missing",
    "patterns": [
        r"source_required\s*=\s*False",
        r"citations_required\s*=\s*False",
        r"without_source_grounding",
        r"return\s+answer\s*$",
    ],
    "severity": "Medium",
    "vuln_type": "source_grounding_missing",
},
{
    "rule_id": "MEMORY_CROSS_TENANT_LEAKAGE",
    "title": "AI Memory Cross-Tenant Leakage Risk",
    "patterns": [
        r"global_memory",
        r"shared_memory",
        r"tenant_id\s*=\s*None",
        r"cross_tenant_memory",
    ],
    "severity": "Critical",
    "vuln_type": "ai_memory_cross_tenant_leakage",
},
{
    "rule_id": "PROMPT_TEMPLATE_SECRET_EXPOSURE",
    "title": "Prompt Template Secret Exposure",
    "patterns": [
        r"prompt_template.*api[_-]?key",
        r"prompt_template.*secret",
        r"template.*password",
        r"template.*token",
    ],
    "severity": "Critical",
    "vuln_type": "prompt_template_secret_exposure",
},
{
    "rule_id": "MODEL_GOVERNANCE_INCOMPLETE",
    "title": "Model Governance Incomplete",
    "patterns": [
        r"model_owner\s*=\s*None",
        r"model_card\s*=\s*None",
        r"model_approval\s*=\s*False",
        r"governance_review\s*=\s*False",
    ],
    "severity": "Medium",
    "vuln_type": "model_governance_incomplete",
},
{
    "rule_id": "UNTRUSTED_MODEL_LOADING",
    "title": "Untrusted Model Loading",
    "patterns": [
        r"torch\.load\(.*http",
        r"load_model\(.*http",
        r"from_pretrained\(.*trust_remote_code\s*=\s*True",
        r"untrusted_model_source",
    ],
    "severity": "High",
    "vuln_type": "untrusted_model_loading",
},
{
    "rule_id": "UNSAFE_AUTONOMOUS_DECISION",
    "title": "Unsafe Autonomous Decision",
    "patterns": [
        r"auto_execute_decision\s*=\s*True",
        r"autonomous_decision\s*=\s*True",
        r"decision_review_required\s*=\s*False",
    ],
    "severity": "High",
    "vuln_type": "unsafe_autonomous_decision",
},

{
    "rule_id": "DATA_UNTRUSTED_TRAINING_UPLOAD",
    "title": "Untrusted Training Data Upload",
    "patterns": [
        r"untrusted_user_training_upload",
        r"external_dataset",
        r"user_uploaded_training_data",
        r"train_model\(.*user",
    ],
    "severity": "High",
    "vuln_type": "ai_data_lineage_risk",
},

{
    "rule_id": "REG_MODEL_CHECKSUM_MISSING",
    "title": "Model Registry Checksum Missing",
    "patterns": [
        r"no_checksum_verification",
        r"checksum\s*=\s*None",
        r"verify_checksum\s*=\s*False",
        r"skip_checksum\s*=\s*True",
    ],
    "severity": "Critical",
    "vuln_type": "model_registry_integrity_risk",
},
{
    "rule_id": "AGENT_BROWSER_AUTOMATION_ABUSE",
    "title": "Agent Browser Automation Abuse",
    "patterns": [
        r"browser_automation_abuse",
        r"browser\.open\(.*user",
        r"page\.goto\(.*user",
        r"playwright.*user",
    ],
    "severity": "Critical",
    "vuln_type": "agent_browser_automation_abuse",
},
{
    "rule_id": "AGENT_EMAIL_EXFILTRATION",
    "title": "Agent Email Exfiltration Risk",
    "patterns": [
        r"email_exfiltration",
        r"send_email\(.*secret",
        r"smtp.*exfiltrate",
        r"mail.*token",
    ],
    "severity": "Critical",
    "vuln_type": "agent_email_exfiltration",
},
{
    "rule_id": "PSC_PROMPT_SIGNING_MISSING",
    "title": "Prompt Supply Chain Signing Missing",
    "patterns": [
        r"prompt_signing_missing",
        r"verify_prompt_signature\s*=\s*False",
        r"prompt_signature\s*=\s*None",
        r"unsigned_prompt_template",
    ],
    "severity": "Critical",
    "vuln_type": "prompt_supply_chain_signing_missing",
},
{
    "rule_id": "VDB_VECTOR_DB_EXPOSURE",
    "title": "Vector Database Exposure",
    "patterns": [
        r"vector_db_exposure",
        r"qdrant.*api_key\s*=",
        r"pinecone.*api_key\s*=",
        r"weaviate.*anonymous",
        r"chroma_server_host\s*=\s*[\"']0\.0\.0\.0",
    ],
    "severity": "High",
    "vuln_type": "vector_database_exposure",
},
{
    "rule_id": "RUN_UNSAFE_RUNTIME_TOOL",
    "title": "Unsafe Runtime Tool Execution",
    "patterns": [
        r"unsafe_runtime_tool",
        r"runtime_tool.*shell",
        r"execute_runtime_tool\(.*user",
        r"tool_runtime_approval\s*=\s*False",
    ],
    "severity": "Critical",
    "vuln_type": "unsafe_runtime_tool_execution",
},
{
    "rule_id": "GOV_MODEL_APPROVAL_MISSING",
    "title": "Model Approval Missing",
    "patterns": [
        r"model_approval_missing",
        r"model_approval\s*=\s*False",
        r"governance_review\s*=\s*False",
        r"approval_status\s*=\s*[\"']none[\"']",
    ],
    "severity": "Medium",
    "vuln_type": "model_approval_missing",
},
{
    "rule_id": "COMP_AI_POLICY_MISSING",
    "title": "AI Policy Compliance Missing",
    "patterns": [
        r"ai_policy_missing",
        r"policy_check\s*=\s*False",
        r"compliance_check\s*=\s*False",
        r"risk_assessment\s*=\s*None",
    ],
    "severity": "Medium",
    "vuln_type": "ai_policy_compliance_missing",
},
{
    "rule_id": "AI_PROVIDER_SECRET_EXPOSURE",
    "title": "AI Provider Secret Exposure",
    "patterns": [
        r"OPENAI_API_KEY\s*=",
        r"ANTHROPIC_API_KEY\s*=",
        r"VERTEX_AI_KEY\s*=",
        r"GOOGLE_APPLICATION_CREDENTIALS",
        r"AZURE_OPENAI_API_KEY\s*=",
    ],
    "severity": "Critical",
    "vuln_type": "ai_provider_secret_exposure",
},

]



# Enterprise remediation metadata for LLM / Agentic AI findings.
# This prevents reports from falling back to generic text such as
# "Follow secure coding best practices" and gives engineers actionable fixes.
OWASP_LLM_MAP = {
    "LLM01_PROMPT_INJECTION": "LLM01:2025 - Prompt Injection",
    "LLM02_INSECURE_OUTPUT_HANDLING": "LLM02:2025 - Sensitive Information Disclosure / Insecure Output Handling",
    "LLM03_TRAINING_DATA_POISONING": "LLM03:2025 - Supply Chain / Data and Model Poisoning",
    "LLM04_MODEL_DENIAL_OF_SERVICE": "LLM04:2025 - Model Denial of Service",
    "LLM05_SUPPLY_CHAIN_VULNERABILITY": "LLM05:2025 - Supply Chain Vulnerabilities",
    "LLM06_SENSITIVE_INFORMATION_DISCLOSURE": "LLM02:2025 - Sensitive Information Disclosure",
    "LLM07_INSECURE_PLUGIN_DESIGN": "LLM07:2025 - Insecure Plugin / Tool Design",
    "LLM08_EXCESSIVE_AGENCY": "LLM06:2025 - Excessive Agency",
    "LLM09_OVERRELIANCE": "LLM09:2025 - Overreliance",
    "LLM10_MODEL_THEFT": "LLM10:2025 - Model Theft",
}

CWE_MAP = {
    "llm_prompt_injection": "CWE-20",
    "llm_insecure_output": "CWE-94",
    "llm_sensitive_disclosure": "CWE-200",
    "system_prompt_exposure": "CWE-200",
    "prompt_template_secret_exposure": "CWE-798",
    "prompt_response_logging_sensitive_data": "CWE-532",
    "llm_insecure_plugin": "CWE-749",
    "llm_excessive_agency": "CWE-269",
    "ai_autonomous_tool_execution": "CWE-78",
    "ai_tool_approval_bypass": "CWE-306",
    "unsafe_function_calling": "CWE-20",
    "unsafe_runtime_tool_execution": "CWE-78",
    "unsafe_autonomous_decision": "CWE-840",
    "no_human_review": "CWE-840",
    "rag_poisoning": "CWE-20",
    "rag_untrusted_retrieval": "CWE-20",
    "source_grounding_missing": "CWE-345",
    "rag_no_source_grounding": "CWE-345",
    "embedding_data_exposure": "CWE-200",
    "vector_database_exposure": "CWE-200",
    "ai_memory_persistence": "CWE-359",
    "ai_memory_cross_tenant_leakage": "CWE-200",
    "model_governance_missing_owner": "CWE-1059",
    "model_governance_missing_model_card": "CWE-1059",
    "model_governance_incomplete": "CWE-1059",
    "model_approval_missing": "CWE-1059",
    "ai_policy_compliance_missing": "CWE-1059",
    "unsigned_or_untrusted_model_loading": "CWE-494",
    "untrusted_model_loading": "CWE-494",
    "model_registry_integrity_risk": "CWE-353",
    "llm_model_theft": "CWE-200",
    "agent_browser_automation_abuse": "CWE-918",
    "agent_email_exfiltration": "CWE-200",
    "prompt_supply_chain_signing_missing": "CWE-347",
    "ai_provider_secret_exposure": "CWE-798",
    "ai_data_lineage_risk": "CWE-345",
    "llm_data_poisoning": "CWE-345",
    "llm_model_dos": "CWE-400",
    "llm_supply_chain": "CWE-1104",
    "llm_overreliance": "CWE-840",
}

DEFAULT_LLM_REMEDIATION = [
    "Perform threat modeling for the affected AI workflow and identify user-controlled inputs, tool calls, model outputs, and downstream actions.",
    "Apply least privilege to model, agent, tool, data, and runtime permissions.",
    "Add validation, logging, monitoring, and human review for high-risk AI decisions or actions.",
]

REMEDIATION_BY_VULN_TYPE = {
    "ai_autonomous_tool_execution": [
        "Require explicit human approval before executing shell, file, network, cloud, or deployment tools.",
        "Restrict agent tools using an allow-list of approved commands and approved target resources.",
        "Block direct shell execution such as shell.exec unless routed through a controlled broker.",
        "Run tools in a sandbox with least-privilege permissions, timeout limits, and audit logging.",
        "Validate tool arguments to prevent command injection, file deletion, data exfiltration, or privilege escalation.",
    ],
    "llm_insecure_plugin": [
        "Require authentication, authorization, and scope checks before any plugin or tool action executes.",
        "Use a tool allow-list and deny direct access to shell, browser, file system, deployment, and credential operations by default.",
        "Validate and normalize plugin parameters before execution; reject user-controlled command strings.",
        "Run plugins in an isolated sandbox with network, file, and process restrictions.",
        "Log tool requests, approvals, parameters, and execution results for audit and incident response.",
    ],
    "llm_insecure_output": [
        "Never execute LLM output directly using eval(), exec(), shell commands, subprocess, or dynamic code loaders.",
        "Treat all model output as untrusted input and validate it against a strict schema.",
        "Use deterministic allow-listed actions instead of free-form model-generated commands.",
        "Add output filtering for unsafe code, shell metacharacters, secrets, URLs, and sensitive operations.",
        "Require human approval for high-risk actions such as command execution, file writes, deployment, or data deletion.",
    ],
    "llm_sensitive_disclosure": [
        "Do not place secrets, credentials, system prompts, internal policy, or privileged instructions in user-visible model context.",
        "Redact secrets and sensitive headers before sending prompts or logs to model providers.",
        "Separate system prompts from user-controlled content and prevent prompt concatenation without boundaries.",
        "Add response filtering to block disclosure of secrets, tokens, credentials, internal URLs, or system prompts.",
        "Disable prompt/response logging for sensitive data or apply irreversible redaction before storage.",
    ],
    "system_prompt_exposure": [
        "Do not concatenate system prompts directly with user input.",
        "Store system prompts server-side and never return them in API responses, logs, or debug traces.",
        "Use role-separated message structures instead of raw prompt string concatenation.",
        "Add prompt-injection checks for requests asking to reveal instructions, policies, secrets, or hidden context.",
        "Monitor and alert on repeated attempts to extract system prompts or internal instructions.",
    ],
    "prompt_response_logging_sensitive_data": [
        "Disable prompt and response logging for sensitive workflows unless a documented business need exists.",
        "Apply irreversible redaction for secrets, tokens, PII, authentication headers, and system prompts before storage.",
        "Restrict log access using least privilege and separate duties for operations, developers, and support teams.",
        "Set log retention limits and encrypt logs at rest and in transit.",
        "Add automated scanning to detect sensitive data in prompt/response logs.",
    ],
    "prompt_template_secret_exposure": [
        "Remove credentials, tokens, passwords, API keys, and private configuration values from prompt templates.",
        "Resolve secrets at runtime from a secrets manager and never inject raw secret values into prompts.",
        "Review prompt templates before release and scan them using secret-detection controls.",
        "Separate business instructions from sensitive configuration and credential material.",
        "Rotate any credential that may have been stored in prompt templates or prompt history.",
    ],
    "ai_provider_secret_exposure": [
        "Remove AI provider API keys from source code, config files, prompts, and logs.",
        "Store provider credentials in a secrets manager and inject them only at runtime.",
        "Rotate exposed provider keys immediately and review provider audit logs for misuse.",
        "Restrict provider keys by project, environment, model, IP range, and usage quota where supported.",
        "Add pre-commit and CI secret scanning to prevent future exposure.",
    ],
    "ai_tool_approval_bypass": [
        "Re-enable human approval for high-risk tools and privileged actions.",
        "Define approval policies by action type, target resource, data sensitivity, and environment.",
        "Prevent user input from disabling approval flags such as approval_required or human_approval.",
        "Record approver identity, request context, parameters, and execution outcome.",
        "Add tests that fail when approval gates are bypassed for sensitive tools.",
    ],
    "unsafe_function_calling": [
        "Disable unrestricted auto function calling for sensitive operations.",
        "Use a strict JSON schema for tool/function arguments and reject unknown fields.",
        "Apply server-side authorization for each function call independent of the model decision.",
        "Allow only pre-approved functions and block arbitrary function names or user-controlled dispatch.",
        "Require human review for functions that modify data, invoke external systems, or access sensitive records.",
    ],
    "unsafe_runtime_tool_execution": [
        "Route runtime tool execution through a controlled broker instead of direct shell/runtime access.",
        "Block arbitrary command strings and accept only structured, validated action parameters.",
        "Run runtime tools in isolated containers with read-only file systems and restricted network access.",
        "Apply timeouts, resource limits, and output-size limits for all runtime tools.",
        "Log all tool invocations, approvals, parameters, and outputs for traceability.",
    ],
    "unsafe_autonomous_decision": [
        "Require human-in-the-loop review for business-critical or user-impacting AI decisions.",
        "Define policy gates for autonomous decisions based on risk, data sensitivity, and financial or operational impact.",
        "Add deterministic validation checks before executing model-selected decisions.",
        "Record decision rationale, input data, model version, and reviewer approval where applicable.",
        "Provide rollback and override controls for incorrect autonomous decisions.",
    ],
    "no_human_review": [
        "Add mandatory human review for high-impact AI decisions, privileged operations, and sensitive data actions.",
        "Define escalation paths for uncertain, low-confidence, or policy-sensitive model outputs.",
        "Record reviewer identity, decision, timestamp, and reason for approval or rejection.",
        "Block automated execution when required review metadata is missing.",
        "Test that human review cannot be disabled by user-controlled input or configuration drift.",
    ],
    "llm_prompt_injection": [
        "Separate system, developer, retrieved, and user content using role-aware message boundaries.",
        "Treat retrieved documents and user prompts as untrusted input and never let them override system instructions.",
        "Add prompt-injection detection for requests to ignore instructions, reveal hidden prompts, or bypass policy.",
        "Constrain model actions with server-side authorization and tool allow-lists rather than prompt instructions alone.",
        "Log and monitor prompt-injection attempts and test known jailbreak patterns during release validation.",
    ],
    "rag_poisoning": [
        "Validate document source, ownership, and integrity before adding content to the retrieval index.",
        "Separate trusted enterprise content from user-submitted or internet-sourced content.",
        "Require source citations and confidence checks before using retrieved content in answers or actions.",
        "Scan retrieved documents for prompt-injection instructions and malicious tool-use instructions.",
        "Maintain versioned indexes and rollback capability for poisoned or untrusted documents.",
    ],
    "rag_untrusted_retrieval": [
        "Restrict retrieval ingestion to approved, authenticated, and integrity-checked sources.",
        "Tag documents by trust level and prevent low-trust content from driving privileged actions.",
        "Sanitize retrieved content before injecting it into model context.",
        "Require source attribution for retrieved answers and block answers without acceptable sources.",
        "Monitor retrieval index changes and alert on unusual bulk ingestion or external-source spikes.",
    ],
    "source_grounding_missing": [
        "Require citations or source identifiers for RAG-generated answers.",
        "Block high-confidence responses when no trusted source supports the answer.",
        "Return an explicit insufficient-evidence response when retrieval confidence is low.",
        "Store source IDs with generated responses for auditability.",
        "Evaluate grounding quality during testing using adversarial and out-of-domain prompts.",
    ],
    "rag_no_source_grounding": [
        "Require citations or source identifiers for RAG-generated answers.",
        "Block high-confidence responses when no trusted source supports the answer.",
        "Return an explicit insufficient-evidence response when retrieval confidence is low.",
        "Store source IDs with generated responses for auditability.",
        "Evaluate grounding quality during testing using adversarial and out-of-domain prompts.",
    ],
    "embedding_data_exposure": [
        "Do not export or dump embeddings unless approved and encrypted.",
        "Treat embeddings as sensitive derived data when they can reveal source text, users, or business context.",
        "Restrict vector-store persistence and backups using least privilege and encryption.",
        "Apply tenant isolation to embedding stores and delete embeddings when source data is deleted.",
        "Monitor bulk export, dump, or persistence operations from embedding stores.",
    ],
    "vector_database_exposure": [
        "Require authentication and network restrictions for vector database endpoints.",
        "Disable anonymous access and avoid binding vector databases to 0.0.0.0 unless behind protected infrastructure.",
        "Store vector database API keys in a secrets manager and rotate exposed keys.",
        "Apply tenant-level access controls and encryption for vector collections.",
        "Monitor query, export, and collection-management operations for abnormal access.",
    ],
    "ai_memory_persistence": [
        "Persist AI memory only with explicit user, tenant, and purpose boundaries.",
        "Avoid storing secrets, credentials, regulated data, or sensitive conversation content in long-term memory.",
        "Encrypt memory stores and enforce tenant isolation and retention limits.",
        "Provide deletion, review, and consent controls for persisted memory.",
        "Audit memory reads/writes and alert on cross-user or cross-tenant access patterns.",
    ],
    "ai_memory_cross_tenant_leakage": [
        "Partition memory by tenant and user using enforced server-side authorization checks.",
        "Remove global/shared memory for tenant-specific data unless strong isolation is implemented.",
        "Include tenant_id in memory keys and queries; reject operations without tenant context.",
        "Add tests proving one tenant cannot retrieve another tenant's memory.",
        "Encrypt tenant memory separately and monitor cross-tenant access attempts.",
    ],
    "llm_data_poisoning": [
        "Accept training data only from approved, authenticated, and integrity-checked sources.",
        "Track data lineage, uploader identity, license, timestamp, and approval status for every dataset.",
        "Scan training data for malicious instructions, secrets, sensitive data, and outlier content.",
        "Separate staging and production training datasets with review and approval gates.",
        "Keep dataset versions and rollback capability for poisoned or low-quality data.",
    ],
    "ai_data_lineage_risk": [
        "Track dataset source, owner, license, consent, approval status, and transformation history.",
        "Block user-uploaded training data from production training until reviewed and approved.",
        "Scan incoming datasets for secrets, regulated data, malicious prompts, and policy violations.",
        "Maintain immutable dataset versions for audit and rollback.",
        "Document data retention, deletion, and opt-out handling for training inputs.",
    ],
    "unsigned_or_untrusted_model_loading": [
        "Load models only from approved registries or trusted internal artifact stores.",
        "Verify model signatures, checksums, and provenance before loading.",
        "Disable trust_remote_code unless reviewed and explicitly approved.",
        "Run new or third-party models in a sandbox before production deployment.",
        "Record model source, version, digest, owner, and approval status in the model inventory.",
    ],
    "untrusted_model_loading": [
        "Load models only from approved registries or trusted internal artifact stores.",
        "Verify model signatures, checksums, and provenance before loading.",
        "Disable trust_remote_code unless reviewed and explicitly approved.",
        "Run new or third-party models in a sandbox before production deployment.",
        "Record model source, version, digest, owner, and approval status in the model inventory.",
    ],
    "model_registry_integrity_risk": [
        "Require checksum verification before model download, loading, or deployment.",
        "Store approved model checksums and signatures in a controlled model registry.",
        "Block model promotion when checksum, signature, or provenance metadata is missing.",
        "Audit registry changes and alert on model replacement or checksum drift.",
        "Include model digest, version, source, owner, and approval status in release evidence.",
    ],
    "llm_model_theft": [
        "Restrict model export, checkpoint copying, and weight download permissions to approved roles.",
        "Encrypt model artifacts at rest and in transit and monitor bulk download behavior.",
        "Disable debug endpoints or admin APIs that expose model weights or embeddings.",
        "Watermark or fingerprint proprietary models where feasible.",
        "Alert on model export, checkpoint copy, save_pretrained, or unusual artifact access events.",
    ],
    "agent_browser_automation_abuse": [
        "Restrict browser automation to approved domains and block user-controlled navigation to arbitrary URLs.",
        "Run browser automation in a sandboxed profile with no persistent credentials unless explicitly required.",
        "Prevent agents from submitting forms, downloading files, or accessing internal URLs without approval.",
        "Validate URLs against allow-lists and block localhost, metadata services, and private network ranges.",
        "Capture audit logs and screenshots for sensitive browser automation actions.",
    ],
    "agent_email_exfiltration": [
        "Require human approval before an agent sends email or attaches files.",
        "Block sending secrets, tokens, credentials, or regulated data to external recipients.",
        "Apply recipient allow-lists, DLP scanning, and content redaction before email dispatch.",
        "Use a dedicated low-privilege service account for agent email actions.",
        "Log recipient, subject, attachments, approval status, and DLP outcome for audit.",
    ],
    "prompt_supply_chain_signing_missing": [
        "Sign prompt templates and verify signatures before runtime use.",
        "Store prompt templates in a controlled repository with code review and change approval.",
        "Block unsigned or modified prompt templates from production deployment.",
        "Track prompt template owner, version, checksum, and deployment history.",
        "Alert on prompt template signature failures or unexpected prompt changes.",
    ],
    "model_governance_missing_owner": [
        "Assign a named business owner and technical owner for the model.",
        "Record owner, purpose, risk tier, data sources, and approval status in the model inventory.",
        "Block production release when model ownership metadata is missing.",
    ],
    "model_governance_missing_model_card": [
        "Create and maintain a model card covering purpose, limitations, datasets, risks, evaluation results, and approved use cases.",
        "Require model card review before promotion to production.",
        "Update the model card when data, model version, risk profile, or deployment context changes.",
    ],
    "model_governance_incomplete": [
        "Complete model ownership, model card, approval, and governance review metadata before release.",
        "Define model risk tier, intended use, prohibited use, data classification, and monitoring requirements.",
        "Block production deployment until governance approval is recorded.",
    ],
    "model_approval_missing": [
        "Require documented model approval before production use.",
        "Record approver, approval date, model version, evaluation evidence, and release scope.",
        "Block deployments with approval_status missing, none, or false.",
    ],
    "ai_policy_compliance_missing": [
        "Add an AI policy compliance check before release.",
        "Validate data use, model purpose, privacy, safety, security, and regulatory requirements.",
        "Record compliance evidence and risk acceptance decisions in the release package.",
    ],
    "llm_model_dos": [
        "Set maximum token, input length, output length, concurrency, and request-rate limits.",
        "Reject unbounded loops, recursive agent calls, and excessive tool invocation chains.",
        "Apply per-user and per-tenant quotas for model usage.",
        "Add timeout and circuit-breaker controls for model and tool calls.",
        "Monitor abnormal token consumption, latency, and repeated failed requests.",
    ],
    "llm_supply_chain": [
        "Pin AI framework and model dependency versions and verify package integrity.",
        "Use approved package registries and block untrusted model downloads.",
        "Generate SBOM/AI-BOM evidence for AI dependencies, models, plugins, and tools.",
        "Review third-party AI libraries for known CVEs, malicious packages, and license risk.",
        "Require provenance, checksum, and approval metadata for external models and plugins.",
    ],
    "llm_overreliance": [
        "Do not accept model output without validation for security, financial, legal, or user-impacting decisions.",
        "Use deterministic rules and independent checks for critical decisions.",
        "Display uncertainty and require human review for low-confidence outputs.",
        "Test model outputs against adversarial, edge-case, and policy-sensitive scenarios.",
        "Log decisions and validation outcomes for audit and continuous improvement.",
    ],
}

DESCRIPTION_BY_VULN_TYPE = {
    "ai_autonomous_tool_execution": "Agent or LLM workflow can invoke tools such as shell, file, browser, network, or deployment actions without sufficient approval or restriction.",
    "llm_insecure_plugin": "Plugin or tool interface can execute sensitive operations without strong authorization, parameter validation, or sandboxing.",
    "llm_insecure_output": "Model output is used in executable code, shell, subprocess, or dynamic evaluation paths without validation.",
    "llm_sensitive_disclosure": "Sensitive information may be exposed through prompts, responses, logs, memory, or model context.",
    "system_prompt_exposure": "System prompts or privileged model instructions may be exposed or mixed with user-controlled content.",
    "prompt_response_logging_sensitive_data": "Prompts or responses may be logged with secrets, credentials, tokens, or sensitive data.",
    "prompt_template_secret_exposure": "Prompt templates may contain secrets, credentials, tokens, or sensitive configuration values.",
    "ai_provider_secret_exposure": "AI provider credentials are present in code, configuration, prompt context, or logs.",
    "ai_tool_approval_bypass": "Tool approval controls can be disabled or bypassed, enabling sensitive actions without review.",
    "unsafe_function_calling": "Function or tool calling allows auto-dispatch or arbitrary user-controlled execution paths.",
    "unsafe_runtime_tool_execution": "Runtime tool execution may allow shell or privileged runtime operations from untrusted input.",
    "unsafe_autonomous_decision": "AI workflow can make or execute business-impacting decisions without sufficient review or deterministic controls.",
    "no_human_review": "High-risk AI decision path does not require human review or documented approval.",
    "llm_prompt_injection": "User-controlled or retrieved content may override, bypass, or manipulate model instructions.",
    "rag_poisoning": "Untrusted content can enter the retrieval corpus and influence model output or downstream actions.",
    "rag_untrusted_retrieval": "RAG workflow retrieves or ingests content from untrusted sources without trust boundaries or validation.",
    "source_grounding_missing": "Generated answers are not required to cite or ground output in trusted sources.",
    "rag_no_source_grounding": "RAG output is not required to cite or ground answers in trusted retrieved evidence.",
    "embedding_data_exposure": "Embeddings or vector-store data may be exported, persisted, or exposed without adequate controls.",
    "vector_database_exposure": "Vector database endpoint or credentials may be exposed or insufficiently access controlled.",
    "ai_memory_persistence": "Long-term AI memory may persist sensitive data without clear retention, consent, or tenant controls.",
    "ai_memory_cross_tenant_leakage": "Shared or global AI memory can leak data across users or tenants.",
    "llm_data_poisoning": "Training or fine-tuning data can be influenced by untrusted or unreviewed sources.",
    "ai_data_lineage_risk": "Training data lacks sufficient lineage, approval, or integrity controls.",
    "unsigned_or_untrusted_model_loading": "Model loading path trusts external or unsigned model artifacts.",
    "untrusted_model_loading": "Model loading path trusts external or unapproved model artifacts.",
    "model_registry_integrity_risk": "Model registry or artifact loading lacks checksum/signature verification.",
    "llm_model_theft": "Model weights, checkpoints, embeddings, or proprietary artifacts may be exported or copied without sufficient controls.",
    "agent_browser_automation_abuse": "Agent-controlled browser automation may access arbitrary URLs or perform sensitive actions without restrictions.",
    "agent_email_exfiltration": "Agent email capability may send secrets or sensitive data outside approved boundaries.",
    "prompt_supply_chain_signing_missing": "Prompt templates are not signed or integrity-verified before runtime use.",
    "model_governance_missing_owner": "Model ownership metadata is missing, weakening accountability and release governance.",
    "model_governance_missing_model_card": "Model card documentation is missing, weakening transparency and risk review.",
    "model_governance_incomplete": "Model governance metadata, approval, or documentation is incomplete.",
    "model_approval_missing": "Model approval status is missing or disabled before release.",
    "ai_policy_compliance_missing": "AI workflow lacks documented policy or compliance review before release.",
    "llm_model_dos": "AI workflow may allow excessive token usage, unbounded execution, or resource exhaustion.",
    "llm_supply_chain": "AI dependency, model, plugin, or framework supply chain controls are insufficient.",
    "llm_overreliance": "Model output may be accepted without independent validation for sensitive decisions.",
}

BUSINESS_IMPACT_BY_VULN_TYPE = {
    "ai_autonomous_tool_execution": "Unauthorized autonomous tool execution can cause data deletion, command execution, cloud changes, data exfiltration, and production impact.",
    "llm_insecure_plugin": "Insecure plugins can become an execution bridge from prompt input to privileged systems, enabling unauthorized actions and data exposure.",
    "llm_insecure_output": "Executing model output can lead to remote code execution, command injection, data theft, or unsafe business actions.",
    "llm_sensitive_disclosure": "Sensitive information disclosure can expose credentials, internal instructions, customer data, or regulated information.",
    "system_prompt_exposure": "System prompt disclosure can reveal internal controls and make prompt injection or policy bypass easier.",
    "prompt_response_logging_sensitive_data": "Sensitive prompt/response logs can create long-lived data exposure and audit/compliance risk.",
    "prompt_template_secret_exposure": "Secrets in prompt templates can leak to users, providers, logs, or model memory and require credential rotation.",
    "ai_provider_secret_exposure": "Exposed AI provider keys can enable unauthorized model usage, data access, cost abuse, and provider account compromise.",
    "ai_tool_approval_bypass": "Bypassed tool approval can allow unreviewed privileged operations and weaken release governance.",
    "unsafe_function_calling": "Unsafe function calling can let model or user-controlled input trigger unauthorized business operations.",
    "unsafe_runtime_tool_execution": "Unsafe runtime tools can enable arbitrary command execution, data exfiltration, or environment compromise.",
    "unsafe_autonomous_decision": "Unreviewed autonomous decisions can cause financial, operational, legal, or customer harm.",
    "no_human_review": "Missing human review weakens accountability for high-impact AI actions and can violate governance expectations.",
    "llm_prompt_injection": "Prompt injection can bypass controls, disclose hidden context, or manipulate tool actions and responses.",
    "rag_poisoning": "Poisoned retrieval content can mislead users, trigger unsafe actions, or silently corrupt enterprise knowledge responses.",
    "rag_untrusted_retrieval": "Untrusted retrieval can introduce malicious instructions, inaccurate evidence, or data leakage paths.",
    "source_grounding_missing": "Ungrounded answers can produce unsupported recommendations and weaken auditability.",
    "rag_no_source_grounding": "Ungrounded RAG answers can create unsupported business decisions and audit gaps.",
    "embedding_data_exposure": "Exposed embeddings can leak sensitive source data, user context, or proprietary business information.",
    "vector_database_exposure": "Vector database exposure can leak indexed knowledge, embeddings, and tenant-specific data.",
    "ai_memory_persistence": "Uncontrolled memory persistence can retain sensitive information beyond intended purpose or retention periods.",
    "ai_memory_cross_tenant_leakage": "Cross-tenant memory leakage can expose one customer or business unit's data to another.",
    "llm_data_poisoning": "Poisoned training data can degrade model behavior, introduce unsafe outputs, or create hidden backdoors.",
    "ai_data_lineage_risk": "Weak data lineage reduces trust in model outputs and creates compliance and rollback challenges.",
    "unsigned_or_untrusted_model_loading": "Untrusted models can introduce malicious code, backdoors, or unsafe behavior into production.",
    "untrusted_model_loading": "Untrusted models can introduce malicious code, backdoors, or unsafe behavior into production.",
    "model_registry_integrity_risk": "Missing artifact verification can allow model tampering or unauthorized replacement.",
    "llm_model_theft": "Model theft can expose proprietary IP, training investment, embeddings, and sensitive derived data.",
    "agent_browser_automation_abuse": "Browser automation abuse can access internal systems, perform unauthorized actions, or leak data through web workflows.",
    "agent_email_exfiltration": "Agent email misuse can exfiltrate secrets, customer data, or regulated information to unauthorized recipients.",
    "prompt_supply_chain_signing_missing": "Unsigned prompt templates can be modified without detection, changing model behavior or bypassing controls.",
    "model_governance_missing_owner": "Missing ownership weakens accountability for model risk, operation, and remediation.",
    "model_governance_missing_model_card": "Missing model cards reduce transparency, approval quality, and audit readiness.",
    "model_governance_incomplete": "Incomplete model governance can block production release and weaken enterprise AI assurance.",
    "model_approval_missing": "Missing model approval weakens release controls and audit evidence.",
    "ai_policy_compliance_missing": "Missing policy compliance review can create regulatory, privacy, security, and reputational risk.",
    "llm_model_dos": "Unbounded model usage can cause service degradation, cost spikes, and denial of service.",
    "llm_supply_chain": "Weak AI supply chain controls can introduce vulnerable packages, malicious models, or license risk.",
    "llm_overreliance": "Overreliance can cause incorrect, unsafe, or unsupported decisions without human or deterministic validation.",
}


def _owasp_llm(rule_id: str, vuln_type: str) -> str:
    if rule_id in OWASP_LLM_MAP:
        return OWASP_LLM_MAP[rule_id]
    if vuln_type in {"llm_insecure_output", "ai_autonomous_tool_execution", "unsafe_runtime_tool_execution"}:
        return "LLM06/LLM07:2025 - Excessive Agency / Insecure Tool Use"
    if "sensitive" in vuln_type or "secret" in vuln_type or "exposure" in vuln_type:
        return "LLM02:2025 - Sensitive Information Disclosure"
    if "rag" in vuln_type or "grounding" in vuln_type:
        return "LLM01/LLM05:2025 - Prompt Injection / Supply Chain Risk"
    if "governance" in vuln_type or "approval" in vuln_type or "policy" in vuln_type:
        return "AI Governance Control Gap"
    return "OWASP LLM / Agentic AI Security"


def _remediation_for(vuln_type: str) -> list[str]:
    return list(REMEDIATION_BY_VULN_TYPE.get(vuln_type, DEFAULT_LLM_REMEDIATION))


def _description_for(vuln_type: str, title: str) -> str:
    return DESCRIPTION_BY_VULN_TYPE.get(vuln_type, f"{title} detected in AI/LLM workflow and requires security review.")


def _business_impact_for(vuln_type: str) -> str:
    return BUSINESS_IMPACT_BY_VULN_TYPE.get(
        vuln_type,
        "AI/LLM control weakness may enable unsafe model behavior, unauthorized action, sensitive data exposure, or governance failure.",
    )

def scan_llm_file(filepath: str, content: str) -> list[dict]:
    findings = []
    lines = content.splitlines()
    seen = set()

    for lineno, line in enumerate(lines, start=1):
        for rule in LLM_RULES:
            for pattern in rule["patterns"]:
                if not re.search(pattern, line, re.I):
                    continue

                rule_id = rule["rule_id"]
                vuln_type = rule["vuln_type"]
                title = rule["title"]
                dedupe_key = (rule_id, vuln_type, filepath, lineno, line.strip())

                if dedupe_key in seen:
                    break

                seen.add(dedupe_key)
                owasp_llm = _owasp_llm(rule_id, vuln_type)
                cwe = CWE_MAP.get(vuln_type, "CWE-693")
                remediation = _remediation_for(vuln_type)

                findings.append(
                    {
                        "rule_id": rule_id,
                        "title": title,
                        "vuln_type": vuln_type,
                        "severity": rule["severity"],
                        "priority": "P1" if str(rule["severity"]).lower() == "critical" else "P2" if str(rule["severity"]).lower() == "high" else "P3",
                        "confidence": "HIGH",
                        "confidence_label": "HIGH",
                        "confidence_score": 90,
                        "language": "ai/llm",
                        "file": filepath,
                        "line": lineno,
                        "snippet": line.strip(),
                        "description": _description_for(vuln_type, title),
                        "business_impact": _business_impact_for(vuln_type),
                        "remediation": remediation,
                        "recommended_action": " ".join(remediation[:2]),
                        "owasp_llm_top10": owasp_llm,
                        "owasp": owasp_llm,
                        "owasp_id": owasp_llm.split(":", 1)[0] if ":" in owasp_llm else rule_id.split("_", 1)[0],
                        "cwe": cwe,
                        "cwe_desc": "AI/LLM security control weakness",
                        "mitre": "T1059" if vuln_type in {"llm_insecure_output", "ai_autonomous_tool_execution", "unsafe_runtime_tool_execution"} else "",
                        "mitre_desc": "Command and Scripting Interpreter" if vuln_type in {"llm_insecure_output", "ai_autonomous_tool_execution", "unsafe_runtime_tool_execution"} else "",
                        "exploitability": "High" if str(rule["severity"]).lower() in {"critical", "high"} else "Medium",
                        "sink_category": "AI / LLM Workflow",
                        "detection": "LLM Security Heuristic",
                        "detection_note": f"{title} matched pattern: {pattern}",
                        "cve": None,
                        "cvss": None,
                    }
                )
                break

    return findings


if __name__ == "__main__":
    sample = """
prompt = input("ignore previous instructions")
eval(user_prompt)
approval_required=False
print(api_key)
"""

    import json
    print(json.dumps(scan_llm_file("sample.py", sample), indent=2))