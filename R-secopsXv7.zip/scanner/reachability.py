import os
import re
import json


SOURCE_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".cs"
}

SKIP_DIRS = {
    "node_modules", ".git", "__pycache__", "venv", ".venv",
    "dist", "build", "target", ".next"
}

REACHABILITY_ALIASES = {
    "log4j": {
        "log4j-core",
        "log4j-api",
        "org.apache.logging.log4j",
        "org.apache.logging.log4j:log4j-core",
        "org.apache.logging.log4j:log4j-api",
        "logmanager",
    },
    "spring": {
        "spring-core",
        "spring-web",
        "spring-webmvc",
        "org.springframework",
        "org.springframework:spring-core",
        "org.springframework:spring-web",
        "org.springframework:spring-webmvc",
    },
    "lodash": {"lodash-es"},
    "node-fetch": {"nodefetch", "node_fetch", "fetch"},
    "jackson": {
        "jackson-databind",
        "jackson-core",
        "com.fasterxml.jackson",
        "com.fasterxml.jackson.core:jackson-databind",
    },
    "struts": {"struts2-core", "org.apache.struts"},
}



def _safe_read(path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.readlines()
    except Exception:
        return []


def _iter_project_files(project_root):
    for root, dirs, files in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]

        for filename in files:
            path = os.path.join(root, filename)
            ext = os.path.splitext(filename)[1].lower()

            if ext in SOURCE_EXTENSIONS or filename in {
                "package.json", "pom.xml", "build.gradle"
            }:
                yield path


def extract_source_references(project_root):
    references = []

    for path in _iter_project_files(project_root):
        rel_path = os.path.relpath(path, project_root)
        filename = os.path.basename(path)
        ext = os.path.splitext(filename)[1].lower()
        lines = _safe_read(path)

        for line_no, line in enumerate(lines, start=1):
            stripped = line.strip()

            if not stripped:
                continue

            found = []

            if ext == ".py":
                found += re.findall(r"^\s*import\s+([a-zA-Z0-9_\.]+)", line)
                found += re.findall(r"^\s*from\s+([a-zA-Z0-9_\.]+)\s+import\s+", line)
                found += re.findall(r"importlib\.import_module\(['\"]([^'\"]+)['\"]\)", line)
                found += re.findall(r"__import__\(['\"]([^'\"]+)['\"]\)", line)
                found += re.findall(r"getattr\(\s*([a-zA-Z0-9_\.]+)\s*,", line)

            elif ext in {".js", ".ts", ".jsx", ".tsx"}:
                found += re.findall(r"require\(['\"]([^'\"]+)['\"]\)", line)
                found += re.findall(r"from\s+['\"]([^'\"]+)['\"]", line)
                found += re.findall(r"import\s+['\"]([^'\"]+)['\"]", line)
                found += re.findall(r"import\s+.*?from\s+['\"]([^'\"]+)['\"]", line)
                found += re.findall(r"require\(\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\)", line)

            elif ext == ".java":
                found += re.findall(r"^\s*import\s+([a-zA-Z0-9_\.]+)", line)
                found += re.findall(r"Class\.forName\(['\"]([^'\"]+)['\"]\)", line)

            elif ext == ".cs":
                found += re.findall(r"^\s*using\s+([a-zA-Z0-9_\.]+)", line)
                found += re.findall(r"Activator\.CreateInstance\(['\"]([^'\"]+)['\"]\)", line)
                found += re.findall(r"Type\.GetType\(['\"]([^'\"]+)['\"]\)", line)

            elif filename == "package.json":
                try:
                    data = json.loads("".join(lines))
                    for section in [
                        "dependencies",
                        "devDependencies",
                        "optionalDependencies",
                        "peerDependencies",
                    ]:
                        for pkg in data.get(section, {}).keys():
                            references.append({
                                "package_reference": pkg,
                                "file": rel_path,
                                "line": 0,
                                "reference": section,
                                "method": "manifest_reference",
                            })
                    break
                except Exception:
                    continue

            elif filename == "pom.xml":
                found += re.findall(r"<artifactId>(.*?)</artifactId>", line)
                found += re.findall(r"<groupId>(.*?)</groupId>", line)

            elif filename == "build.gradle":
                found += re.findall(
                    r"(?:implementation|api|compileOnly|runtimeOnly|testImplementation)\s+['\"]([^'\"]+)['\"]",
                    line,
                )

            for ref in found:
                clean_ref = str(ref or "").strip()

                if not clean_ref:
                    continue

                references.append({
                    "package_reference": clean_ref,
                    "file": rel_path,
                    "line": line_no,
                    "reference": stripped[:160],
                    "method": "import_reference",
                })

    return references


def _normalize_package_name(name):
    if not name:
        return ""

    name = str(name).strip().lower()

    if name.startswith("@"):
        parts = name.split("/")
        return "/".join(parts[:2])

    return name.split(".")[0]


def _reference_matches_package(reference, package_name):
    reference = str(reference or "").lower()
    package_name = str(package_name or "").lower()

    ref = _normalize_package_name(reference)
    pkg = _normalize_package_name(package_name)

    if not ref or not pkg:
        return False

    expanded = {reference, ref, package_name, pkg}

    for alias_key, aliases in REACHABILITY_ALIASES.items():
        alias_key_norm = _normalize_package_name(alias_key)

        if (
            alias_key in reference
            or alias_key in package_name
            or alias_key_norm == ref
            or alias_key_norm == pkg
        ):
            expanded.add(alias_key)
            expanded.add(alias_key_norm)

            for alias in aliases:
                expanded.add(str(alias).lower())
                expanded.add(_normalize_package_name(alias))

    if package_name in expanded or pkg in expanded:
        return True

    for item in expanded:
        item_norm = _normalize_package_name(item)

        if item and item in package_name:
            return True

        if item_norm and item_norm in pkg:
            return True

        if item and item in reference:
            return True

        if item_norm and item_norm in ref:
            return True

    if ref == pkg:
        return True

    if reference.startswith(package_name):
        return True

    if package_name in reference:
        return True

    if ":" in package_name:
        artifact = package_name.split(":")[-1]
        artifact_norm = _normalize_package_name(artifact)

        if artifact and artifact in reference:
            return True

        if artifact_norm and artifact_norm in expanded:
            return True

        for item in expanded:
            if artifact and artifact in item:
                return True
            if artifact_norm and artifact_norm in _normalize_package_name(item):
                return True

    if package_name.startswith("@") and ref == pkg:
        return True

    return False

    
def map_references_to_sbom(references, sbom):
    enriched = []

    for package in sbom:
        pkg = dict(package)
        name = pkg.get("name") or pkg.get("package") or ""

        matched_evidence = []

        for ref in references:
            if _reference_matches_package(ref.get("package_reference"), name):
                matched_evidence.append({
                    "file": ref.get("file"),
                    "line": ref.get("line"),
                    "reference": ref.get("reference"),
                    "method": ref.get("method"),
                })

        if matched_evidence:
            method = matched_evidence[0].get("method", "import_reference")

            if method == "import_reference":
                pkg["reachable"] = True
                pkg["reachability_status"] = "REACHABLE"
                pkg["reachability_confidence"] = 0.85
            else:
                pkg["reachable"] = False
                pkg["reachability_status"] = "MANIFEST_REFERENCED"
                pkg["reachability_confidence"] = 0.65

            pkg["reachability_method"] = method
            pkg["reachability_evidence"] = matched_evidence[:10]

        else:
            pkg["reachable"] = False
            pkg["reachability_status"] = "NOT_OBSERVED"
            pkg["reachability_method"] = "no_reference_observed"
            pkg["reachability_confidence"] = 0.30
            pkg["reachability_evidence"] = []

        enriched.append(pkg)

    return enriched


def generate_reachability_summary(enriched_sbom):
    summary = {
        "total_packages": len(enriched_sbom),
        "reachable_packages": 0,
        "manifest_referenced_packages": 0,
        "not_observed_packages": 0,
        "unknown_packages": 0,
        "direct_reachable": 0,
        "transitive_reachable": 0,
    }

    for pkg in enriched_sbom:
        status = pkg.get("reachability_status")
        dep_type = str(pkg.get("dependency_type", "")).lower()

        if status == "REACHABLE":
            summary["reachable_packages"] += 1

            if dep_type == "direct":
                summary["direct_reachable"] += 1
            elif dep_type == "transitive":
                summary["transitive_reachable"] += 1

        elif status == "MANIFEST_REFERENCED":
            summary["manifest_referenced_packages"] += 1

        elif status == "NOT_OBSERVED":
            summary["not_observed_packages"] += 1

        else:
            summary["unknown_packages"] += 1

    return summary


def _valid_vulnerability_id(value):
    text = str(value or "").strip()
    return bool(text) and text.upper() not in {"NONE", "NULL", "UNKNOWN", "N/A", "NA"}


def _has_vulnerability(pkg):
    if int(pkg.get("vulnerability_count", 0) or 0) > 0:
        return True

    for key in ["cve", "advisory_id", "primary_vulnerability_id", "source_vulnerability_id"]:
        if _valid_vulnerability_id(pkg.get(key)):
            return True

    for cve in pkg.get("cve_list") or []:
        if _valid_vulnerability_id(cve):
            return True

    for advisory in pkg.get("advisory_ids") or []:
        if _valid_vulnerability_id(advisory):
            return True

    vulns = pkg.get("vulnerabilities") or []
    if isinstance(vulns, list):
        for v in vulns:
            if not isinstance(v, dict):
                continue

            vid = (
                v.get("cve")
                or v.get("advisory_id")
                or v.get("id")
                or v.get("ghsa_id")
            )

            if _valid_vulnerability_id(vid):
                return True

    return False


def prioritize_reachable_vulnerabilities(enriched_sbom):
    summary = {
        "vulnerable_packages": 0,
        "reachable_vulnerable_packages": 0,
        "not_observed_vulnerable_packages": 0,
        "unknown_reachability_vulnerable_packages": 0,
    }

    for pkg in enriched_sbom:
        vulnerable = _has_vulnerability(pkg)
        status = pkg.get("reachability_status", "UNKNOWN")

        pkg["reachable_vulnerability"] = False
        pkg["reachability_priority"] = "NOT_APPLICABLE"

        if not vulnerable:
            continue

        summary["vulnerable_packages"] += 1

        if status == "REACHABLE":
            pkg["reachable_vulnerability"] = True
            pkg["reachability_priority"] = "REACHABLE_VULNERABLE"
            summary["reachable_vulnerable_packages"] += 1

        elif status == "NOT_OBSERVED":
            pkg["reachability_priority"] = "NOT_OBSERVED_VULNERABLE"
            summary["not_observed_vulnerable_packages"] += 1

        else:
            pkg["reachability_priority"] = "UNKNOWN_REACHABILITY_VULNERABLE"
            summary["unknown_reachability_vulnerable_packages"] += 1

    return {
        "sbom": enriched_sbom,
        "reachability_vulnerability_summary": summary,
    }


def analyze_reachability(project_root, sbom):
    references = extract_source_references(project_root)
    enriched_sbom = map_references_to_sbom(references, sbom)

    priority_result = prioritize_reachable_vulnerabilities(enriched_sbom)
    enriched_sbom = priority_result.get("sbom", enriched_sbom)

    summary = generate_reachability_summary(enriched_sbom)

    return {
        "sbom": enriched_sbom,
        "reachability_summary": summary,
        "reachability_vulnerability_summary": priority_result.get(
            "reachability_vulnerability_summary",
            {},
        ),
        "reachability_references_count": len(references),
    }