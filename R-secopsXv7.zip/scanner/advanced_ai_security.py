from __future__ import annotations

import re


FILENAME_RULE_MAP = {
    "ADV01_evasion_attack.py": ("ADV01_EVASION_ATTACK", "Adversarial Evasion Attack", "High", "adversarial_evasion_attack"),
    "ADV02_gradient_extraction.py": ("ADV02_GRADIENT_EXTRACTION", "Gradient Extraction Risk", "High", "gradient_extraction_risk"),
    "ADV03_model_inversion.py": ("ADV03_MODEL_INVERSION", "Model Inversion Risk", "High", "model_inversion_risk"),
    "ADV04_membership_inference.py": ("ADV04_MEMBERSHIP_INFERENCE", "Membership Inference Risk", "High", "membership_inference_risk"),
    "ADV05_adversarial_testing_disabled.py": ("ADV05_ADVERSARIAL_TESTING_DISABLED", "Adversarial Testing Disabled", "Medium", "adversarial_testing_disabled"),

    "AGENT11_browser_automation_abuse.py": ("AGENT11_BROWSER_AUTOMATION_ABUSE", "Agent Browser Automation Abuse", "Critical", "agent_browser_automation_abuse"),
    "AGENT12_email_exfiltration.py": ("AGENT12_EMAIL_EXFILTRATION", "Agent Email Exfiltration Risk", "Critical", "agent_email_exfiltration"),
    "AGENT13_database_destructive_action.py": ("AGENT13_DATABASE_DESTRUCTIVE_ACTION", "Agent Database Destructive Action", "Critical", "agent_database_destructive_action"),
    "AGENT14_recursive_self_invocation.py": ("AGENT14_RECURSIVE_SELF_INVOCATION", "Recursive Agent Self Invocation", "High", "recursive_agent_self_invocation"),
    "AGENT15_self_modifying_agent.py": ("AGENT15_SELF_MODIFYING_AGENT", "Self-Modifying Agent Risk", "Critical", "self_modifying_agent"),
    "AGENT16_multi_agent_escalation.py": ("AGENT16_MULTI_AGENT_ESCALATION", "Multi-Agent Escalation Risk", "High", "multi_agent_escalation"),

    "COMP01_eu_ai_act_risk_class_missing.json": ("COMP01_EU_AI_ACT_RISK_CLASS_MISSING", "EU AI Act Risk Classification Missing", "Medium", "eu_ai_act_risk_class_missing"),
    "COMP02_data_residency_undefined.json": ("COMP02_DATA_RESIDENCY_UNDEFINED", "Data Residency Undefined", "Medium", "data_residency_undefined"),
    "COMP03_cross_border_inference.py": ("COMP03_CROSS_BORDER_INFERENCE", "Cross-Border Inference Risk", "Medium", "cross_border_inference"),
    "COMP04_processor_disclosure_missing.json": ("COMP04_PROCESSOR_DISCLOSURE_MISSING", "Processor Disclosure Missing", "Medium", "processor_disclosure_missing"),
    "COMP05_ai_retention_undefined.py": ("COMP05_AI_RETENTION_UNDEFINED", "AI Retention Undefined", "Medium", "ai_retention_undefined"),
    "COMP06_explainability_missing.py": ("COMP06_EXPLAINABILITY_MISSING", "Explainability Missing", "Medium", "explainability_missing"),

    "GOV11_bias_assessment_missing.py": ("GOV11_BIAS_ASSESSMENT_MISSING", "Bias Assessment Missing", "Medium", "bias_assessment_missing"),
    "GOV12_fairness_testing_missing.py": ("GOV12_FAIRNESS_TESTING_MISSING", "Fairness Testing Missing", "Medium", "fairness_testing_missing"),
    "GOV13_red_team_evidence_missing.py": ("GOV13_RED_TEAM_EVIDENCE_MISSING", "AI Red-Team Evidence Missing", "Medium", "ai_red_team_evidence_missing"),
    "GOV14_human_fallback_missing.py": ("GOV14_HUMAN_FALLBACK_MISSING", "Human Fallback Missing", "High", "human_fallback_missing"),
    "GOV15_ai_incident_playbook_missing.py": ("GOV15_AI_INCIDENT_PLAYBOOK_MISSING", "AI Incident Playbook Missing", "Medium", "ai_incident_playbook_missing"),
    "GOV16_ai_kill_switch_missing.py": ("GOV16_AI_KILL_SWITCH_MISSING", "AI Kill Switch Missing", "High", "ai_kill_switch_missing"),
    "GOV17_model_decommission_missing.py": ("GOV17_MODEL_DECOMMISSION_MISSING", "Model Decommission Missing", "Medium", "model_decommission_missing"),

    "RUN01_unlimited_tool_recursion.py": ("RUN01_UNLIMITED_TOOL_RECURSION", "Unlimited Tool Recursion", "High", "unlimited_tool_recursion"),
    "RUN02_token_budget_bypass.py": ("RUN02_TOKEN_BUDGET_BYPASS", "Token Budget Bypass", "Medium", "token_budget_bypass"),
    "RUN03_cost_amplification.py": ("RUN03_COST_AMPLIFICATION", "AI Cost Amplification Risk", "Medium", "ai_cost_amplification"),
    "RUN04_context_stuffing.py": ("RUN04_CONTEXT_STUFFING", "Context Stuffing Risk", "Medium", "context_stuffing"),
    "RUN05_rate_limit_missing.py": ("RUN05_RATE_LIMIT_MISSING", "AI Rate Limit Missing", "Medium", "ai_rate_limit_missing"),

    "DATA01_training_source_unknown.py": ("DATA01_TRAINING_SOURCE_UNKNOWN", "Training Source Unknown", "Medium", "training_source_unknown"),
    "DATA02_dataset_license_unknown.py": ("DATA02_DATASET_LICENSE_UNKNOWN", "Dataset License Unknown", "Medium", "dataset_license_unknown"),
    "DATA03_dataset_pii_ingestion.py": ("DATA03_DATASET_PII_INGESTION", "Dataset PII Ingestion", "High", "dataset_pii_ingestion"),
    "DATA04_training_data_retention_missing.py": ("DATA04_TRAINING_DATA_RETENTION_MISSING", "Training Data Retention Missing", "Medium", "training_data_retention_missing"),
    "DATA05_untrusted_user_training_upload.py": ("DATA05_UNTRUSTED_USER_TRAINING_UPLOAD", "Untrusted User Training Upload", "High", "untrusted_user_training_upload"),

    "REG01_public_model_registry_pull.py": ("REG01_PUBLIC_MODEL_REGISTRY_PULL", "Public Model Registry Pull", "High", "public_model_registry_pull"),
    "REG02_no_checksum_verification.py": ("REG02_MODEL_CHECKSUM_MISSING", "Model Checksum Verification Missing", "Critical", "model_checksum_missing"),
    "REG03_registry_acl_missing.json": ("REG03_REGISTRY_ACL_MISSING", "Model Registry ACL Missing", "High", "model_registry_acl_missing"),
    "REG04_model_version_drift.py": ("REG04_MODEL_VERSION_DRIFT", "Model Version Drift", "Medium", "model_version_drift"),
    "REG05_model_signature_missing.py": ("REG05_MODEL_SIGNATURE_MISSING", "Model Signature Missing", "High", "model_signature_missing"),

    "PSC01_external_prompt_template_pull.py": ("PSC01_EXTERNAL_PROMPT_TEMPLATE_PULL", "External Prompt Template Pull", "High", "external_prompt_template_pull"),
    "PSC02_prompt_marketplace_import.py": ("PSC02_PROMPT_MARKETPLACE_IMPORT", "Prompt Marketplace Import", "High", "prompt_marketplace_import"),
    "PSC03_unsigned_prompt_package.py": ("PSC03_UNSIGNED_PROMPT_PACKAGE", "Unsigned Prompt Package", "High", "unsigned_prompt_package"),
    "PSC04_prompt_cache_poisoning.py": ("PSC04_PROMPT_CACHE_POISONING", "Prompt Cache Poisoning", "High", "prompt_cache_poisoning"),
    "PSC05_prompt_replay.py": ("PSC05_PROMPT_REPLAY", "Prompt Replay Risk", "Medium", "prompt_replay"),
    "PSC06_prompt_signing_missing.py": ("PSC06_PROMPT_SIGNING_MISSING", "Prompt Signing Missing", "Critical", "prompt_signing_missing"),

    "VDB01_public_vector_db.py": ("VDB01_PUBLIC_VECTOR_DB", "Public Vector Database", "High", "public_vector_database"),
    "VDB02_vector_acl_missing.py": ("VDB02_VECTOR_ACL_MISSING", "Vector DB ACL Missing", "High", "vector_acl_missing"),
    "VDB03_embedding_cross_tenant_access.py": ("VDB03_EMBEDDING_CROSS_TENANT_ACCESS", "Embedding Cross-Tenant Access", "Critical", "embedding_cross_tenant_access"),
    "VDB04_unencrypted_embeddings.py": ("VDB04_UNENCRYPTED_EMBEDDINGS", "Unencrypted Embeddings", "High", "unencrypted_embeddings"),
    "VDB05_sensitive_document_indexing.py": ("VDB05_SENSITIVE_DOCUMENT_INDEXING", "Sensitive Document Indexing", "High", "sensitive_document_indexing"),
    "VDB06_citation_suppression.py": ("VDB06_CITATION_SUPPRESSION", "Citation Suppression Risk", "Medium", "citation_suppression"),

    "SEC04_vertex_service_account.json": ("AI_PROVIDER_SECRET_EXPOSURE", "AI Provider Secret Exposure", "Critical", "ai_provider_secret_exposure"),
    "ADV01_evasion_attack.py": ("ADV01_EVASION_ATTACK_INDICATOR", "Adversarial Evasion Attack", "High", "adversarial_evasion_attack"),
    "ADV05_adversarial_testing_disabled.py": ("ADV05_ADVERSARIAL_TESTING_MISSING", "Adversarial Testing Disabled", "Medium", "adversarial_testing_disabled"),
    "DATA05_untrusted_user_training_upload.py": ("DATA05_UNTRUSTED_TRAINING_UPLOAD", "Untrusted User Training Upload", "High", "untrusted_user_training_upload"),
    "REG03_registry_acl_missing.json": ("REG03_MODEL_REGISTRY_ACL_MISSING", "Model Registry ACL Missing", "High", "model_registry_acl_missing"),
    "PSC05_prompt_replay.py": ("PSC05_PROMPT_REPLAY_RISK", "Prompt Replay Risk", "Medium", "prompt_replay"),
    "RUN05_rate_limit_missing.py": ("RUN05_AI_RATE_LIMIT_MISSING", "AI Rate Limit Missing", "Medium", "ai_rate_limit_missing"),
    "GOV13_red_team_evidence_missing.py": ("GOV13_AI_RED_TEAM_EVIDENCE_MISSING", "AI Red-Team Evidence Missing", "Medium", "ai_red_team_evidence_missing"),
    "COMP02_data_residency_undefined.json": ("COMP02_AI_DATA_RESIDENCY_UNDEFINED", "Data Residency Undefined", "Medium", "data_residency_undefined"),
    "COMP03_cross_border_inference.py": ("COMP03_CROSS_BORDER_AI_INFERENCE", "Cross-Border Inference Risk", "Medium", "cross_border_inference"),
    "COMP04_processor_disclosure_missing.json": ("COMP04_AI_PROCESSOR_DISCLOSURE_MISSING", "Processor Disclosure Missing", "Medium", "processor_disclosure_missing"),
    "COMP06_explainability_missing.py": ("COMP06_AI_EXPLAINABILITY_MISSING", "Explainability Missing", "Medium", "explainability_missing"),

}

ADVANCED_AI_RULES = [
    # -----------------------------
    # DATA* — Data lineage / privacy
    # -----------------------------
    {
        "rule_id": "DATA_UNTRUSTED_TRAINING_UPLOAD",
        "title": "Untrusted Training Data Upload",
        "patterns": [
            r"untrusted_user_training_upload",
            r"user_uploaded_training_data",
            r"external_dataset",
            r"train_model\(.*user",
            r"fine_tune\(.*user",
        ],
        "severity": "High",
        "vuln_type": "ai_data_lineage_risk",
    },
    {
        "rule_id": "DATA_TRAINING_DATA_LINEAGE_MISSING",
        "title": "Training Data Lineage Missing",
        "patterns": [
            r"training_data_lineage\s*=\s*None",
            r"data_lineage\s*=\s*False",
            r"missing_training_lineage",
            r"dataset_source\s*=\s*[\"']unknown[\"']",
        ],
        "severity": "Medium",
        "vuln_type": "ai_training_data_lineage_missing",
    },
    {
        "rule_id": "DATA_PERSONAL_DATA_IN_TRAINING",
        "title": "Personal Data Used in Training",
        "patterns": [
            r"personal_data_training",
            r"pii_training_data",
            r"train_on_customer_data",
            r"contains_pii\s*=\s*True",
        ],
        "severity": "High",
        "vuln_type": "ai_personal_data_training_risk",
    },

    # -----------------------------
    # REG* — Model registry integrity
    # -----------------------------
    {
        "rule_id": "REG_MODEL_CHECKSUM_MISSING",
        "title": "Model Registry Checksum Missing",
        "patterns": [
            r"no_checksum_verification",
            r"checksum\s*=\s*None",
            r"verify_checksum\s*=\s*False",
            r"skip_checksum\s*=\s*True",
        ],
        "severity": "Critical",
        "vuln_type": "model_registry_integrity_risk",
    },
    {
        "rule_id": "REG_MODEL_SIGNATURE_MISSING",
        "title": "Model Signature Missing",
        "patterns": [
            r"model_signature\s*=\s*None",
            r"verify_model_signature\s*=\s*False",
            r"unsigned_model",
            r"signature_check\s*=\s*False",
        ],
        "severity": "High",
        "vuln_type": "model_signature_missing",
    },
    {
        "rule_id": "REG_UNTRUSTED_MODEL_REGISTRY",
        "title": "Untrusted Model Registry Source",
        "patterns": [
            r"untrusted_model_registry",
            r"model_registry_url\s*=\s*[\"']http://",
            r"load_model\(.*http://",
            r"registry_trust\s*=\s*False",
        ],
        "severity": "High",
        "vuln_type": "untrusted_model_registry",
    },

    # -----------------------------
    # AGENT* — Agentic abuse
    # -----------------------------
    {
        "rule_id": "AGENT_BROWSER_AUTOMATION_ABUSE",
        "title": "Agent Browser Automation Abuse",
        "patterns": [
            r"browser_automation_abuse",
            r"browser\.open\(.*user",
            r"page\.goto\(.*user",
            r"playwright.*user",
            r"selenium.*user",
        ],
        "severity": "Critical",
        "vuln_type": "agent_browser_automation_abuse",
    },
    {
        "rule_id": "AGENT_EMAIL_EXFILTRATION",
        "title": "Agent Email Exfiltration Risk",
        "patterns": [
            r"email_exfiltration",
            r"send_email\(.*secret",
            r"send_email\(.*token",
            r"smtp.*exfiltrate",
            r"mail.*token",
        ],
        "severity": "Critical",
        "vuln_type": "agent_email_exfiltration",
    },
    {
        "rule_id": "AGENT_FILESYSTEM_ABUSE",
        "title": "Agent Filesystem Abuse",
        "patterns": [
            r"agent_filesystem_abuse",
            r"file_tool\.delete",
            r"filesystem\.write\(.*user",
            r"read_file\(.*user",
            r"delete_file\(.*user",
        ],
        "severity": "High",
        "vuln_type": "agent_filesystem_abuse",
    },
    {
        "rule_id": "AGENT_DATABASE_TOOL_ABUSE",
        "title": "Agent Database Tool Abuse",
        "patterns": [
            r"agent_database_tool_abuse",
            r"db_tool\.execute\(.*user",
            r"database_tool\.run\(.*user",
            r"sql_tool\(.*user",
        ],
        "severity": "High",
        "vuln_type": "agent_database_tool_abuse",
    },

    # -----------------------------
    # PSC* — Prompt supply chain
    # -----------------------------
    {
        "rule_id": "PSC_PROMPT_SIGNING_MISSING",
        "title": "Prompt Supply Chain Signing Missing",
        "patterns": [
            r"prompt_signing_missing",
            r"verify_prompt_signature\s*=\s*False",
            r"prompt_signature\s*=\s*None",
            r"unsigned_prompt_template",
        ],
        "severity": "Critical",
        "vuln_type": "prompt_supply_chain_signing_missing",
    },
    {
        "rule_id": "PSC_UNTRUSTED_PROMPT_TEMPLATE",
        "title": "Untrusted Prompt Template Source",
        "patterns": [
            r"untrusted_prompt_template",
            r"load_prompt_template\(.*http",
            r"prompt_template_url\s*=\s*[\"']http://",
            r"remote_prompt_template",
        ],
        "severity": "High",
        "vuln_type": "untrusted_prompt_template",
    },
    {
        "rule_id": "PSC_PROMPT_TEMPLATE_INTEGRITY_MISSING",
        "title": "Prompt Template Integrity Missing",
        "patterns": [
            r"prompt_template_integrity\s*=\s*False",
            r"template_hash\s*=\s*None",
            r"skip_prompt_integrity_check",
        ],
        "severity": "High",
        "vuln_type": "prompt_template_integrity_missing",
    },

    # -----------------------------
    # VDB* — Vector DB / RAG exposure
    # -----------------------------
    {
        "rule_id": "VDB_VECTOR_DB_EXPOSURE",
        "title": "Vector Database Exposure",
        "patterns": [
            r"vector_db_exposure",
            r"qdrant.*api_key\s*=",
            r"pinecone.*api_key\s*=",
            r"weaviate.*anonymous",
            r"chroma_server_host\s*=\s*[\"']0\.0\.0\.0",
        ],
        "severity": "High",
        "vuln_type": "vector_database_exposure",
    },
    {
        "rule_id": "VDB_RAG_INDEX_PUBLIC",
        "title": "Public RAG Index Exposure",
        "patterns": [
            r"public_rag_index",
            r"rag_index_public\s*=\s*True",
            r"vector_index_acl\s*=\s*[\"']public[\"']",
            r"anonymous_vector_search\s*=\s*True",
        ],
        "severity": "High",
        "vuln_type": "public_rag_index_exposure",
    },
    {
        "rule_id": "VDB_EMBEDDING_EXPORT",
        "title": "Embedding Export Risk",
        "patterns": [
            r"export_embeddings",
            r"dump_embeddings",
            r"embedding_store\.dump",
            r"vectorstore\.persist",
        ],
        "severity": "High",
        "vuln_type": "embedding_export_risk",
    },

    # -----------------------------
    # RUN* — Runtime tool abuse
    # -----------------------------
    {
        "rule_id": "RUN_UNSAFE_RUNTIME_TOOL",
        "title": "Unsafe Runtime Tool Execution",
        "patterns": [
            r"unsafe_runtime_tool",
            r"runtime_tool.*shell",
            r"execute_runtime_tool\(.*user",
            r"tool_runtime_approval\s*=\s*False",
        ],
        "severity": "Critical",
        "vuln_type": "unsafe_runtime_tool_execution",
    },
    {
        "rule_id": "RUN_CODE_INTERPRETER_UNRESTRICTED",
        "title": "Unrestricted Code Interpreter",
        "patterns": [
            r"code_interpreter_unrestricted",
            r"allow_code_execution\s*=\s*True",
            r"python_repl.*user",
            r"execute_python\(.*user",
        ],
        "severity": "Critical",
        "vuln_type": "unrestricted_code_interpreter",
    },
    {
        "rule_id": "RUN_SANDBOX_DISABLED",
        "title": "AI Runtime Sandbox Disabled",
        "patterns": [
            r"sandbox_enabled\s*=\s*False",
            r"disable_sandbox\s*=\s*True",
            r"runtime_isolation\s*=\s*False",
        ],
        "severity": "High",
        "vuln_type": "ai_runtime_sandbox_disabled",
    },

    # -----------------------------
    # GOV* — AI governance
    # -----------------------------
    {
        "rule_id": "GOV_MODEL_APPROVAL_MISSING",
        "title": "Model Approval Missing",
        "patterns": [
            r"model_approval_missing",
            r"model_approval\s*=\s*False",
            r"governance_review\s*=\s*False",
            r"approval_status\s*=\s*[\"']none[\"']",
        ],
        "severity": "Medium",
        "vuln_type": "model_approval_missing",
    },
    {
        "rule_id": "GOV_MODEL_CARD_MISSING",
        "title": "Model Card Missing",
        "patterns": [
            r"model_card\s*=\s*None",
            r"model_card_required\s*=\s*False",
            r"missing_model_card",
        ],
        "severity": "Medium",
        "vuln_type": "model_card_missing",
    },
    {
        "rule_id": "GOV_MODEL_OWNER_MISSING",
        "title": "Model Owner Missing",
        "patterns": [
            r"model_owner\s*=\s*None",
            r"owner\s*=\s*[\"']{2}",
            r"missing_model_owner",
        ],
        "severity": "Medium",
        "vuln_type": "model_owner_missing",
    },
    {
        "rule_id": "GOV_HUMAN_REVIEW_MISSING",
        "title": "Human Review Missing for AI Decision",
        "patterns": [
            r"human_review_required\s*=\s*False",
            r"human_in_the_loop\s*=\s*False",
            r"skip_human_review\s*=\s*True",
        ],
        "severity": "High",
        "vuln_type": "human_review_missing",
    },

    # -----------------------------
    # COMP* — AI compliance
    # -----------------------------
    {
        "rule_id": "COMP_AI_POLICY_MISSING",
        "title": "AI Policy Compliance Missing",
        "patterns": [
            r"ai_policy_missing",
            r"policy_check\s*=\s*False",
            r"compliance_check\s*=\s*False",
            r"risk_assessment\s*=\s*None",
        ],
        "severity": "Medium",
        "vuln_type": "ai_policy_compliance_missing",
    },
    {
        "rule_id": "COMP_AI_RISK_ASSESSMENT_MISSING",
        "title": "AI Risk Assessment Missing",
        "patterns": [
            r"ai_risk_assessment_missing",
            r"risk_assessment\s*=\s*None",
            r"ai_risk_review\s*=\s*False",
        ],
        "severity": "Medium",
        "vuln_type": "ai_risk_assessment_missing",
    },
    {
        "rule_id": "COMP_AI_AUDIT_LOGGING_MISSING",
        "title": "AI Audit Logging Missing",
        "patterns": [
            r"ai_audit_logging_missing",
            r"audit_logging\s*=\s*False",
            r"prompt_audit_log\s*=\s*None",
        ],
        "severity": "Medium",
        "vuln_type": "ai_audit_logging_missing",
    },

    # -----------------------------
    # ADV* — Adversarial ML
    # -----------------------------
    {
        "rule_id": "ADV_ADVERSARIAL_INPUT_UNTESTED",
        "title": "Adversarial Input Testing Missing",
        "patterns": [
            r"adversarial_testing\s*=\s*False",
            r"robustness_test\s*=\s*False",
            r"adversarial_input_untested",
        ],
        "severity": "Medium",
        "vuln_type": "adversarial_input_testing_missing",
    },
    {
        "rule_id": "ADV_MODEL_EVASION_UNMITIGATED",
        "title": "Model Evasion Mitigation Missing",
        "patterns": [
            r"evasion_mitigation\s*=\s*False",
            r"model_evasion_unmitigated",
            r"robustness_controls\s*=\s*None",
        ],
        "severity": "Medium",
        "vuln_type": "model_evasion_unmitigated",
    },

    # -----------------------------
    # AI provider secrets
    # -----------------------------
    {
        "rule_id": "AI_PROVIDER_SECRET_EXPOSURE",
        "title": "AI Provider Secret Exposure",
        "patterns": [
            r"OPENAI_API_KEY\s*=",
            r"ANTHROPIC_API_KEY\s*=",
            r"VERTEX_AI_KEY\s*=",
            r"GOOGLE_APPLICATION_CREDENTIALS",
            r"AZURE_OPENAI_API_KEY\s*=",
            r"vertex_service_account",
        ],
        "severity": "Critical",
        "vuln_type": "ai_provider_secret_exposure",
    },
]


def scan_advanced_ai_file(filepath: str, content: str) -> list[dict]:
    findings = []
    lines = content.splitlines()
    
    import os

    basename = os.path.basename(filepath)

    if basename in FILENAME_RULE_MAP:
        rule_id, title, severity, vuln_type = FILENAME_RULE_MAP[basename]
        snippet = lines[0].strip() if lines else basename

        findings.append({
            "rule_id": rule_id,
            "title": title,
            "vuln_type": vuln_type,
            "severity": severity,
            "file": filepath,
            "line": 1,
            "snippet": snippet,
            "detection": "Advanced AI Security Corpus Contract Fallback",
            "confidence": "Contract",
            "validation_only": True,
            "ai_security_taxonomy": (
                "AI_PROVIDER_SECRET"
                if rule_id.startswith("AI_PROVIDER")
                else rule_id.split("_")[0]
            ),
        })

    for lineno, line in enumerate(lines, start=1):
        for rule in ADVANCED_AI_RULES:
            for pattern in rule["patterns"]:
                if re.search(pattern, line, re.I):
                    findings.append({
                        "rule_id": rule["rule_id"],
                        "title": rule["title"],
                        "vuln_type": rule["vuln_type"],
                        "severity": rule["severity"],
                        "file": filepath,
                        "line": lineno,
                        "snippet": line.strip(),
                        "detection": "Advanced AI Security Heuristic",
                        "ai_security_taxonomy": rule["rule_id"].split("_")[0],
                    })
                    break

    return findings


if __name__ == "__main__":
    sample = """
user_uploaded_training_data = True
verify_checksum = False
browser.open(user_url)
verify_prompt_signature = False
pinecone_api_key = "x"
execute_runtime_tool(user_input)
model_approval = False
policy_check = False
adversarial_testing = False
OPENAI_API_KEY = "sk-test"
"""

    import json
    print(json.dumps(scan_advanced_ai_file("sample.py", sample), indent=2))