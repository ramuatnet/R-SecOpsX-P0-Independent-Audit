"""
scanner/idor_detector.py
========================
Behaviour-based IDOR detector using AST taint analysis.

Three conditions must ALL hold before a finding is raised:
  1. A user-controlled identifier reaches a data-access sink.
  2. The flow is not suppressed by a real ownership / authorization check.
  3. (Route-based path) the route has a variable segment <param> that feeds a sink.

Detection strategy
------------------
* Uses a lightweight single-function taint propagation (no cross-function).
* Suppresses findings when ownership patterns are present in the same scope.
* Complements (does NOT replace) the taint_engine.py general analysis.

Auth suppression patterns (cause the finding to be dropped)
-----------------------------------------------------------
  Sufficient (suppress IDOR):
    current_user.id  == var  /  var == current_user.id   (ownership compare)
    is_authorized(   / check_access(  / has_permission(
    if var not in allowed_ids / whitelist / allowed
    AND owner_id=?  / AND user_id=current_user   in a DB query string

  Insufficient (IDOR still flagged):
    current_user.is_authenticated              (authn ≠ authz)
    int(var) / str(var)                        (type-cast ≠ authz)
    current_user.email == var                  (wrong attribute)
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Taint sources — expressions whose return value is user-controlled
# ---------------------------------------------------------------------------
_TAINT_SOURCE_RE = re.compile(
    r"""
    request\.(?:args|GET|POST|form|params|data|values|files|view_args)
        \.get\s*\(
    | request\.(?:args|GET|POST|form)\s*\[
    | request\.(?:json|data|get_json)\b
    """,
    re.VERBOSE | re.IGNORECASE,
)

# Function/attribute names that indicate the function argument receives a
# user-controlled value (used for route-variable path params).
_ROUTE_SOURCES: frozenset[str] = frozenset({
    "user_id", "uid", "account_id", "item_id", "order_id",
    "record_id", "doc_id", "pk", "obj_id", "id", "file_id",
})

# ---------------------------------------------------------------------------
# Data-access sinks that constitute an IDOR when reached by tainted data
# ---------------------------------------------------------------------------
_IDOR_SINKS: frozenset[str] = frozenset({
    # Generic DB helpers
    "db.get", "db.find", "db.fetch", "db.query",
    # SQLAlchemy
    "session.get", "session.query",
    # Django ORM
    "objects.get", "objects.filter", "objects.exclude",
    "get_object_or_404",
    # Mongo / generic ORMs
    "collection.find_one", "collection.find",
    "Model.get", "Model.find",
    # Generic by-ID helpers
    "find_by_id", "get_by_id", "fetch_by_id",
    "findById", "findOne",
    # File system — user-controlled path reaching open()
    "open",
    # External HTTP with user-controlled resource ID (e.g. internal API call)
    "requests.get", "requests.post",
    # Raw SQL execute (even without 'sql_injection' label here, an ID-driven
    # execute without owner-filter is IDOR)
    "execute", "cursor.execute",
    # Repository / DAO patterns
    "repository.fetch", "repository.find", "repository.get",
    "repo.get", "repo.find",
    "User.find_by_id", "User.objects.get",
})

# ---------------------------------------------------------------------------
# Auth / ownership suppression patterns
# These make a finding safe — IDOR is NOT raised when they appear in scope.
# ---------------------------------------------------------------------------

# Pattern: current_user.id compared to the tainted variable
_OWNERSHIP_CMP_RE = re.compile(
    r"current_user\.id\s*(?:==|!=|is)\s*\w+"
    r"|"
    r"\w+\s*(?:==|!=|is)\s*current_user\.id",
    re.IGNORECASE,
)

# Authorization function calls
_AUTH_FUNC_RE = re.compile(
    r"\b(?:is_authorized|check_access|has_permission|require_permission"
    r"|authorize|can_access|check_permission)\s*\(",
    re.IGNORECASE,
)

# Allowlist / denylist membership check on the tainted variable
_ALLOWLIST_RE = re.compile(
    r"\bnot\s+in\s+\w*(?:allowed|whitelist|permit|safe)\w*"
    r"|\bnot\s+in\s+\w*_ids\b",
    re.IGNORECASE,
)

# SQL query string contains owner-filter (inline, not parameterised check)
_OWNER_FILTER_SQL_RE = re.compile(
    r"AND\s+(?:owner_id|user_id|account_id)\s*[=!]",
    re.IGNORECASE,
)

# Auth decorators on the function (Flask-Login, custom)
_AUTH_DECORATOR_RE = re.compile(
    r"\blogin_required\b|\bjwt_required\b|\btoken_required\b"
    r"|\brequire_auth\b|\bpermission_required\b",
    re.IGNORECASE,
)

# ── Patterns that look like auth but are NOT sufficient ──────────────────────
# is_authenticated is authn, not authz — still an IDOR
# Type-casting (int(), str()) is sanitisation, not authorisation
# Comparing wrong attribute (current_user.email != user_id) is not ownership
_INSUFFICIENT_AUTH_RE = re.compile(
    r"current_user\.is_authenticated"
    r"|"
    r"\bint\s*\(\s*\w+\s*\)"
    r"|"
    r"current_user\.(?!id\b)\w+\s*==",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Route variable regex (matches ast.unparse output, no @ prefix)
# ---------------------------------------------------------------------------
_ROUTE_VAR_RE = re.compile(r"route\s*\(.*<[^>]+>", re.IGNORECASE)


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------
@dataclass
class IDORFinding:
    file:       str
    line:       int
    snippet:    str
    taint_path: str
    confidence: str   # "High" | "Medium"
    note:       str   = ""
    suppressed: bool  = False   # True = would have fired but auth was found
    vuln_type:  str   = "api_idor"
    detection:  str   = "Taint Flow Analysis"


# ---------------------------------------------------------------------------
# Single-function taint tracker
# ---------------------------------------------------------------------------
class _FunctionAnalyser(ast.NodeVisitor):
    """
    Lightweight per-function taint propagation.

    Tracks variables that hold user-controlled values and checks whether
    they reach an IDOR sink without a real ownership/authorization check
    in the same function scope.
    """

    def __init__(self, source_lines: list[str], filepath: str):
        self._lines     = source_lines
        self._filepath  = filepath
        self._tainted:  dict[str, str] = {}   # varname -> taint_path string
        self._findings: list[IDORFinding]  = []

    # ── Public entry ─────────────────────────────────────────────────────────

    def analyse_function(self, func_node: ast.FunctionDef | ast.AsyncFunctionDef,
                         route_vars: list[str] | None = None) -> list[IDORFinding]:
        """Analyse one function; route_vars are the <param> names from the route."""
        self._tainted = {}
        self._findings = []
        self._route_vars = set(route_vars or [])

        # Seed taint from route parameters that match known ID-param names
        for arg in func_node.args.args:
            if arg.arg in _ROUTE_SOURCES or arg.arg in self._route_vars:
                self._tainted[arg.arg] = arg.arg   # initial path = the param name

        # Walk the function body
        for stmt in func_node.body:
            self._visit_stmt(stmt)

        # Return only un-suppressed findings
        return [f for f in self._findings if not f.suppressed]

    # ── Statement visitor ────────────────────────────────────────────────────

    def _visit_stmt(self, node: ast.stmt) -> None:
        """Dispatch a single statement for taint propagation."""
        if isinstance(node, ast.Assign):
            self._handle_assign(node)
        elif isinstance(node, (ast.Expr, ast.Return)):
            self._handle_expr(node)
        elif isinstance(node, ast.If):
            self._handle_if(node)
        elif isinstance(node, (ast.For, ast.While, ast.With)):
            for child in ast.walk(node):
                if child is not node and isinstance(child, ast.stmt):
                    self._visit_stmt(child)
        # Other stmt types: not interesting for IDOR

    def _handle_assign(self, node: ast.Assign) -> None:
        """Propagate taint through assignments and detect source calls."""
        rhs_taint = self._taint_of_expr(node.value)
        for target in node.targets:
            if isinstance(target, ast.Name):
                if rhs_taint:
                    # Propagate: lhs is now tainted
                    self._tainted[target.id] = rhs_taint + " -> " + target.id
                else:
                    # Assignment may clear taint (but only at this scope level)
                    self._tainted.pop(target.id, None)
        # Also check if the RHS itself is a sink call reaching tainted data
        if isinstance(node.value, ast.Call):
            self._check_sink_call(node.value)

    def _handle_expr(self, node: ast.Expr | ast.Return) -> None:
        """Check expression / return statement for sink calls."""
        value = node.value if isinstance(node, ast.Return) else node.value
        if value is None:
            return
        for call in _calls_in(value):
            self._check_sink_call(call)

    def _handle_if(self, node: ast.If) -> None:
        """
        Handle if-statements.
        An 'if … return Forbidden' guard only suppresses IDOR for the ELSE
        branch. We conservatively flag if ANY code path reaches the sink
        without authorisation (E1 mixed-safe-unsafe case).
        We simply visit both branches without modelling branch-level taint
        splitting — this catches E1 correctly.
        """
        # Visit test expression for sink calls (rare, but possible)
        for call in _calls_in(node.test):
            self._check_sink_call(call)
        # Visit both branches
        for stmt in node.body + node.orelse:
            self._visit_stmt(stmt)

    # ── Taint helper ─────────────────────────────────────────────────────────

    def _taint_of_expr(self, node: ast.expr) -> str:
        """
        Return a taint-path string if the expression is tainted, else ''.

        Handles:
          - Direct Name references
          - Source calls: request.args.get('user_id')
          - Propagation through function calls: int(uid), transform(uid)
          - f-strings containing tainted values
          - BinOp / JoinedStr with tainted sub-expressions
        """
        if isinstance(node, ast.Name):
            return self._tainted.get(node.id, "")

        if isinstance(node, ast.Call):
            # Is this a taint source?
            call_str = _unparse_call(node)
            for src in TAINT_SOURCES_STR:
                if call_str.startswith(src):
                    # Extract the argument string for the path label
                    arg_label = _first_str_arg(node) or call_str
                    return arg_label

            # Propagation through arbitrary function call:
            # if any argument is tainted, the result is tainted
            # (conservative — models int(uid), transform(uid), fetch(uid) etc.)
            for arg in node.args:
                tp = self._taint_of_expr(arg)
                if tp:
                    return tp + " -> [call]"
            return ""

        if isinstance(node, (ast.JoinedStr, ast.BinOp)):
            # f-string or concatenation: tainted if any part is tainted
            for child in ast.walk(node):
                if isinstance(child, ast.Name):
                    tp = self._tainted.get(child.id, "")
                    if tp:
                        return tp + " -> [fstring]"
            return ""

        if isinstance(node, ast.Attribute):
            # request.args, current_user.id — check if the object is tainted
            tp = self._taint_of_expr(node.value)
            return (tp + "." + node.attr) if tp else ""

        if isinstance(node, ast.Subscript):
            tp = self._taint_of_expr(node.value)
            return tp if tp else ""

        return ""

    # ── Sink checker ─────────────────────────────────────────────────────────

    def _check_sink_call(self, call_node: ast.Call) -> None:
        """
        If call_node is an IDOR sink AND any argument is tainted AND no
        ownership/auth check suppresses the finding → record an IDORFinding.
        """
        call_str = _unparse_call(call_node)
        sink_name = _match_sink(call_str)
        if not sink_name:
            return

        # Check if any argument carries taint
        tainted_path = ""
        for arg in call_node.args + [kw.value for kw in call_node.keywords]:
            tp = self._taint_of_expr(arg)
            if tp:
                tainted_path = tp
                break
        if not tainted_path:
            return   # sink reached, but no tainted input

        lineno  = getattr(call_node, "lineno", 0)
        snippet = self._lines[lineno-1].strip() if lineno <= len(self._lines) else call_str

        # Build full taint path label
        full_path = tainted_path + " -> " + call_str

        self._findings.append(IDORFinding(
            file=self._filepath,
            line=lineno,
            snippet=snippet,
            taint_path=full_path,
            confidence="High",
            note="User-controlled identifier reaches data-access sink without authorization validation.",
        ))


# ---------------------------------------------------------------------------
# Auth suppression pass — applied to the entire function body text
# ---------------------------------------------------------------------------

# Regex to count data-access sink calls in function source
_SINK_CALL_RE = re.compile(
    r"(?:db|session|objects|collection|cursor|repo(?:sitory)?)"
    r"\.(?:get|find|filter|query|execute|fetch)\s*\("
    r"|find_by_id\s*\(|findById\s*\(|get_object_or_404\s*\(|open\s*\(",
    re.IGNORECASE,
)


def _suppressed_by_auth(func_src: str,
                        func_node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """
    Return True ONLY if ALL tainted-data paths through the function are
    protected by a real ownership / authorization check.

    Key insight for E1 (mixed safe+unsafe):
      If there are multiple sink calls in the function and only ONE of them
      is inside an ownership-protected if-block, the function is NOT fully
      suppressed — the unguarded sink path is still an IDOR.

    Patterns that ARE sufficient (when they cover ALL sink calls):
      • current_user.id == var  — direct ownership comparison
      • is_authorized(…) / check_access(…) / has_permission(…)
      • if var not in allowed_ids / whitelist
      • SQL: AND owner_id=? inline guard

    Patterns that are NOT sufficient:
      • current_user.is_authenticated  (authn ≠ authz)
      • int(user_id) / str(user_id)   (type-cast)
      • current_user.email == var     (wrong attribute)
    """
    has_ownership = bool(_OWNERSHIP_CMP_RE.search(func_src))
    has_auth_func = bool(_AUTH_FUNC_RE.search(func_src))
    has_allowlist = bool(_ALLOWLIST_RE.search(func_src))
    has_owner_sql = bool(_OWNER_FILTER_SQL_RE.search(func_src))

    if not (has_ownership or has_auth_func or has_allowlist or has_owner_sql):
        return False  # no auth at all

    # Count how many distinct sink calls are present
    sink_calls = _SINK_CALL_RE.findall(func_src)
    if len(sink_calls) <= 1:
        # Single sink — the auth check covers it
        return True

    # Multiple sinks: ownership comparison only suppresses if it guards ALL paths.
    # A simple heuristic: if there are N sink calls and the function has an
    # unconditional (not-inside-if) sink call after the auth check, it's NOT safe.
    # We detect this by checking if the auth expression appears on a line where
    # the NEXT non-empty line is NOT a return/raise (i.e. execution continues).
    if has_auth_func or has_allowlist or has_owner_sql:
        # These are typically guard-clause patterns (return Forbidden immediately)
        # so they suppress even with multiple sinks.
        return True

    if has_ownership:
        # Ownership check inside an if-block: only safe when it wraps ALL sinks.
        # Heuristic: count sink calls inside vs outside if-blocks.
        # If any sink call line is at base indentation (not inside an if),
        # the function has an unguarded path.
        lines = func_src.split("\n")
        base_indent = len(lines[0]) - len(lines[0].lstrip()) if lines else 0
        unguarded_sinks = 0
        in_if = False
        if_indent = 999
        for line in lines:
            stripped = line.lstrip()
            indent = len(line) - len(stripped)
            if stripped.startswith("if ") and indent <= base_indent + 4:
                in_if = True
                if_indent = indent
            elif in_if and indent <= if_indent:
                in_if = False   # exited the if block
            if not in_if and _SINK_CALL_RE.search(stripped):
                unguarded_sinks += 1
        return unguarded_sinks == 0  # safe only if no unguarded sinks

    return False


# ---------------------------------------------------------------------------
# Route decorator scanner
# ---------------------------------------------------------------------------

def _get_route_vars(func_node: ast.FunctionDef | ast.AsyncFunctionDef) -> list[str]:
    """Return <param> names from Flask/FastAPI route decorators, e.g. [user_id]."""
    route_vars: list[str] = []
    for deco in func_node.decorator_list:
        try:
            deco_str = ast.unparse(deco)
        except Exception:
            continue
        if _ROUTE_VAR_RE.search(deco_str):
            route_vars += re.findall(r"<(?:[^:>]+:)?([^>]+)>", deco_str)
    return route_vars


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

TAINT_SOURCES_STR: list[str] = [
    "request.args.get",  "request.GET.get",   "request.POST.get",
    "request.form.get",  "request.params.get","request.data.get",
    "request.values.get","request.args[",     "request.GET[",
    "request.form[",     "request.get_json",  "request.json",
]


def analyse_file(filepath: str) -> list[dict]:
    """
    Run IDOR taint analysis on a Python source file.

    Returns a list of finding dicts compatible with the rest of the pipeline
    (same keys as findings from sast.py / taint_engine.py).
    """
    try:
        source = Path(filepath).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    lines    = source.splitlines()
    findings = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        # Extract source text for this function for the suppression regex checks
        func_start = node.lineno - 1
        func_end   = getattr(node, "end_lineno", func_start + 30)
        func_src   = "\n".join(lines[func_start:func_end])

        # Collect route path variables (<user_id> etc.)
        route_vars = _get_route_vars(node)

        # Analyse taint flow inside this function
        analyser = _FunctionAnalyser(lines, filepath)
        raw = analyser.analyse_function(node, route_vars)
        if not raw:
            continue

        # Suppression check — applied once per function
        if _suppressed_by_auth(func_src, node):
            continue   # all findings in this function are suppressed

        # Emit findings
        for f in raw:
            findings.append(_make_finding_dict(f, filepath))

    return findings


def _make_finding_dict(f: IDORFinding, filepath: str) -> dict:
    """Convert IDORFinding → pipeline-compatible dict."""
    from scanner.sast import _iac_api_finding   # avoid circular at module load
    base = _iac_api_finding("api_idor", filepath, f.line, f.snippet, "python")
    base.update({
        "taint_path":  f.taint_path,
        "taint_chain": f.taint_path.split(" -> "),
        "detection":   "TAINT-VALIDATED",
        "confidence":  f.confidence,
        "note":        f.note,
        "group_key":   f"api_idor|{f.taint_path}",
    })
    return base


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _unparse_call(node: ast.Call) -> str:
    """Best-effort string representation of a Call node's function part."""
    try:
        return ast.unparse(node.func)
    except Exception:
        return ""


def _first_str_arg(node: ast.Call) -> str:
    """Return the first string-literal argument of a call, if any."""
    for arg in node.args:
        if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
            return f"request.args.get('{arg.value}')"
    return ""


def _match_sink(call_str: str) -> str:
    """Return the matched sink name if call_str matches an IDOR sink, else ''."""
    for sink in _IDOR_SINKS:
        if call_str == sink or call_str.endswith("." + sink.split(".")[-1]):
            return sink
        # Handle method calls: objects.get, User.find_by_id etc.
        if sink in call_str:
            return sink
    return ""


def _calls_in(node: ast.expr) -> list[ast.Call]:
    """Collect all Call nodes inside an expression (non-recursive top-level)."""
    calls = []
    for child in ast.walk(node):
        if isinstance(child, ast.Call):
            calls.append(child)
    return calls
