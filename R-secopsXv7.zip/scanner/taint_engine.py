"""
scanner/taint_engine.py
Backward-compatible AST taint engine for Python plus lightweight enterprise
source-to-sink scanning for Java/Spring, .NET, Node/TS, Go, PHP and GraphQL.

Public API preserved:
- analyze_file(filepath) -> list[dict]
"""
from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:
    from core.mapper import get_mapping
except Exception:
    def get_mapping(vuln_type: str) -> dict:
        return {}

TAINT_SOURCES = {
    "request.args", "request.form", "request.json", "request.data", "request.headers", "request.cookies",
    "request.values", "request.get_json", "request.files", "input", "sys.argv", "os.environ", "os.getenv",
    "params", "query", "kwargs",
}

DANGEROUS_SINKS: dict[str, str] = {
    "execute": "sql_injection", "executemany": "sql_injection", "raw": "sql_injection", "cursor.execute": "sql_injection",
    "subprocess.call": "command_injection", "subprocess.run": "command_injection", "subprocess.Popen": "command_injection", "os.system": "command_injection", "os.popen": "command_injection",
    "open": "path_traversal", "os.path.join": "path_traversal", "os.listdir": "path_traversal", "os.remove": "path_traversal", "os.rename": "path_traversal",
    "eval": "code_injection", "exec": "code_injection", "compile": "code_injection",
    "pickle.load": "insecure_deserialization", "pickle.loads": "insecure_deserialization", "yaml.load": "insecure_deserialization", "marshal.loads": "insecure_deserialization", "jsonpickle.decode": "insecure_deserialization",
    "requests.get": "ssrf", "requests.post": "ssrf", "requests.put": "ssrf", "requests.delete": "ssrf", "requests.request": "ssrf", "urllib.request.urlopen": "ssrf", "http.client.HTTPConnection": "ssrf", "http.client.HTTPSConnection": "ssrf",
    "redirect": "open_redirect", "render_template_string": "xss", "Markup": "xss",
}

LANG_BY_EXT = {".py":"python", ".java":"java", ".cs":"csharp", ".js":"javascript", ".jsx":"javascript", ".ts":"typescript", ".tsx":"typescript", ".go":"go", ".php":"php", ".graphql":"graphql", ".gql":"graphql"}
_F = re.IGNORECASE | re.MULTILINE | re.DOTALL


BIG4_TAINT_CONTROLS = {
    "spel_injection": {"pci_dss":"Req 6.2.4 - Prevent injection attacks", "nist":"SI-10", "iso27001":"A.14.2.5", "soc2":"CC6.6"},
    "orm_injection": {"pci_dss":"Req 6.2.4 - Prevent injection attacks", "nist":"SI-10", "iso27001":"A.14.2.5", "soc2":"CC6.1 / CC6.6"},
    "prototype_pollution": {"pci_dss":"Req 6.2.4 - Secure development", "nist":"SI-10 / CM-7", "iso27001":"A.8.28 / A.8.29", "soc2":"CC6.6 / CC7.2"},
    "mass_assignment": {"pci_dss":"Req 6.2.4 / Req 7 - Access control", "nist":"AC-3 / SI-10", "iso27001":"A.9.4.1 / A.14.2.5", "soc2":"CC6.1 / CC6.6"},
    "idor": {"pci_dss":"Req 7 / Req 8 - Access control", "nist":"AC-3 / AC-6", "iso27001":"A.9.4.1", "soc2":"CC6.1"},
    "ssrf": {"pci_dss":"Req 6.2.4 - Prevent SSRF attacks", "nist":"SC-7", "iso27001":"A.13.1.3", "soc2":"CC6.6"},
    "resource_exhaustion": {"pci_dss":"Req 6.2.4 / Req 8 - Abuse prevention", "nist":"AC-7 / SC-5 / SI-10", "iso27001":"A.8.16 / A.8.20", "soc2":"CC7.2 / CC6.6"},
}
BIG4_TAINT_REMEDIATION = {
    "spel_injection": ["Do not evaluate user-controlled input with SpEL parseExpression().", "Replace dynamic expressions with allow-listed server-side operations.", "Use SimpleEvaluationContext and block type/method/constructor references."],
    "orm_injection": ["Use parameter binding for JPQL/HQL/SQL and avoid string concatenation/interpolation.", "Use repository methods or criteria builders with typed parameters.", "Add tests proving malicious query fragments are treated as data."],
    "prototype_pollution": ["Reject __proto__, constructor and prototype keys recursively.", "Use safe merge libraries configured to block prototype mutation.", "Validate object schemas before merging request bodies."],
    "mass_assignment": ["Bind request bodies to DTOs rather than domain/entity objects.", "Allow-list fields and block role, isAdmin, permissions, tenantId, status and balance.", "Authorize server-side after binding and before persistence."],
    "idor": ["Enforce object-level authorization before repository/database lookup returns data.", "Verify tenant and owner match the authenticated principal.", "Add negative authorization tests for cross-user and cross-tenant IDs."],
    "resource_exhaustion": ["Add query depth and complexity limits.", "Set per-user/IP/tenant rate limits and timeouts.", "Reject oversized request bodies and expensive queries."],
}

@dataclass
class TaintedVar:
    name: str
    source: str
    lineno: int
    chain: list[str] = field(default_factory=list)
    def full_chain(self) -> list[str]:
        parts = [self.source] + self.chain + [self.name]
        out: list[str] = []
        for p in parts:
            if not out or out[-1] != p:
                out.append(p)
        return out

@dataclass
class TaintFinding:
    vuln_type: str
    source_var: str
    source_expr: str
    sink_call: str
    file: str
    line: int
    snippet: str
    taint_path: str
    chain: list[str]
    function: str = ""
    rule_id: str = ""
    title: str = ""
    language: str = "python"
    confidence: str = "High"
    severity: str | None = None
    cwe: str = ""
    owasp: str = ""
    remediation: list[str] = field(default_factory=list)

class TaintVisitor(ast.NodeVisitor):
    def __init__(self, lines: list[str], filepath: str):
        self.lines = lines
        self.filepath = filepath
        self.tainted: dict[str, TaintedVar] = {}
        self.findings: list[TaintFinding] = []
        self._cur_func = ""
        self._tainted_returns: dict[str, str] = {}

    def _unparse(self, node) -> str:
        try: return ast.unparse(node)
        except Exception: return "<expr>"
    def _snippet(self, lineno: int) -> str:
        idx = lineno - 1
        return self.lines[idx].rstrip() if 0 <= idx < len(self.lines) else ""
    def _match_source(self, node) -> Optional[str]:
        expr = self._unparse(node)
        for src in TAINT_SOURCES:
            if expr == src:
                return src
        if isinstance(node, ast.Call):
            func_str = self._unparse(node.func)
            for src in TAINT_SOURCES:
                if func_str == src or func_str.startswith(src + ".") or func_str.startswith(src + "["):
                    return expr
            if func_str in self._tainted_returns:
                return f"{func_str}() [returns tainted: {self._tainted_returns[func_str]}]"
        if isinstance(node, (ast.Attribute, ast.Subscript)):
            base = self._unparse(node)
            for src in TAINT_SOURCES:
                if base == src or base.startswith(src + ".") or base.startswith(src + "["):
                    return base
        return None
    def _tainted_names_in(self, node) -> list[str]:
        seen = []
        for child in ast.walk(node):
            if isinstance(child, ast.Name) and child.id in self.tainted and child.id not in seen:
                seen.append(child.id)
        return seen
    def _source_exprs_in(self, node) -> list[str]:
        sources = []
        for child in ast.walk(node):
            src = self._match_source(child)
            if src and src not in sources:
                sources.append(src)
        return sources
    def _chain_for(self, var_name: str) -> list[str]:
        return self.tainted[var_name].full_chain() if var_name in self.tainted else [var_name]
    def _make_path(self, chain: list[str], sink: str) -> str:
        out = []
        for p in chain + [sink]:
            if not out or out[-1] != p:
                out.append(p)
        return " -> ".join(out)
    def _record(self, vuln_type: str, chain: list[str], sink_str: str, call_node: ast.Call):
        self.findings.append(TaintFinding(vuln_type, chain[0] if chain else "", chain[0] if chain else "", sink_str, self.filepath, call_node.lineno, self._snippet(call_node.lineno), self._make_path(chain, sink_str), chain, self._cur_func))
    def _check_sink(self, call: ast.Call):
        call_str = self._unparse(call.func)
        for sink_key, vuln_type in DANGEROUS_SINKS.items():
            if call_str != sink_key and not call_str.endswith("." + sink_key):
                continue
            all_args = list(call.args) + [kw.value for kw in call.keywords]
            for arg in all_args:
                names = self._tainted_names_in(arg)
                if names:
                    self._record(vuln_type, self._chain_for(names[0]), call_str, call); return
            for arg in all_args:
                srcs = self._source_exprs_in(arg)
                if srcs:
                    self._record(vuln_type, [srcs[0]], call_str, call); return
    def visit_Assign(self, node: ast.Assign):
        rhs = node.value
        src_label = self._match_source(rhs)
        if src_label is not None:
            for t in node.targets:
                if isinstance(t, ast.Name):
                    self.tainted[t.id] = TaintedVar(t.id, src_label, node.lineno, [])
        else:
            names = self._tainted_names_in(rhs)
            if names:
                parent = self.tainted[names[0]]
                for t in node.targets:
                    if isinstance(t, ast.Name):
                        new_chain = parent.full_chain() + [t.id]
                        self.tainted[t.id] = TaintedVar(t.id, parent.source, node.lineno, new_chain[1:])
        self.generic_visit(node)
    def visit_AugAssign(self, node: ast.AugAssign):
        if isinstance(node.target, ast.Name):
            t_name = node.target.id
            src_label = self._match_source(node.value)
            names = self._tainted_names_in(node.value)
            if src_label:
                self.tainted.setdefault(t_name, TaintedVar(t_name, src_label, node.lineno, []))
            elif names and t_name not in self.tainted:
                parent = self.tainted[names[0]]
                self.tainted[t_name] = TaintedVar(t_name, parent.source, node.lineno, parent.full_chain()[1:] + [t_name])
        self.generic_visit(node)
    def visit_FunctionDef(self, node: ast.FunctionDef):
        prev = self._cur_func; self._cur_func = node.name
        self.generic_visit(node)
        self._cur_func = prev
    visit_AsyncFunctionDef = visit_FunctionDef
    def visit_Return(self, node: ast.Return):
        if node.value is not None and self._cur_func:
            names = self._tainted_names_in(node.value)
            if names:
                self._tainted_returns[self._cur_func] = " -> ".join(self._chain_for(names[0]))
            else:
                src = self._match_source(node.value)
                if src and "[returns tainted" not in src:
                    self._tainted_returns[self._cur_func] = src
        self.generic_visit(node)
    def visit_Call(self, node: ast.Call):
        self._check_sink(node)
        self.generic_visit(node)

# Lightweight source-to-sink rules for non-Python and framework patterns.
ENTERPRISE_TAINT_RULES = [
    {"id":"TAINT_SPRING_SPEL_INJECTION","title":"Spring SpEL Injection","vuln":"spel_injection","lang":["java"],"sev":"Critical","cwe":"CWE-94","owasp":"A03:2021 - Injection","src":r"request|getParameter|@RequestParam|@PathVariable|input|param","sink":r"SpelExpressionParser|parseExpression|ExpressionParser"},
    {"id":"TAINT_SPRING_QUERY_INJECTION","title":"Spring Data @Query / JPQL Injection","vuln":"orm_injection","lang":["java"],"sev":"High","cwe":"CWE-89","owasp":"A03:2021 - Injection","src":r"@RequestParam|@PathVariable|request|getParameter|param","sink":r"@Query|createQuery|createNativeQuery|EntityManager|JpaRepository"},
    {"id":"TAINT_EF_FROMSQLRAW","title":"EF FromSqlRaw Injection","vuln":"orm_injection","lang":["csharp"],"sev":"High","cwe":"CWE-89","owasp":"A03:2021 - Injection","src":r"Request\.|FromQuery|FromRoute|FromBody|route|query","sink":r"FromSqlRaw|ExecuteSqlRaw|SqlQuery"},
    {"id":"TAINT_NOSQL_INJECTION","title":"NoSQL Injection","vuln":"nosql_injection","lang":["javascript","typescript","python","java","php"],"sev":"High","cwe":"CWE-943","owasp":"A03:2021 - Injection","src":r"req\.|request\.|\$_GET|\$_POST|body|query|params","sink":r"findOne|find\(|updateOne|deleteOne|\$where|\$regex|MongoClient"},
    {"id":"TAINT_SSRF_EXPANDED","title":"SSRF Dynamic Outbound Request","vuln":"ssrf","lang":["javascript","typescript","python","java","csharp","go","php"],"sev":"High","cwe":"CWE-918","owasp":"A10:2021 - Server-Side Request Forgery","src":r"req\.|request\.|Request\.|r\.URL|\$_GET|\$_POST|query|params|body|getParameter","sink":r"fetch|axios|requests\.|http\.Get|HttpClient|RestTemplate|WebClient|curl_exec|file_get_contents|urlopen"},
    {"id":"TAINT_PROTOTYPE_POLLUTION","title":"Prototype Pollution User Object Merge","vuln":"prototype_pollution","lang":["javascript","typescript"],"sev":"High","cwe":"CWE-1321","owasp":"A08:2021 - Software and Data Integrity Failures","src":r"req\.body|req\.query|body|query","sink":r"Object\.assign|merge|deepmerge|lodash|_\.merge|qs\.parse"},
    {"id":"TAINT_MASS_ASSIGNMENT","title":"Mass Assignment / Overposting","vuln":"mass_assignment","lang":["java","csharp","javascript","typescript","python","php"],"sev":"High","cwe":"CWE-915","owasp":"A01:2021 - Broken Access Control","src":r"@RequestBody|FromBody|req\.body|request\.json|\$_POST|body","sink":r"User|Account|Role|Admin|Entity|Model|create\(|update\(|save\("},
    {"id":"TAINT_MULTIPART_TRAVERSAL","title":"Multipart Upload Path Traversal","vuln":"path_traversal","lang":["java","python","javascript","typescript","csharp","php"],"sev":"High","cwe":"CWE-22","owasp":"A01:2021 - Broken Access Control","src":r"MultipartFile|request\.files|req\.file|IFormFile|\$_FILES|getOriginalFilename|filename","sink":r"transferTo|File\(|Paths\.get|open\(|writeFile|Path\.Combine|move_uploaded_file"},
    {"id":"TAINT_GRAPHQL_RESOLVER_BOLA","title":"GraphQL Resolver BOLA / IDOR","vuln":"idor","lang":["javascript","typescript","python","java","csharp","graphql"],"sev":"High","cwe":"CWE-639","owasp":"A01:2021 - Broken Access Control","src":r"args\.id|id\s*:|@Argument|GraphQLArgument","sink":r"findById|findOne|getById|repository\.find|db\."},

    {"id":"TAINT_GRAPHQL_INTROSPECTION_ENABLED","title":"GraphQL Introspection Enabled","vuln":"graphql_exposure","lang":["javascript","typescript","python","java","csharp","graphql"],"sev":"High","cwe":"CWE-200","owasp":"A05:2021 - Security Misconfiguration","src":r"introspection|graphiql|__schema|__type","sink":r"true|GraphQLPlayground|ApolloServer|GraphQLServer"},
    {"id":"TAINT_GRAPHQL_DEPTH_COMPLEXITY_MISSING","title":"GraphQL Depth / Complexity Abuse Indicator","vuln":"resource_exhaustion","lang":["javascript","typescript","python","java","csharp"],"sev":"High","cwe":"CWE-400","owasp":"API4:2023 - Unrestricted Resource Consumption","src":r"ApolloServer|GraphQLServer|graphqlHTTP|GraphQLModule","sink":r"resolvers|schema|typeDefs|Query|Mutation"},
    {"id":"TAINT_API_RATE_LIMIT_LOGIN","title":"Login/OTP/Reset API Missing Abuse Controls","vuln":"api_rate_limit","lang":["javascript","typescript","python","java","csharp","go","php"],"sev":"High","cwe":"CWE-770","owasp":"API4:2023 - Unrestricted Resource Consumption","src":r"/(?:login|signin|otp|mfa|2fa|reset|forgot|coupon|promo|refresh|token)","sink":r"post|get|PostMapping|HttpPost|router|app\."},
]

def _priority(sev: str) -> str:
    return {"Critical":"P1","High":"P2","Medium":"P3","Low":"P4"}.get(sev,"P3")

def _language(path: Path) -> str:
    return LANG_BY_EXT.get(path.suffix.lower(), path.suffix.lower().lstrip(".") or "unknown")

def _base_finding(rule: dict, filepath: str, line: int, snippet: str, source: str, sink: str, lang: str) -> dict:
    m = get_mapping(rule["vuln"])
    sev = rule.get("sev") or m.get("severity", "High")
    controls = BIG4_TAINT_CONTROLS.get(rule["vuln"], {})
    remediation = BIG4_TAINT_REMEDIATION.get(rule["vuln"]) or m.get("remediation") or ["Use safe framework APIs.", "Validate and authorize user-controlled input before sink use.", "Add security regression tests for this flow."]
    conf = "High" if sev == "Critical" else "Medium"
    return {
        "rule_id": rule["id"], "title": rule["title"], "vuln_type": rule["vuln"], "severity": sev,
        "priority": _priority(sev), "confidence": conf, "language": lang, "file": filepath, "line": line,
        "snippet": snippet.strip(), "description": f"Source-to-sink indicator: {source} reaches {sink} near the same function/block.",
        "remediation": remediation,
        "owasp": rule.get("owasp") or m.get("owasp", ""), "owasp_id": m.get("owasp_id", ""),
        "cwe": rule.get("cwe") or m.get("cwe", ""), "cwe_desc": m.get("cwe_desc", ""),
        "mitre": m.get("mitre", ""), "mitre_desc": m.get("mitre_desc", ""),
        "pci_dss": m.get("pci_dss") or controls.get("pci_dss", ""), "nist": m.get("nist") or controls.get("nist", ""), "nist_800_53": m.get("nist_800_53") or m.get("nist") or controls.get("nist", ""), "iso27001": m.get("iso27001") or controls.get("iso27001", ""), "iso_27001": m.get("iso_27001") or m.get("iso27001") or controls.get("iso27001", ""), "soc2": m.get("soc2") or controls.get("soc2", ""),
        "business_impact": m.get("business_impact", ""), "exploitability": "High",
        "taint_path": f"{source} -> {sink}", "taint_chain": [source, sink], "source_expr": source, "sink_call": sink,
        "evidence": f"{filepath}:{line}: {snippet.strip()}", "detection": "Enterprise Source-to-Sink Heuristic", "engine": "scanner.taint_engine", "cvss": None, "cve": None,
        "group_key": f"{rule['id']}|{filepath}|{line}", "enterprise_control": True,
    }

def _scan_enterprise_text(filepath: str, source: str, lang: str) -> list[dict]:
    lines = source.splitlines()
    findings: list[dict] = []
    # Look in nearby windows, but report the sink line as evidence to avoid mismatched source-only lines.
    for rule in ENTERPRISE_TAINT_RULES:
        if lang not in rule["lang"]:
            continue
        src_re = re.compile(rule["src"], _F)
        sink_re = re.compile(rule["sink"], _F)
        for i, line in enumerate(lines):
            src_match = src_re.search(line)
            if not src_match:
                continue
            start = max(0, i - 4)
            end = min(len(lines), i + 14)
            window_lines = lines[start:end]
            window = "\n".join(window_lines)
            sink_match = sink_re.search(window)
            if sink_match:
                sink = sink_match.group(0)[:80]
                sink_line_offset = window[:sink_match.start()].count("\n")
                evidence_line = start + sink_line_offset + 1
                snippet = lines[evidence_line - 1] if 0 <= evidence_line - 1 < len(lines) else line
                source_label = src_match.group(0)[:80]
                findings.append(_base_finding(rule, filepath, evidence_line, snippet, source_label, sink, lang))
                break
    return findings


def _python_ast_findings(filepath: str, source: str) -> list[dict]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []
    lines = source.splitlines()
    pre = TaintVisitor(lines, filepath); pre.visit(tree)
    visitor = TaintVisitor(lines, filepath); visitor._tainted_returns = dict(pre._tainted_returns); visitor.visit(tree)
    findings = []
    for tf in visitor.findings:
        m = get_mapping(tf.vuln_type)
        sev = tf.severity or m.get("severity", "High")
        snippet = tf.snippet.strip()
        findings.append({
            "rule_id": tf.rule_id or f"TAINT_{tf.vuln_type.upper()}", "title": tf.title or m.get("title", tf.vuln_type.replace("_", " ").title()),
            "vuln_type": tf.vuln_type, "severity": sev, "priority": _priority(sev), "confidence": tf.confidence,
            "language": tf.language, "file": tf.file, "line": tf.line, "snippet": snippet,
            "group_key": f"{tf.vuln_type}|{tf.file}|{tf.line}|{snippet[:100]}", "function": tf.function,
            "description": f"Taint flow: {tf.taint_path}", "remediation": tf.remediation or m.get("remediation", []),
            "owasp": tf.owasp or m.get("owasp", ""), "owasp_id": m.get("owasp_id", ""), "cwe": tf.cwe or m.get("cwe", ""), "cwe_desc": m.get("cwe_desc", ""),
            "mitre": m.get("mitre", ""), "mitre_desc": m.get("mitre_desc", ""), "pci_dss": m.get("pci_dss") or controls.get("pci_dss", ""), "nist": m.get("nist") or controls.get("nist", ""), "nist_800_53": m.get("nist_800_53") or m.get("nist") or controls.get("nist", ""), "iso27001": m.get("iso27001") or controls.get("iso27001", ""), "iso_27001": m.get("iso_27001") or m.get("iso27001") or controls.get("iso27001", ""), "soc2": m.get("soc2") or controls.get("soc2", ""),
            "business_impact": m.get("business_impact", ""), "exploitability": m.get("exploitability", "High"),
            "taint_path": tf.taint_path, "taint_chain": tf.chain, "source_expr": tf.source_expr, "sink_call": tf.sink_call,
            "evidence": f"{tf.file}:{tf.line}: {snippet}", "detection": "AST Taint Analysis", "engine": "scanner.taint_engine", "cvss": None, "cve": None,
        })
    return findings

def analyze_file(filepath: str) -> list[dict]:
    path = Path(filepath)
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    lang = _language(path)
    findings: list[dict] = []
    if lang == "python":
        findings.extend(_python_ast_findings(filepath, source))
    findings.extend(_scan_enterprise_text(filepath, source, lang))
    # Dedup within file.
    seen = set(); out = []
    for f in findings:
        k = f.get("group_key") or f"{f.get('rule_id')}|{f.get('line')}|{f.get('snippet')}"
        if k not in seen:
            seen.add(k); out.append(f)
    return out

if __name__ == "__main__":
    import json, sys
    print(json.dumps(analyze_file(sys.argv[1]), indent=2))
