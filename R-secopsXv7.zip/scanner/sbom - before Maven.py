"""
scanner/sbom.py  v5

CHANGES (v4 → v5):
  1. ADD — pom.xml parser: extracts Maven dependencies (groupId, artifactId, version)
           from Java projects.
  2. ADD — Expanded CVE database with JS ecosystem entries (lodash, axios,
           express, moment, node-fetch, log4j).
  3. FIX — requirements.txt parser now handles extras e.g. Flask[async]==2.0.1
  4. ENH — generate_sbom() returns packages sorted: direct first, then transitive,
           each group alphabetically sorted for consistent report output.
"""
from __future__ import annotations
from scanner.vulnerability_overrides import VULNERABILITY_OVERRIDES

import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

EXCLUDED_DIRS = {"venv", ".venv", "env", "node_modules", ".git", "dist", "build"}


# ---------------------------------------------------------------------------
# Version comparison
# ---------------------------------------------------------------------------

def _lt(v: str, t: str) -> bool:
    def _p(s: str) -> tuple:
        s = re.sub(r"[^0-9.]", "", s)
        try:    return tuple(int(x) for x in s.split(".") if x)
        except: return (0,)
    try:    return _p(v) < _p(t)
    except: return False


# ---------------------------------------------------------------------------
# Offline CVE database
# ---------------------------------------------------------------------------

KNOWN_VULNS: dict[str, list[dict]] = {
    # Python
    "flask":      [{"affected": lambda v: _lt(v,"1.1.0"), "cve":"CVE-2018-1000656",
                    "cvss":7.5,"severity":"High","epss":0.012,
                    "description":"Open redirect in Flask < 1.1.0",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2018-1000656",
                    "fixed":"1.1.0","reachable":True}],
    "jinja2":     [{"affected": lambda v: _lt(v,"2.10.3"), "cve":"CVE-2019-10906",
                    "cvss":8.1,"severity":"High","epss":0.009,
                    "description":"Sandbox escape in Jinja2 < 2.10.3",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2019-10906",
                    "fixed":"2.10.3","reachable":True},
                   {"affected": lambda v: _lt(v,"2.11.3"), "cve":"CVE-2020-28493",
                    "cvss":7.5,"severity":"High","epss":0.006,
                    "description":"ReDoS in Jinja2 < 2.11.3",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2020-28493",
                    "fixed":"2.11.3","reachable":False}],
    "werkzeug":   [{"affected": lambda v: _lt(v,"0.15.5"), "cve":"CVE-2019-14806",
                    "cvss":7.5,"severity":"High","epss":0.015,
                    "description":"Predictable PIN in Werkzeug debugger",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2019-14806",
                    "fixed":"0.15.5","reachable":True}],
    "requests":   [{"affected": lambda v: _lt(v,"2.20.1"), "cve":"CVE-2018-18074",
                    "cvss":9.8,"severity":"Critical","epss":0.042,
                    "description":"Credential exposure via redirect in requests",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2018-18074",
                    "fixed":"2.20.1","reachable":True}],
    "pyyaml":     [{"affected": lambda v: _lt(v,"5.1"), "cve":"CVE-2017-18342",
                    "cvss":9.8,"severity":"Critical","epss":0.089,
                    "description":"Arbitrary code exec via yaml.load()",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2017-18342",
                    "fixed":"5.1","reachable":True}],
    "sqlalchemy":  [{"affected": lambda v: _lt(v,"1.3.0"), "cve":"CVE-2019-7548",
                    "cvss":8.1,"severity":"High","epss":0.018,
                    "description":"SQL injection via ORDER BY in SQLAlchemy",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2019-7548",
                    "fixed":"1.3.0","reachable":True}],
    "cryptography":[{"affected": lambda v: _lt(v,"2.6.1"), "cve":"CVE-2018-10903",
                    "cvss":7.5,"severity":"High","epss":0.007,
                    "description":"GCM nonce reuse in cryptography < 2.6.1",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2018-10903",
                    "fixed":"2.6.1","reachable":False}],
    "urllib3":    [{"affected": lambda v: _lt(v,"1.24.2"), "cve":"CVE-2019-11324",
                    "cvss":7.5,"severity":"High","epss":0.011,
                    "description":"Certificate verification bypass in urllib3",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2019-11324",
                    "fixed":"1.24.2","reachable":True}],
    "django":     [{"affected": lambda v: _lt(v,"2.1.0"), "cve":"CVE-2018-14574",
                    "cvss":6.1,"severity":"Medium","epss":0.005,
                    "description":"Open redirect in Django CommonMiddleware",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2018-14574",
                    "fixed":"2.1.0","reachable":True}],
    "pillow":     [{"affected": lambda v: _lt(v,"6.2.0"), "cve":"CVE-2019-16865",
                    "cvss":7.5,"severity":"High","epss":0.008,
                    "description":"DoS via malformed images in Pillow",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2019-16865",
                    "fixed":"6.2.0","reachable":False}],
    "paramiko":   [{"affected": lambda v: _lt(v,"2.4.2"), "cve":"CVE-2018-1000805",
                    "cvss":9.8,"severity":"Critical","epss":0.035,
                    "description":"Authentication bypass in Paramiko",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2018-1000805",
                    "fixed":"2.4.2","reachable":True}],
    # JS / npm
    "lodash":     [{"affected": lambda v: _lt(v,"4.17.21"), "cve":"CVE-2021-23337",
                    "cvss":7.2,"severity":"High","epss":0.021,
                    "description":"Command injection via lodash template < 4.17.21",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2021-23337",
                    "fixed":"4.17.21","reachable":True}],
    "axios":      [{"affected": lambda v: _lt(v,"0.21.2"), "cve":"CVE-2021-3749",
                    "cvss":7.5,"severity":"High","epss":0.013,
                    "description":"ReDoS in axios < 0.21.2",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2021-3749",
                    "fixed":"0.21.2","reachable":True}],
    "express":    [{"affected": lambda v: _lt(v,"4.17.3"), "cve":"CVE-2022-24999",
                    "cvss":7.5,"severity":"High","epss":0.010,
                    "description":"Open redirect in express < 4.17.3",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2022-24999",
                    "fixed":"4.17.3","reachable":True}],
    "moment":     [{"affected": lambda v: _lt(v,"2.29.4"), "cve":"CVE-2022-24785",
                    "cvss":7.5,"severity":"High","epss":0.018,
                    "description":"Path traversal in moment.js < 2.29.4",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2022-24785",
                    "fixed":"2.29.4","reachable":True}],
    "nodefetch":  [{"affected": lambda v: _lt(v,"2.6.7"), "cve":"CVE-2022-0235",
                    "cvss":6.1,"severity":"Medium","epss":0.008,
                    "description":"Exposure of sensitive information in node-fetch < 2.6.7",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2022-0235",
                    "fixed":"2.6.7","reachable":False}],
    # Java
    "log4j":      [{"affected": lambda v: _lt(v,"2.17.1"), "cve":"CVE-2021-44228",
                    "cvss":10.0,"severity":"Critical","epss":0.975,
                    "description":"Log4Shell: JNDI injection RCE in log4j2 < 2.17.1",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2021-44228",
                    "fixed":"2.17.1","reachable":True}],
    "spring":     [{"affected": lambda v: _lt(v,"5.3.18"), "cve":"CVE-2022-22965",
                    "cvss":9.8,"severity":"Critical","epss":0.970,
                    "description":"Spring4Shell: RCE in Spring Framework < 5.3.18",
                    "nvd":"https://nvd.nist.gov/vuln/detail/CVE-2022-22965",
                    "fixed":"5.3.18","reachable":True}],
}

TRANSITIVE_DEPS: dict[str, list[str]] = {
    "flask":    ["jinja2", "werkzeug"],
    "django":   ["sqlparse"],
    "requests": ["urllib3", "certifi"],
    "express":  ["qs", "path-to-regexp"],
}


# ---------------------------------------------------------------------------
# Parsers
# ---------------------------------------------------------------------------

def _parse_requirements(filepath: str) -> list[dict]:
    """FIX #3: handles extras syntax e.g. Flask[async]==2.0.1"""
    pkgs = []
    for line in Path(filepath).read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith(("#", "-")):
            continue
        # Strip extras: Flask[async] → Flask
        line_clean = re.sub(r"\[.*?\]", "", line)
        m = re.match(r"^([A-Za-z0-9_\-\.]+)\s*(?:[=~<>!]+\s*([\w.\-]+))?", line_clean)
        if m:
            pkgs.append({"name": m.group(1), "version": m.group(2) or "unknown",
                         "ecosystem": "PyPI", "direct": True})
    return pkgs


def _parse_package_json(filepath: str) -> list[dict]:
    pkgs = []
    try:
        data = json.loads(Path(filepath).read_text(encoding="utf-8"))
    except Exception:
        return pkgs
    for section in ("dependencies", "devDependencies"):
        for name, ver in data.get(section, {}).items():
            if isinstance(ver, str):
                version = ver.lstrip("^~>=<")
            elif isinstance(ver, dict):
                version = str(
                    ver.get("version")
                    or ver.get("resolved")
                    or ver.get("url")
                    or "unknown"
                )
            else:
                version = str(ver)

            pkgs.append({
                "name": name,
                "version": version,
                "ecosystem": "npm",
                "direct": True
            })

    return pkgs


def _parse_pom_xml(filepath: str) -> list[dict]:
    """
    ADD #1: Parse Maven pom.xml — extracts <dependency> blocks.
    Handles ${property} version references by storing them as-is
    so the SBOM still lists the package even when version is unknown.
    """
    pkgs = []
    try:
        tree = ET.parse(filepath)
        root = tree.getroot()
        # Maven uses a default namespace — strip it for easy tag matching
        ns = re.match(r'\{.*\}', root.tag)
        prefix = ns.group(0) if ns else ""

        for dep in root.iter(f"{prefix}dependency"):
            artifact = dep.find(f"{prefix}artifactId")
            version  = dep.find(f"{prefix}version")
            if artifact is not None:
                ver_str = (version.text or "unknown") if version is not None else "unknown"
                # Property references like ${spring.version} → mark as unknown
                if ver_str.startswith("${"):
                    ver_str = "unknown"
                pkgs.append({
                    "name":      artifact.text or "unknown",
                    "version":   ver_str,
                    "ecosystem": "Maven",
                    "direct":    True,
                })
    except Exception:
        pass
    return pkgs


# ---------------------------------------------------------------------------
# Enrichment
# ---------------------------------------------------------------------------

def _add_transitive(packages: list[dict]) -> list[dict]:
    existing = {p["name"].lower() for p in packages}
    extra = []
    for pkg in list(packages):
        for trans in TRANSITIVE_DEPS.get(pkg["name"].lower(), []):
            if trans not in existing:
                extra.append({"name": trans, "version": "unknown",
                               "ecosystem": pkg["ecosystem"], "direct": False})
                existing.add(trans)
    return packages + extra


def _normalise(name: str) -> str:
    return name.lower().replace("-", "").replace("_", "").replace(".", "")


# Known typosquat pairs — checked against SBOM package names
_SBOM_TYPOSQUATS: dict[str, str] = {
    "reqests": "requests",    "requets": "requests",
    "reuqests": "requests",   "requestss": "requests",
    "urlib": "urllib",        "djano": "django",
    "diango": "django",       "falsk": "flask",
    "flaks": "flask",         "numpyy": "numpy",
    "nunpy": "numpy",         "panads": "pandas",
    "pands": "pandas",        "paramikoo": "paramiko",
    "pyyamll": "pyyaml",      "cryptograhy": "cryptography",
    "crytography": "cryptography", "colourama": "colorama",
    "pycryto": "pycrypto",    "twilo": "twilio",
    "aiohtpp": "aiohttp",     "boto32": "boto3",
}


def enrich_with_cve(packages: list[dict]) -> list[dict]:
    sbom = []
    for pkg in packages:
        entry = {**pkg, "cve": None, "cvss": None, "severity": "None",
                 "nvd": None, "epss": None,
                 "description": "No known vulnerabilities",
                 "fixed_in": None, "reachable": False}
        key = _normalise(pkg["name"])
        ver = pkg.get("version", "unknown")

        for db_key, vulns in KNOWN_VULNS.items():
            if _normalise(db_key) == key and ver != "unknown":
                applicable = [v for v in vulns if v["affected"](ver)]
                if applicable:
                    worst = max(applicable, key=lambda x: x["cvss"])
                    entry.update({
                        "cve":         worst["cve"],
                        "cvss":        worst["cvss"],
                        "severity":    worst["severity"],
                        "nvd":         worst["nvd"],
                        "epss":        worst.get("epss"),
                        "description": worst["description"],
                        "fixed_in":    worst["fixed"],
                        "reachable":   worst.get("reachable", False),
                    })
                break
        # Issue 7: flag typosquatted package names as supply chain risk
        pkg_norm = _normalise(pkg["name"])
        legit = _SBOM_TYPOSQUATS.get(pkg["name"].lower())
        if legit:
            entry.update({
                "cve":         "TYPOSQUAT",
                "cvss":        8.0,
                "severity":    "High",
                "epss":        None,
                "description": f"Package name '{pkg['name']}' closely resembles '{legit}' — probable typosquatting. Malicious packages execute code on install.",
                "fixed_in":    f"Replace with '{legit}'",
                "reachable":   True,
            })
        sbom.append(entry)
    return sbom


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def generate_sbom(target_path: str) -> list[dict]:
    """
    Locate all dependency manifests under target_path and return enriched SBOM.
    Scans: requirements*.txt, package.json, pom.xml
    ENH #4: output sorted direct-first, then transitive, each group alphabetical.
    """
    target   = Path(target_path)
    packages: list[dict] = []

    for f in target.rglob("requirements*.txt"):
        if not any(p in EXCLUDED_DIRS for p in f.parts):
            packages.extend(_parse_requirements(str(f)))

    for f in target.rglob("package.json"):
        if not any(p in EXCLUDED_DIRS for p in f.parts):
            packages.extend(_parse_package_json(str(f)))

    for f in target.rglob("pom.xml"):
        if not any(p in EXCLUDED_DIRS for p in f.parts):
            packages.extend(_parse_pom_xml(str(f)))

    # Deduplicate
    seen: set = set()
    unique: list[dict] = []
    for p in packages:
        k = (p["name"].lower(), p["version"], p["ecosystem"])
        if k not in seen:
            seen.add(k)
            unique.append(p)

    with_trans = _add_transitive(unique)
    enriched   = enrich_with_cve(with_trans)

    # ENH #4: sort direct first, then transitive, each alphabetically
    enriched.sort(key=lambda p: (0 if p.get("direct", True) else 1,
                                  p.get("name", "").lower()))
    return enriched
