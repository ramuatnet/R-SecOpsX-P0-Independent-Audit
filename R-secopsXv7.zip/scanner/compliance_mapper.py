from __future__ import annotations

from copy import deepcopy


DEFAULT_MAPPINGS = {
    "hardcoded_secret": {
        "frameworks": {
            "OWASP": ["A07:2021 - Identification and Authentication Failures"],
            "CWE": ["CWE-798 - Use of Hard-coded Credentials"],
            "NIST 800-53": ["IA-5", "SC-12", "SC-28"],
            "PCI DSS": ["3.6", "8.3.2", "8.6.1"],
            "ISO 27001": ["A.5.17", "A.8.24"],
            "SOC 2": ["CC6.1", "CC6.6"],
            "MITRE ATT&CK": ["T1552 - Unsecured Credentials"],
        },
        "control_theme": "Credential Protection",
    },
    "sql_injection": {
        "frameworks": {
            "OWASP": ["A03:2021 - Injection"],
            "CWE": ["CWE-89 - SQL Injection"],
            "NIST 800-53": ["SI-10", "SA-11"],
            "PCI DSS": ["6.2.4", "6.4.2"],
            "ISO 27001": ["A.8.28", "A.8.29"],
            "SOC 2": ["CC7.1", "CC7.2"],
            "MITRE ATT&CK": ["T1190 - Exploit Public-Facing Application"],
        },
        "control_theme": "Input Validation",
    },
    "command_injection": {
        "frameworks": {
            "OWASP": ["A03:2021 - Injection"],
            "CWE": ["CWE-78 - OS Command Injection"],
            "NIST 800-53": ["SI-10", "CM-7"],
            "PCI DSS": ["6.2.4"],
            "ISO 27001": ["A.8.28"],
            "SOC 2": ["CC7.1"],
            "MITRE ATT&CK": ["T1059 - Command and Scripting Interpreter"],
        },
        "control_theme": "Command Execution Control",
    },
    "code_injection": {
        "frameworks": {
            "OWASP": ["A03:2021 - Injection"],
            "CWE": ["CWE-94 - Code Injection"],
            "NIST 800-53": ["SI-10", "SA-11"],
            "PCI DSS": ["6.2.4"],
            "ISO 27001": ["A.8.28"],
            "SOC 2": ["CC7.1"],
            "MITRE ATT&CK": ["T1059 - Command and Scripting Interpreter"],
        },
        "control_theme": "Unsafe Dynamic Execution",
    },
    "insecure_deserialization": {
        "frameworks": {
            "OWASP": ["A08:2021 - Software and Data Integrity Failures"],
            "CWE": ["CWE-502 - Deserialization of Untrusted Data"],
            "NIST 800-53": ["SI-10", "SC-18"],
            "PCI DSS": ["6.2.4"],
            "ISO 27001": ["A.8.28"],
            "SOC 2": ["CC7.1"],
            "MITRE ATT&CK": ["T1059 - Command and Scripting Interpreter"],
        },
        "control_theme": "Unsafe Data Processing",
    },
    "ssrf": {
        "frameworks": {
            "OWASP": ["A10:2021 - Server-Side Request Forgery"],
            "CWE": ["CWE-918 - Server-Side Request Forgery"],
            "NIST 800-53": ["SC-7", "SI-10"],
            "PCI DSS": ["1.2.1", "6.2.4"],
            "ISO 27001": ["A.8.20", "A.8.21"],
            "SOC 2": ["CC6.6"],
            "MITRE ATT&CK": ["T1190 - Exploit Public-Facing Application"],
        },
        "control_theme": "Outbound Request Control",
    },
    "api_idor": {
        "frameworks": {
            "OWASP": ["A01:2021 - Broken Access Control"],
            "CWE": ["CWE-639 - Authorization Bypass Through User-Controlled Key"],
            "NIST 800-53": ["AC-3", "AC-6"],
            "PCI DSS": ["7.1", "7.2"],
            "ISO 27001": ["A.5.15", "A.5.18"],
            "SOC 2": ["CC6.1", "CC6.3"],
            "MITRE ATT&CK": ["T1190 - Exploit Public-Facing Application"],
        },
        "control_theme": "Authorization Enforcement",
    },
    "debug_exposure": {
        "frameworks": {
            "OWASP": ["A05:2021 - Security Misconfiguration"],
            "CWE": ["CWE-215 - Information Exposure Through Debug Information"],
            "NIST 800-53": ["CM-6", "SI-11"],
            "PCI DSS": ["6.2.4", "6.5.5"],
            "ISO 27001": ["A.8.9", "A.8.32"],
            "SOC 2": ["CC7.2"],
            "MITRE ATT&CK": ["T1082 - System Information Discovery"],
        },
        "control_theme": "Secure Configuration",
    },
    "vulnerable_dependency": {
        "frameworks": {
            "OWASP": ["A06:2021 - Vulnerable and Outdated Components"],
            "CWE": ["CWE-937 - Use of Vulnerable Third Party Component"],
            "NIST 800-53": ["SI-2", "RA-5", "SA-12"],
            "PCI DSS": ["6.3.3", "6.4.3"],
            "ISO 27001": ["A.8.8", "A.8.9"],
            "SOC 2": ["CC7.1", "CC7.2"],
            "MITRE ATT&CK": ["T1195 - Supply Chain Compromise"],
        },
        "control_theme": "Software Supply Chain Risk",
    },
}


PREFIX_MAPPINGS = {
    "k8s_": {
        "frameworks": {
            "OWASP": ["A05:2021 - Security Misconfiguration"],
            "CWE": ["CWE-250", "CWE-732", "CWE-798"],
            "NIST 800-53": ["AC-6", "CM-6", "CM-7", "SC-7"],
            "PCI DSS": ["2.2.4", "6.2.4"],
            "ISO 27001": ["A.8.9", "A.8.20", "A.8.24"],
            "SOC 2": ["CC6.1", "CC6.6", "CC7.2"],
            "CIS": ["CIS Kubernetes Benchmark"],
        },
        "control_theme": "Kubernetes Security",
    },
    "tf_": {
        "frameworks": {
            "OWASP": ["A05:2021 - Security Misconfiguration"],
            "CWE": ["CWE-284", "CWE-311", "CWE-732", "CWE-798"],
            "NIST 800-53": ["AC-6", "CM-6", "SC-7", "SC-28"],
            "PCI DSS": ["1.2.1", "2.2.4", "3.5.1"],
            "ISO 27001": ["A.8.9", "A.8.20", "A.8.24"],
            "SOC 2": ["CC6.1", "CC6.6"],
            "CIS": ["CIS AWS Foundations Benchmark"],
        },
        "control_theme": "Cloud Infrastructure Security",
    },
    "docker_": {
        "frameworks": {
            "OWASP": ["A05:2021 - Security Misconfiguration"],
            "CWE": ["CWE-250", "CWE-494", "CWE-732", "CWE-798"],
            "NIST 800-53": ["AC-6", "CM-6", "CM-7", "SI-7"],
            "PCI DSS": ["2.2.4", "6.2.4"],
            "ISO 27001": ["A.8.9", "A.8.20", "A.8.24"],
            "SOC 2": ["CC6.1", "CC6.6", "CC7.2"],
            "CIS": ["CIS Docker Benchmark"],
        },
        "control_theme": "Container Image Security",
    },
}


def _mapping_for(finding: dict) -> dict:
    vuln_type = str(finding.get("vuln_type", "")).lower()
    rule_id = str(finding.get("rule_id", "")).lower()

    if vuln_type in DEFAULT_MAPPINGS:
        return DEFAULT_MAPPINGS[vuln_type]

    if rule_id in DEFAULT_MAPPINGS:
        return DEFAULT_MAPPINGS[rule_id]

    for prefix, mapping in PREFIX_MAPPINGS.items():
        if vuln_type.startswith(prefix) or rule_id.startswith(prefix):
            return mapping

    return {
        "frameworks": {
            "NIST 800-53": ["RA-5"],
            "ISO 27001": ["A.8.8"],
            "SOC 2": ["CC7.1"],
        },
        "control_theme": "Security Review",
    }


def enrich_compliance(findings: list[dict]) -> list[dict]:
    enriched = []

    for finding in findings:
        item = deepcopy(finding)
        mapping = _mapping_for(item)

        item["compliance_controls"] = mapping["frameworks"]
        item["control_theme"] = mapping["control_theme"]

        item.setdefault("framework", mapping["control_theme"])
        item.setdefault("control", mapping["control_theme"])

        enriched.append(item)

    return enriched


def compliance_summary(findings: list[dict]) -> dict:
    summary: dict[str, int] = {}

    for finding in findings:
        controls = finding.get("compliance_controls", {})
        for framework in controls:
            summary[framework] = summary.get(framework, 0) + 1

    return dict(sorted(summary.items()))


if __name__ == "__main__":
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description="R-SecOpsX Compliance Mapper")
    parser.add_argument("input", help="Input findings JSON file")
    parser.add_argument("--output", default=None, help="Output enriched JSON file")
    args = parser.parse_args()

    source = Path(args.input)
    data = json.loads(source.read_text(encoding="utf-8"))

    findings = data.get("findings", data if isinstance(data, list) else [])
    enriched = enrich_compliance(findings)

    result = {
        "findings": enriched,
        "compliance_summary": compliance_summary(enriched),
    }

    if args.output:
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(f"[COMPLIANCE] Findings enriched: {len(enriched)}")
        print(f"[COMPLIANCE] Output written: {out}")
    else:
        print(json.dumps(result, indent=2))