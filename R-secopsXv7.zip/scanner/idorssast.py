"""
scanner/sast.py  v6

CHANGES (v5 → v6):
  1. ADD — Debug visibility: scan_directory() prints file count and raw finding
           count to stderr before returning, so coverage can be validated
           without modifying any other module.
  2. ADD — Fallback detection layer (HYBRID):
           After regex rules, a lightweight structural scan catches patterns
           that taint analysis misses:
             a) subprocess + shell=True anywhere in the file (AST-level, not regex)
             b) open() / file access where any argument references a known
                source name (request, input, argv, params, query)
           These are AST-based, not string-regex, so they don't add noise.
  3. KEEP — All v5 rules retained unchanged (secrets, weak crypto, SQL,
            command injection, code injection, XSS, SSRF, deserialization,
            open redirect, auth bypass, debug exposure, sensitive logging).
  4. KEEP — group_key, confidence, language fields on every finding.
"""
from __future__ import annotations

import ast
import re
import sys
from pathlib import Path

from core.mapper import get_mapping

_F = re.IGNORECASE | re.MULTILINE

# ---------------------------------------------------------------------------
# Regex rule definitions
# ---------------------------------------------------------------------------
REGEX_RULES: list[dict] = [

    # ── Secrets ──────────────────────────────────────────────────────────────
    {"name": "AWS Access Key",
     "pattern": re.compile(r"AKIA[0-9A-Z]{16}", _F),
     "vuln_type": "hardcoded_secret", "confidence": "High",
     "note": "AWS access key ID detected in source code."},

    {"name": "GitHub Token",
     "pattern": re.compile(r"ghp_[A-Za-z0-9]{36}", _F),
     "vuln_type": "hardcoded_secret", "confidence": "High",
     "note": "GitHub personal access token detected."},

    {"name": "Generic API Key/Password",
     "pattern": re.compile(
         r'(?:api[_-]?key|api[_-]?token|secret[_-]?key|auth[_-]?token|'
         r'access[_-]?token|password|passwd|pwd)\s*[=:]\s*["\'][A-Za-z0-9@#$%^&+=!_.\-]{8,}["\']',
         _F),
     "vuln_type": "hardcoded_secret", "confidence": "Medium",
     "note": "Possible hardcoded credential or API key."},

    {"name": "Private Key Header",
     "pattern": re.compile(r"-----BEGIN (?:RSA |EC )?PRIVATE KEY-----", _F),
     "vuln_type": "hardcoded_secret", "confidence": "High",
     "note": "Private key material embedded in source."},

    {"name": "JWT Secret",
     "pattern": re.compile(
         r'(?:jwt[_-]?secret|secret[_-]?key)\s*=\s*["\'][^"\']{8,}["\']', _F),
     "vuln_type": "hardcoded_secret", "confidence": "High",
     "note": "JWT signing secret hardcoded."},

    {"name": "High-Entropy Token",
     "pattern": re.compile(
         r'(?:token|bearer|api_token|auth_token|access_token)\s*=\s*["\'\'][A-Za-z0-9+/=_.\-]{20,}["\'\']',
         _F),
     "vuln_type": "hardcoded_secret", "confidence": "Medium",
     "note": "Long token string hardcoded — may be a live credential."},

    # ── Weak crypto ───────────────────────────────────────────────────────────
    {"name": "MD5 Usage",
     "pattern": re.compile(r"hashlib\.md5\s*\(", _F),
     "vuln_type": "weak_crypto", "confidence": "High",
     "note": "MD5 is cryptographically broken; use SHA-256 or bcrypt for passwords."},

    {"name": "SHA-1 Usage",
     "pattern": re.compile(r"hashlib\.sha1\s*\(", _F),
     "vuln_type": "weak_crypto", "confidence": "High",
     "note": "SHA-1 deprecated for cryptographic use."},

    {"name": "DES/3DES Import",
     "pattern": re.compile(r"(?:from|import)\s+.*\bDES\b", _F),
     "vuln_type": "weak_crypto", "confidence": "High",
     "note": "DES/3DES is insecure; use AES-256."},

    {"name": "Insecure Random",
     "pattern": re.compile(r"\brandom\.(?:random|randint|choice|shuffle)\b", _F),
     "vuln_type": "weak_crypto", "confidence": "Medium",
     "note": "random module is not cryptographically secure; use secrets module."},

    # ── SQL Injection ─────────────────────────────────────────────────────────
    # NOTE: parameterized queries (?, %s, :name placeholders followed by a
    # tuple/list second argument) are safe and must NOT be flagged.
    # The patterns below match only string-concatenated or f-string queries.
    # The post-filter _is_parameterized() in scan_file() drops safe matches.
    {"name": "SQL String Concatenation",
     "pattern": re.compile(
         r'(?:execute|executemany|raw)\s*\(\s*["\'].*'
         r'(?:SELECT|INSERT|UPDATE|DELETE|DROP|UNION).*["\'\s+]', _F),
     "vuln_type": "sql_injection", "confidence": "High",
     "note": "SQL query constructed via string concatenation.",
     "check_parameterized": True},

    {"name": "SQL f-string Query",
     "pattern": re.compile(
         r'(?:execute|executemany)\s*\(\s*f["\'].*'
         r'(?:SELECT|INSERT|UPDATE|DELETE|WHERE).*{', _F),
     "vuln_type": "sql_injection", "confidence": "High",
     "note": "SQL query built with f-string — injection risk.",
     "check_parameterized": False},

    # ── Command Injection ─────────────────────────────────────────────────────
    {"name": "subprocess shell=True",
     "pattern": re.compile(r"subprocess\.\w+\s*\([^)]*shell\s*=\s*True", _F),
     "vuln_type": "command_injection", "confidence": "High",
     "note": "subprocess with shell=True enables shell injection; prefer list form with shell=False."},

    {"name": "os.system Call",
     "pattern": re.compile(r"os\.system\s*\(", _F),
     "vuln_type": "command_injection", "confidence": "High",
     "note": "os.system executes shell commands; prefer subprocess with list args."},

    {"name": "os.popen Call",
     "pattern": re.compile(r"os\.popen\s*\(", _F),
     "vuln_type": "command_injection", "confidence": "High",
     "note": "os.popen is deprecated and unsafe; use subprocess."},

    # ── Code Injection ────────────────────────────────────────────────────────
    {"name": "eval() Call",
     "pattern": re.compile(r"\beval\s*\(", _F),
     "vuln_type": "code_injection", "confidence": "Medium",
     "note": "eval() executes arbitrary Python code."},

    {"name": "exec() Call",
     "pattern": re.compile(r"\bexec\s*\(", _F),
     "vuln_type": "code_injection", "confidence": "Medium",
     "note": "exec() executes arbitrary Python code."},

    # ── Path Traversal ────────────────────────────────────────────────────────
    {"name": "Direct File Open with String Concatenation",
     "pattern": re.compile(r'open\s*\(\s*["\'][^"\']*["\'\s]*\+', _F),
     "vuln_type": "path_traversal", "confidence": "High",
     "note": "File path built by string concatenation — user-controlled input may enable path traversal to read arbitrary files."},

    {"name": "Path Join with Variable",
     "pattern": re.compile(r'os\.path\.join\s*\([^)]*(?:request|input|argv|param|user)', _F),
     "vuln_type": "path_traversal", "confidence": "Medium",
     "note": "os.path.join receives user-controlled input — path traversal risk."},

    # ── XSS ──────────────────────────────────────────────────────────────────
    {"name": "render_template_string Concatenation",
     "pattern": re.compile(r'render_template_string\s*\(\s*["\'][^"\']*["\'\s]*\+', _F),
     "vuln_type": "xss", "confidence": "High",
     "note": "Template rendered from concatenated string — reflected XSS risk."},

    {"name": "Markup() Bypass",
     "pattern": re.compile(r"\bMarkup\s*\(", _F),
     "vuln_type": "xss", "confidence": "Medium",
     "note": "Markup() bypasses Jinja2 auto-escaping — verify no user input included."},

    {"name": "innerHTML Assignment",
     "pattern": re.compile(
         # Match: .innerHTML = <non-quote-starting value>  OR  .innerHTML +=
         # Excludes: .innerHTML = 'literal'  and  .innerHTML = "literal"
         r'\.innerHTML\s*\+?=\s*(?!["\'\`](?:[^"\'\`]|\\\.)*["\'\`]\s*;)',
         _F),
     "vuln_type": "xss", "confidence": "High",
     "note": "innerHTML assigned a variable value — confirmed XSS risk if user-controlled.",
     "languages": {"js", "ts", "jsx", "tsx"}},

    {"name": "document.write with Variable",
     "pattern": re.compile(r"document\.write\s*\(", _F),
     "vuln_type": "xss", "confidence": "Medium",
     "note": "document.write() with dynamic content risks XSS.",
     "languages": {"js", "ts", "jsx", "tsx"}},

    {"name": "dangerouslySetInnerHTML",
     "pattern": re.compile(r"dangerouslySetInnerHTML\s*=\s*\{", _F),
     "vuln_type": "xss", "confidence": "Medium",
     "note": "React dangerouslySetInnerHTML bypasses XSS protection.",
     "languages": {"jsx", "tsx", "js", "ts"}},

    # -- IDOR: removed regex rules — detected exclusively by scanner/idor_detector.py
    #           (taint flow: source → sink, with auth suppression)
        # ── SSRF ──────────────────────────────────────────────────────────────────
    # High confidence: requests.get(var) where arg is a bare name (not a string)
    {"name": "requests with Variable URL",
     "pattern": re.compile(
         r'requests\s*\.\s*(?:get|post|put|patch|delete)\s*\('
         r'\s*(?!["\'])'           # arg does NOT start with a quote
         r'(?!b["\'])'             # not a bytes literal
         r'[^\)]+\)',
         _F),
     "vuln_type": "ssrf", "confidence": "High",
     "note": "requests called with non-literal URL — validate host against allow-list (SSRF risk)."},

    {"name": "urllib.request.urlopen",
     "pattern": re.compile(r"urllib\.request\.urlopen\s*\(", _F),
     "vuln_type": "ssrf", "confidence": "Medium",
     "note": "urllib.request.urlopen with potentially user-controlled URL risks SSRF."},

    {"name": "http.client Connection",
     "pattern": re.compile(r"http\.client\.HTTP(?:S?)Connection\s*\(", _F),
     "vuln_type": "ssrf", "confidence": "Medium",
     "note": "http.client connection — validate host against allow-list to prevent SSRF."},

    {"name": "JS fetch() with Variable",
     "pattern": re.compile(r'\bfetch\s*\(\s*(?!["\'])[^\)]+\)', _F),
     "vuln_type": "ssrf", "confidence": "Low",
     "note": "fetch() with variable URL — verify host is not user-controlled.",
     "languages": {"js", "ts", "jsx", "tsx"}},

    {"name": "axios with Variable URL",
     "pattern": re.compile(
         r'axios\s*\.\s*(?:get|post|put|delete)\s*\(\s*(?!["\'])[^\)]+\)', _F),
     "vuln_type": "ssrf", "confidence": "Low",
     "note": "axios request to variable URL — validate against server-side allow-list.",
     "languages": {"js", "ts", "jsx", "tsx"}},

    # ── Insecure Deserialization ───────────────────────────────────────────────
    {"name": "pickle.loads",
     "pattern": re.compile(r"\bpickle\.loads?\s*\(", _F),
     "vuln_type": "insecure_deserialization", "confidence": "High",
     "note": "pickle.load/loads executes arbitrary Python on malicious input."},

    {"name": "yaml.load without Loader",
     "pattern": re.compile(r'\byaml\.load\s*\(\s*(?!.*Loader\s*=)', _F),
     "vuln_type": "insecure_deserialization", "confidence": "High",
     "note": "yaml.load() without Loader=yaml.SafeLoader allows arbitrary code execution."},

    {"name": "marshal.loads",
     "pattern": re.compile(r"\bmarshal\.loads?\s*\(", _F),
     "vuln_type": "insecure_deserialization", "confidence": "High",
     "note": "marshal.load/loads is unsafe on untrusted data."},

    {"name": "jsonpickle.decode",
     "pattern": re.compile(r"\bjsonpickle\.decode\s*\(", _F),
     "vuln_type": "insecure_deserialization", "confidence": "High",
     "note": "jsonpickle.decode can execute arbitrary code from malicious JSON."},

    # ── Go language ──────────────────────────────────────────────────────────────
    {"name": "Go Command Injection",
     "pattern": re.compile(r'exec\.Command\s*\(', _F),
     "vuln_type": "command_injection", "confidence": "Medium",
     "note": "Go: exec.Command — verify no user-controlled arguments passed.",
     "languages": {"go"}},

    {"name": "Java ObjectInputStream",
     "pattern": re.compile(r"\bObjectInputStream\b", _F),
     "vuln_type": "insecure_deserialization", "confidence": "Medium",
     "note": "Java ObjectInputStream deserializes untrusted data.",
     "languages": {"java"}},

    {"name": "Java XStream",
     "pattern": re.compile(r"\bXStream\b.*\bfromXML\b", _F),
     "vuln_type": "insecure_deserialization", "confidence": "Medium",
     "note": "XStream.fromXML() on untrusted XML is a known RCE vector.",
     "languages": {"java"}},

    # ── Open Redirect ─────────────────────────────────────────────────────────
    {"name": "Unvalidated Redirect from Request",
     "pattern": re.compile(r"redirect\s*\(\s*request\.", _F),
     "vuln_type": "open_redirect", "confidence": "High",
     "note": "Redirect target sourced directly from request — validate against allow-list."},

    {"name": "JS window.location from Variable",
     "pattern": re.compile(r"window\.location\s*(?:\.href)?\s*=\s*(?!['\"])", _F),
     "vuln_type": "open_redirect", "confidence": "Medium",
     "note": "window.location set to variable — verify not user-controlled.",
     "languages": {"js", "ts", "jsx", "tsx"}},

    # ── Auth bypass ───────────────────────────────────────────────────────────
    {"name": "Auth from Request Parameter",
     "pattern": re.compile(
         r'request\.\w+\.\w*(?:role|admin|is_admin|privilege|permission)', _F),
     "vuln_type": "auth_bypass", "confidence": "High",
     "note": "Authorization decision based on user-supplied request parameter."},

    # ── Debug exposure ────────────────────────────────────────────────────────
    {"name": "Flask Debug Mode",
     "pattern": re.compile(r"app\.run\s*\([^)]*debug\s*=\s*True", _F),
     "vuln_type": "debug_exposure", "confidence": "High",
     "note": "Flask debug=True exposes an interactive debugger to the network."},

    {"name": "Django DEBUG=True",
     "pattern": re.compile(r"DEBUG\s*=\s*True", _F),
     "vuln_type": "debug_exposure", "confidence": "High",
     "note": "Django DEBUG=True exposes stack traces and settings."},

    {"name": "Print Sensitive Data",
     "pattern": re.compile(r"print\s*\(.*(?:password|token|secret|key|credential)", _F),
     "vuln_type": "debug_exposure", "confidence": "Low",
     "note": "Sensitive data printed to stdout."},

    # ── Sensitive logging ──────────────────────────────────────────────────────
    {"name": "Credentials in Logger",
     "pattern": re.compile(
         r"(?:logger|logging)\.\w+\s*\([^)]*"
         r"(?:password|passwd|pwd|token|secret|credential)[^)]*\)", _F),
     "vuln_type": "sensitive_logging", "confidence": "Medium",
     "note": "Credentials or secrets may appear in log output."},

    # ── CSRF hint ──────────────────────────────────────────────────────────────
    {"name": "POST Route (verify CSRF)",
     "pattern": re.compile(
         r'@app\.route\s*\([^)]+methods\s*=\s*\[.*["\']POST["\']', _F),
     "vuln_type": "debug_exposure", "confidence": "Low",
     "note": "POST route detected — ensure CSRF protection decorator is applied."},
]

# ---------------------------------------------------------------------------
# File extension configuration
# ---------------------------------------------------------------------------
SCANNABLE_EXT = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs",
    ".java", ".go", ".rb", ".php", ".cs", ".cpp", ".c", ".h",
    ".sh", ".bash", ".env", ".yml", ".yaml", ".xml", ".config",
    ".tf",
}

EXT_TO_LANG = {
    ".py": "python", ".js": "javascript", ".ts": "typescript",
    ".jsx": "javascript", ".tsx": "typescript", ".mjs": "javascript",
    ".java": "java", ".go": "go", ".rb": "ruby", ".php": "php",
    ".cs": "csharp", ".cpp": "cpp", ".c": "c", ".h": "c",
    ".sh": "shell", ".bash": "shell",
    ".tf":  "terraform",
}

EXCLUDED_DIRS = {
    ".git", ".svn", "node_modules", "__pycache__", ".tox",
    "venv", ".venv", "env", ".env", "dist", "build",
    ".cache", "vendor", "third_party", "migrations",
}

# ---------------------------------------------------------------------------
# Fallback structural detection (AST-based, low noise)
# ---------------------------------------------------------------------------

# Source names the fallback looks for in call arguments
_FALLBACK_SOURCE_NAMES = {
    "request", "args", "form", "params", "query",
    "input", "argv", "environ", "getenv",
}


def _fallback_scan(filepath: str, source: str, lang: str) -> list[dict]:
    """
    Lightweight AST-based fallback that catches patterns the taint engine
    misses (e.g. inline expressions, concatenation in call args).

    Detects:
      - subprocess.* calls with shell=True  (command_injection)
      - open() / file access calls whose arg contains a user-input name
        (path_traversal)

    Returns findings in the same format as regex/taint findings.
    Confidence is set to "Medium" since we cannot confirm full data flow.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    findings = []
    lines    = source.splitlines()

    def _snip(lineno: int) -> str:
        idx = lineno - 1
        return lines[idx].rstrip() if 0 <= idx < len(lines) else ""

    def _arg_refs_source(args: list[ast.expr]) -> bool:
        """True if any arg tree contains a name matching a known source."""
        for arg in args:
            for node in ast.walk(arg):
                if isinstance(node, ast.Name) and node.id in _FALLBACK_SOURCE_NAMES:
                    return True
                if isinstance(node, ast.Attribute):
                    try:
                        full = ast.unparse(node)
                        if any(full.startswith(s) for s in _FALLBACK_SOURCE_NAMES):
                            return True
                    except Exception:
                        pass
        return False

    def _make(vuln_type: str, lineno: int, note: str, snippet: str) -> dict:
        m = get_mapping(vuln_type)
        return {
            "title":           note,
            "vuln_type":       vuln_type,
            "severity":        m.get("severity",        "High"),
            "priority":        m.get("priority",        "P2"),
            "confidence":      "Medium",
            "language":        lang,
            "file":            filepath,
            "line":            lineno,
            "snippet":         snippet,
            "group_key":       f"{vuln_type}|{snippet.strip()}",
            "function":        "",
            "description":     note,
            "owasp":           m.get("owasp",           ""),
            "owasp_id":        m.get("owasp_id",        ""),
            "mitre":           m.get("mitre",           ""),
            "mitre_desc":      m.get("mitre_desc",      ""),
            "cwe":             m.get("cwe",             ""),
            "cwe_desc":        m.get("cwe_desc",        ""),
            "pci_dss":         m.get("pci_dss",         ""),
            "nist":            m.get("nist",            ""),
            "iso27001":        m.get("iso27001",        ""),
            "soc2":            m.get("soc2",            ""),
            "business_impact": m.get("business_impact", ""),
            "remediation":     m.get("remediation",     []),
            "exploitability":  m.get("exploitability",  "High"),
            "taint_path":      "",  # structural fallback only
            "taint_chain":     [],
            "source_expr":     "",
            "sink_call":       "",
            "detection":       "Structural Fallback (AST)",
            "cvss":            None,
            "cve":             None,
        }

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue

        try:
            func_str = ast.unparse(node.func)
        except Exception:
            continue

        all_args = list(node.args) + [kw.value for kw in node.keywords]
        lineno   = node.lineno
        snippet  = _snip(lineno)

        # ── Fallback 1: subprocess with shell=True ───────────────────────────
        is_subprocess = (func_str.startswith("subprocess.")
                         or func_str in ("subprocess.call", "subprocess.run",
                                          "subprocess.Popen"))
        if is_subprocess:
            shell_true = any(
                isinstance(kw.value, ast.Constant) and kw.value.value is True
                and kw.arg == "shell"
                for kw in node.keywords
            )
            if shell_true:
                findings.append(_make(
                    "command_injection", lineno,
                    "subprocess called with shell=True — verify no user input in command",
                    snippet,
                ))
                continue

        # ── Fallback 2: open() with source-related arg ────────────────────────
        if func_str == "open" and _arg_refs_source(all_args):
            findings.append(_make(
                "path_traversal", lineno,
                "open() called with potentially user-controlled path",
                snippet,
            ))

    return findings


# ---------------------------------------------------------------------------
# Core scan functions
# ---------------------------------------------------------------------------

def _skip(path: Path) -> bool:
    return any(p in EXCLUDED_DIRS for p in path.parts)


def _should_scan(path: Path) -> bool:
    return path.suffix.lower() in SCANNABLE_EXT and not _skip(path)


# Parameterized query signatures — these are SAFE and must not be flagged.
# Matches the second argument being a tuple/list of bind params:
#   execute("SELECT ...", (a, b))   execute("INSERT ...", [x, y])
#   execute("SELECT ...", %s)       execute("... WHERE id=?", (id,))
_PARAM_QUERY_RE = re.compile(
    r'(?:execute|executemany)\s*\('     # the call
    r'\s*["\'][^"\']*["\']'             # first arg: the query string (no concat)
    r'\s*,\s*'                          # comma separator
    r'(?:\(|\[|{|\w)',                  # second arg starts with tuple/list/dict/var
    re.IGNORECASE,
)


def _is_parameterized(snippet: str) -> bool:
    """
    Return True if the SQL execute() call uses parameterized binding.
    Safe patterns:
      execute("SELECT ... WHERE x=?", (val,))
      execute("INSERT ...", [a, b])
      execute("UPDATE ...", params)
    Unsafe patterns (return False):
      execute("SELECT ... WHERE x='" + val + "'")
      execute(f"DELETE ... WHERE id={uid}")
    """
    # If there's string concatenation (+) or f-string inside the query arg -> unsafe
    if re.search(r'["\'][^"\']*["\'\s]*\+', snippet):
        return False
    if re.search(r'\bexecute\s*\(\s*f["\']', snippet, re.IGNORECASE):
        return False
    # If it matches the safe parameterized pattern -> safe
    return bool(_PARAM_QUERY_RE.search(snippet))


def _lang_note(base_note: str, lang: str, vuln_type: str) -> str:
    """Return language-specific description for a finding (GAP 5)."""
    if vuln_type == "code_injection":
        return {
            "python": "Executes arbitrary Python code.",
            "javascript": "Executes arbitrary JavaScript code.",
            "java": "Executes arbitrary Java code.",
            "go": "Executes arbitrary Go code.",
            "ruby": "Executes arbitrary Ruby code.",
            "php": "Executes arbitrary PHP code.",
        }.get(lang, base_note)
    if vuln_type == "xss":
        return {
            "javascript": "Injects malicious script into DOM — executes in victim browser.",
            "typescript": "Injects malicious script into DOM — executes in victim browser.",
            "python": "Reflected XSS: server renders user input into HTML without escaping.",
            "java": "Reflected XSS: JSP renders user input into HTML without escaping.",
        }.get(lang, base_note)
    if vuln_type == "command_injection":
        runtime = {
            "python": "Python subprocess",
            "javascript": "Node.js child_process",
            "java": "Java Runtime.exec",
            "go": "Go exec.Command",
            "ruby": "Ruby system()",
        }.get(lang)
        if runtime:
            return f"{base_note} [Executes via {runtime}.]"
    if vuln_type == "ssrf":
        return {
            "python": f"{base_note} [Python requests — can reach AWS IMDS at 169.254.169.254.]",
            "javascript": f"{base_note} [Node.js axios/fetch — can reach internal services.]",
            "java": f"{base_note} [Java HttpURLConnection — can reach internal services.]",
        }.get(lang, base_note)
    return base_note

def _make_finding(rule: dict, filepath: str, lineno: int,
                  snippet: str, mapping: dict, lang: str) -> dict:
    vuln_type = rule["vuln_type"]
    conf      = rule.get("confidence", "Medium")
    # VAL-001 FIX: group_key uses vuln_type|snippet ONLY (no line number).
    # This ensures cmd_0.py line 4 and cmd_1.py line 2 with identical snippets
    # are treated as the same root cause and merged by the dedup engine.
    if vuln_type == "hardcoded_secret":
        group_key = vuln_type + "|" + rule["name"]  # PATCH 5
    else:
        group_key = f"{vuln_type}|{snippet.strip()}"
    return {
        "title":           rule["name"],
        "vuln_type":       vuln_type,
        "severity":        mapping.get("severity",        "Medium"),
        "priority":        mapping.get("priority",        "P3"),
        "confidence":      conf,
        "language":        lang,
        "file":            filepath,
        "line":            lineno,
        "snippet":         snippet,
        "group_key":       group_key,
        "function":        "",
        "description":     _lang_note(rule.get("note", ""), lang, rule["vuln_type"]),
        "owasp":           mapping.get("owasp",           ""),
        "owasp_id":        mapping.get("owasp_id",        ""),
        "mitre":           mapping.get("mitre",           ""),
        "mitre_desc":      mapping.get("mitre_desc",      ""),
        "cwe":             mapping.get("cwe",             ""),
        "cwe_desc":        mapping.get("cwe_desc",        ""),
        "pci_dss":         mapping.get("pci_dss",         ""),
        "nist":            mapping.get("nist",            ""),
        "iso27001":        mapping.get("iso27001",        ""),
        "soc2":            mapping.get("soc2",            ""),
        "business_impact": mapping.get("business_impact", ""),
        "remediation":     mapping.get("remediation",     []),
        "exploitability":  mapping.get("exploitability",  "Medium"),
        "taint_path":      "",   # empty for regex — real taint paths set by taint_engine only
        "detection_note":  f"{rule['name']} — {rule.get('note','')}",
        "taint_chain":     [],
        "source_expr":     "",
        "sink_call":       "",
        "detection":       "Regex Pattern",
        "cvss":            None,
        "cve":             None,
    }



# ===========================================================================
# IaC + API Security Detection
# ===========================================================================

_IAC_API_MAPPINGS = {
    "iac_public_s3": {
        "title": "Public S3 Bucket", "severity": "High", "priority": "P2",
        "cwe": "CWE-284", "cwe_desc": "Improper Access Control",
        "owasp": "A05:2021 - Security Misconfiguration", "owasp_id": "A05",
        "mitre": "T1530", "mitre_desc": "Data from Cloud Storage Object",
        "pci_dss": "Req 6.2.4 - Prevent misconfiguration",
        "nist": "AC-3 Access Enforcement",
        "iso27001": "A.9.4.1 Information Access Restriction",
        "soc2": "CC6.1 Logical and Physical Access Controls",
        "exploitability": "High",
        "business_impact": "Sensitive data publicly accessible via S3. Any internet user can read, list, or download bucket contents.",
        "remediation": ["Set bucket ACL to private.", "Enable S3 Block Public Access at account level.", "Use bucket policies to restrict access to specific IAM roles."],
    },
    "iac_open_security_group": {
        "title": "Open Security Group (0.0.0.0/0)", "severity": "High", "priority": "P2",
        "cwe": "CWE-284", "cwe_desc": "Improper Access Control",
        "owasp": "A05:2021 - Security Misconfiguration", "owasp_id": "A05",
        "mitre": "T1190", "mitre_desc": "Exploit Public-Facing Application",
        "pci_dss": "Req 1.3 - Restrict inbound and outbound traffic",
        "nist": "SC-7 Boundary Protection",
        "iso27001": "A.13.1.1 Network Controls",
        "soc2": "CC6.6 Logical Access Security Measures",
        "exploitability": "High",
        "business_impact": "Unrestricted inbound access exposes all ports to the internet, enabling direct exploitation of any running service.",
        "remediation": ["Replace 0.0.0.0/0 with specific trusted CIDR ranges.", "Apply least privilege to security group rules.", "Use separate security groups per service tier."],
    },
    "iac_privileged_container": {
        "title": "Privileged Container", "severity": "High", "priority": "P2",
        "cwe": "CWE-250", "cwe_desc": "Execution with Unnecessary Privileges",
        "owasp": "A05:2021 - Security Misconfiguration", "owasp_id": "A05",
        "mitre": "T1611", "mitre_desc": "Escape to Host",
        "pci_dss": "Req 6.2.4 - Secure system configuration",
        "nist": "CM-7 Least Functionality",
        "iso27001": "A.12.6.1 Management of Technical Vulnerabilities",
        "soc2": "CC6.6 Logical Access Security Measures",
        "exploitability": "High",
        "business_impact": "Privileged containers can escape to the host node and gain root, enabling full cluster compromise.",
        "remediation": ["Remove privileged: true from securityContext.", "Use specific capabilities instead.", "Enable PodSecurityAdmission with restricted policy."],
    },
    "api_idor": {
        "title": "Insecure Direct Object Reference (IDOR)", "severity": "High", "priority": "P2",
        "cwe": "CWE-639", "cwe_desc": "Authorization Bypass Through User-Controlled Key",
        "owasp": "A01:2021 - Broken Access Control", "owasp_id": "A01",
        "mitre": "T1190", "mitre_desc": "Exploit Public-Facing Application",
        "pci_dss": "Req 7.1 - Limit access to system components",
        "nist": "AC-3 Access Enforcement",
        "iso27001": "A.9.4.1 Information Access Restriction",
        "soc2": "CC6.3 Access to Information Assets",
        "exploitability": "High",
        "business_impact": "Attacker accesses any user's data by changing a predictable ID in the URL. Sequential enumeration exposes all records.",
        "remediation": ["Implement server-side authorization on every object access.", "Use UUIDs instead of sequential IDs.", "Verify authenticated user owns the requested resource."],
    },
    "api_jwt_bypass": {
        "title": "Authentication Bypass via JWT Misconfiguration", "severity": "Critical", "priority": "P1",
        "cwe": "CWE-347", "cwe_desc": "Improper Verification of Cryptographic Signature",
        "owasp": "A07:2021 - Identification and Authentication Failures", "owasp_id": "A07",
        "mitre": "T1552", "mitre_desc": "Unsecured Credentials",
        "pci_dss": "Req 8.3 - Secure all user authentication",
        "nist": "IA-5 Authenticator Management",
        "iso27001": "A.9.4.2 Secure Log-on Procedures",
        "soc2": "CC6.1 Logical Access Controls",
        "exploitability": "High",
        "business_impact": "JWT signature verification disabled. Attacker crafts arbitrary tokens claiming any identity or role without the signing secret.",
        "remediation": ["Never set verify_signature=False in production.", "Always verify JWT algorithm matches expected.", "Reject tokens with alg=none."],
    },
}


def _iac_api_finding(vuln_type, filepath, lineno, snippet, lang):
    m = _IAC_API_MAPPINGS.get(vuln_type, {})
    return {
        "title":           m.get("title", vuln_type),
        "vuln_type":       vuln_type,
        "severity":        m.get("severity",        "High"),
        "priority":        m.get("priority",        "P2"),
        "confidence":      "High",
        "language":        lang,
        "file":            filepath,
        "line":            lineno,
        "snippet":         snippet,
        "group_key":       f"{vuln_type}|{snippet.strip()}",
        "function":        "",
        "description":     m.get("business_impact", ""),
        "owasp":           m.get("owasp",           ""),
        "owasp_id":        m.get("owasp_id",        ""),
        "mitre":           m.get("mitre",           ""),
        "mitre_desc":      m.get("mitre_desc",      ""),
        "cwe":             m.get("cwe",             ""),
        "cwe_desc":        m.get("cwe_desc",        ""),
        "pci_dss":         m.get("pci_dss",         ""),
        "nist":            m.get("nist",            ""),
        "iso27001":        m.get("iso27001",        ""),
        "soc2":            m.get("soc2",            ""),
        "business_impact": m.get("business_impact", ""),
        "remediation":     m.get("remediation",     []),
        "exploitability":  m.get("exploitability",  "High"),
        "taint_path":      "",
        "taint_chain":     [],
        "source_expr":     "",
        "sink_call":       "",
        "detection":       "Regex + Contextual Analysis",
        "cvss":            None,
        "cve":             None,
    }


# Terraform rules
_TF_RULES = [
    (re.compile(r'acl\s*=\s*"public-read', re.IGNORECASE),
     "iac_public_s3"),
    (re.compile(r'cidr_blocks\s*=\s*\["0\.0\.0\.0/0"', re.IGNORECASE),
     "iac_open_security_group"),
]

# Kubernetes YAML rules
_K8S_RULES = [
    (re.compile(r'privileged\s*:\s*true', re.IGNORECASE),
     "iac_privileged_container"),
]

# JWT bypass
_JWT_BYPASS_RE = re.compile(
    r'jwt\.decode\s*\(.*verify_signature.*False',
    re.IGNORECASE | re.DOTALL,
)

def _scan_iac(filepath, source, lang):
    findings = []
    lines    = source.splitlines()
    rules    = _TF_RULES if lang == "terraform" else _K8S_RULES
    for pattern, vuln_type in rules:
        for match in pattern.finditer(source):
            lineno  = source[:match.start()].count("\n") + 1
            snippet = lines[lineno - 1].strip() if lineno <= len(lines) else ""
            if snippet.lstrip().startswith(("#",)):
                continue
            findings.append(_iac_api_finding(vuln_type, filepath, lineno, snippet, lang))
    return findings


def _scan_api(filepath, source, lang):
    if lang != "python":
        return []
    findings = []
    lines    = source.splitlines()

    # JWT bypass
    for match in _JWT_BYPASS_RE.finditer(source):
        lineno  = source[:match.start()].count("\n") + 1
        snippet = lines[lineno - 1].strip() if lineno <= len(lines) else ""
        if not snippet.lstrip().startswith(("#",)):
            findings.append(_iac_api_finding("api_jwt_bypass", filepath, lineno, snippet, lang))

    return findings


def _build_string_literal_ranges(source: str) -> list[tuple[int, int]]:
    """
    Return list of (start, end) byte offsets that are inside string literals.
    Used to reject regex matches that land inside a quoted string — e.g.
        code = "subprocess.run(cmd, shell=True)"   ← false positive
        subprocess.run(cmd, shell=True)             ← real finding
    Uses a lightweight state machine so it works without a full parse.
    """
    ranges: list[tuple[int, int]] = []
    i = 0
    n = len(source)
    while i < n:
        c = source[i]
        # Triple-quoted strings
        for q in ('"""', "'''"):
            if source[i:i+3] == q:
                end = source.find(q, i + 3)
                if end == -1:
                    end = n
                else:
                    end += 3
                ranges.append((i, end))
                i = end
                break
        else:
            # Single-quoted strings
            if c in ('"', "'"):
                q = c
                j = i + 1
                while j < n:
                    if source[j] == '\\':
                        j += 2
                        continue
                    if source[j] == q:
                        ranges.append((i, j + 1))
                        i = j + 1
                        break
                    j += 1
                else:
                    i = n
            elif c == '#':
                # Skip to end of line (comment)
                end = source.find('\n', i)
                i = end + 1 if end != -1 else n
            else:
                i += 1
    return ranges


def _in_string_literal(offset: int, ranges: list[tuple[int, int]]) -> bool:
    """Return True if byte offset falls inside a known string literal range."""
    for start, end in ranges:
        if start < offset < end:
            return True
        if start > offset:
            break
    return False


# Known safe package names and their common typosquats (Issue 9)
_TYPOSQUATS: list[tuple[str, str]] = [
    ("reqests",   "requests"),   ("requets",  "requests"),
    ("reqeusts",  "requests"),   ("requsets", "requests"),
    ("urllib2",   "urllib"),
    ("djano",     "django"),     ("dajngo",   "django"),
    ("falsk",     "flask"),      ("flaask",   "flask"),
    ("numpyy",    "numpy"),      ("nunpy",    "numpy"),
    ("panads",    "pandas"),     ("pands",    "pandas"),
    ("paramikoo", "paramiko"),
    ("pyyamll",   "pyyaml"),
    ("cryptograhy","cryptography"),
    ("pillow2",   "pillow"),
    ("boto",      "boto3"),
    ("setup-tools","setuptools"),
]
_TYPOSQUAT_RE = re.compile(
    r'^(?:import|from)\s+(' +
    '|'.join(re.escape(t) for t, _ in _TYPOSQUATS) +
    r')(?=\s|$|[^a-zA-Z0-9_])',
    re.IGNORECASE | re.MULTILINE,
)


def _scan_typosquats(filepath: str, source: str, lang: str) -> list[dict]:
    """Detect probable typosquatted package imports (Issue 9)."""
    if lang not in ("python", "javascript", "unknown"):
        return []
    findings = []
    lines = source.splitlines()
    typo_map = {t: legit for t, legit in _TYPOSQUATS}
    for match in _TYPOSQUAT_RE.finditer(source):
        typo  = match.group(1).lower()
        legit = typo_map.get(typo, "")
        lineno  = source[:match.start()].count("\n") + 1
        snippet = lines[lineno - 1].strip() if lineno <= len(lines) else ""
        findings.append({
            "title":           f"Potential Typosquatting: '{typo}' (did you mean '{legit}'?)",
            "vuln_type":       "supply_chain_typosquat",
            "severity":        "High",
            "priority":        "P2",
            "confidence":      "Medium",
            "language":        lang,
            "file":            filepath,
            "line":            lineno,
            "snippet":         snippet,
            "group_key":       f"supply_chain_typosquat|{typo}",
            "function":        "",
            "description":     f"Package name '{typo}' closely resembles '{legit}'. Typosquatted packages execute malicious code on install.",
            "owasp":           "A06:2021 - Vulnerable and Outdated Components",
            "owasp_id":        "A06",
            "mitre":           "T1195",
            "mitre_desc":      "Supply Chain Compromise",
            "cwe":             "CWE-1357",
            "cwe_desc":        "Reliance on Insufficiently Trustworthy Component",
            "pci_dss":         "Req 6.3.3 - All software protected from known vulnerabilities",
            "nist":            "SA-12 Supply Chain Protection",
            "iso27001":        "A.15.1.1 Information Security Policy for Supplier Relationships",
            "soc2":            "CC7.1 Vulnerability Management",
            "business_impact": f"Typosquatted package '{typo}' may execute malicious code during pip/npm install, stealing credentials or establishing backdoors.",
            "remediation":     [f"Replace import of '{typo}' with '{legit}'.", "Audit all dependencies in requirements.txt/package.json.", "Use a private package mirror with allow-listing.", "Enable pip hash-checking mode."],
            "exploitability":  "High",
            "taint_path":      "",
            "taint_chain":     [],
            "source_expr":     "",
            "sink_call":       "",
            "detection":       "Regex + Contextual Analysis",
            "cvss":            None,
            "cve":             None,
        })
    return findings


def scan_file(filepath: str) -> list[dict]:
    """Regex rules + structural fallback on a single file."""
    path = Path(filepath)
    ext  = path.suffix.lower().lstrip(".")
    lang = EXT_TO_LANG.get(path.suffix.lower(), "unknown")

    try:
        source = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    lines    = source.splitlines()
    findings = []

    # Pre-compute string literal ranges once for the whole file (VAL-006 fix).
    # Any regex match whose start offset falls inside a string literal is a
    # false positive (the pattern is in annotation/test data, not live code).
    str_ranges = _build_string_literal_ranges(source) if path.suffix.lower() == ".py" else []

    # ── Regex rules ──────────────────────────────────────────────────────────
    for rule in REGEX_RULES:
        rule_langs = rule.get("languages")
        if rule_langs and ext not in rule_langs:
            continue

        mapping = get_mapping(rule["vuln_type"])
        for match in rule["pattern"].finditer(source):
            lineno  = source[: match.start()].count("\n") + 1
            snippet = lines[lineno - 1].strip() if lineno <= len(lines) else ""

            # Skip commented-out lines
            if snippet.lstrip().startswith(("#", "//", "*", "'")):
                continue

            # VAL-006: skip matches inside string literals (e.g. benchmark annotations)
            if str_ranges and _in_string_literal(match.start(), str_ranges):
                continue

            # ── False positive filter: parameterized SQL queries ─────────────
            # execute("SELECT ...", (params,)) is safe — skip it
            if rule.get("check_parameterized") and _is_parameterized(snippet):
                continue

            # ── Confidence refinement ─────────────────────────────────────────
            # Upgrade confidence when the pattern is unambiguously dangerous:
            #   - SQL with string concatenation operator present on same line
            #   - SSRF with bare variable name (single word, no quotes)
            conf = rule.get("confidence", "Medium")
            vuln = rule["vuln_type"]

            if vuln == "sql_injection":
                # Downgrade if query looks benign (no concat / f-string on line)
                if "+" not in snippet and not snippet.strip().startswith("f"):
                    conf = "Medium"

            elif vuln == "ssrf":
                # Upgrade to High if arg is a bare identifier (e.g. requests.get(url))
                bare_var = re.search(
                    r'(?:get|post|put|patch|delete)\s*\(\s*([A-Za-z_]\w*)\s*[\),]',
                    snippet,
                )
                if bare_var:
                    conf = "High"
                # Downgrade to Low if URL contains a dot (likely a hardcoded domain)
                elif re.search(r'(?:get|post|put|patch|delete)\s*\(\s*["\']', snippet):
                    continue  # hardcoded string URL — skip entirely

            elif vuln == "xss" and "innerHTML" in snippet:
                # Upgrade if RHS is a bare variable or function call result
                rhs_match = re.search(r'innerHTML\s*\+?=\s*(.+)', snippet)
                if rhs_match:
                    rhs = rhs_match.group(1).strip().rstrip(";")
                    if rhs.startswith(("'", '"', '`')):
                        continue   # static string — safe, skip
                    conf = "High" if re.match(r'^[A-Za-z_]\w*(\.\w+|\[.+\])?$', rhs) else "Medium"

            finding = _make_finding(rule, filepath, lineno, snippet, mapping, lang)
            finding["confidence"] = conf  # apply refined confidence

            # Safeguard: if any critical metadata field is empty, re-pull from mapper.
            # Prevents stale cached mapping from producing empty-field findings.
            if not finding.get("cwe") or not finding.get("owasp"):
                fresh = get_mapping(finding["vuln_type"])
                for field in ("cwe","owasp","owasp_id","mitre","mitre_desc",
                              "pci_dss","nist","iso27001","soc2",
                              "business_impact","remediation","severity"):
                    if not finding.get(field) and fresh.get(field):
                        finding[field] = fresh[field]

            findings.append(finding)

    # ── Structural fallback (Python only — AST required) ─────────────────────
    if path.suffix.lower() == ".py":
        findings += _fallback_scan(filepath, source, lang)

    # ── IaC security (Terraform + Kubernetes YAML) ────────────────────────────
    if lang == "terraform":
        findings += _scan_iac(filepath, source, lang)
    elif lang in ("unknown",) and path.suffix.lower() in (".yml", ".yaml"):
        findings += _scan_iac(filepath, source, "yaml")

    # ── API security (JWT bypass — Python only) ─────────────────────────────
    if lang == "python":
        findings += _scan_api(filepath, source, lang)

    # ── IDOR: behaviour-based taint detection for all supported languages ─────
    if lang in ("python", "javascript", "go", "java"):
        from scanner.idor_detector import analyse_file as _idor_analyse
        findings += _idor_analyse(filepath)

    # ── Supply chain typosquatting (Issue 9) ──────────────────────────────────
    if lang in ("python", "javascript", "unknown"):
        findings += _scan_typosquats(filepath, source, lang)

    return findings


def scan_directory(target_path: str, workers: int = 2) -> list[dict]:
    """
    Recursively scan a directory.
    Combines: regex rules + structural fallback + AST taint analysis.

    Debug visibility (requirement):
      Prints file count and raw finding count to stderr before returning.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from scanner.taint_engine import analyze_file as taint_analyze

    target    = Path(target_path)
    all_files = [f for f in target.rglob("*") if f.is_file() and _should_scan(f)]

    all_findings: list[dict] = []

    def _scan(fp: Path) -> list[dict]:
        results = scan_file(str(fp))           # regex + fallback
        if fp.suffix.lower() == ".py":
            results += taint_analyze(str(fp))  # AST taint (primary)
        return results

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_scan, fp): fp for fp in all_files}
        for future in as_completed(futures):
            try:
                all_findings.extend(future.result())
            except Exception:
                pass

    # ── Debug visibility (prints to stderr so it doesn't pollute JSON output)
    print(
        f"[SCAN] Files scanned: {len(all_files)} | "
        f"Raw findings (before dedup): {len(all_findings)}",
        file=sys.stderr,
    )

    return all_findings
