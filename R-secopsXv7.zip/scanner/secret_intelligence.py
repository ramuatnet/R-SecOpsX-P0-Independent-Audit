"""
scanner/secret_intelligence.py
Enterprise secret intelligence scanner/enricher.

Compatibility APIs preserved:
- scan_secret_intelligence(target_path)
- analyze_secret_intelligence(target_path)
- classify_secrets(findings)
- enrich_secret_intelligence(findings)
- summarize_secret_intelligence(findings)
- secret_intelligence_summary(findings)

Important fix:
- enrich_secret_intelligence() must never stamp non-secret SAST/taint/framework/API findings
  as scanner.secret_intelligence. Older patches caused every finding in clean_report.json to show
  engine=scanner.secret_intelligence. This version only enriches true secret findings.
"""
from __future__ import annotations

import re
from pathlib import Path
from collections import Counter

_F = re.IGNORECASE | re.MULTILINE

SECRET_EXT = {
    ".py", ".js", ".ts", ".java", ".cs", ".go", ".php",
    ".env", ".properties", ".yml", ".yaml", ".json", ".xml", ".config"
}
EXCLUDED = {".git", "node_modules", "venv", ".venv", "__pycache__", "dist", "build", "vendor"}

SECRET_RULES = [
    ("SPRING_DATASOURCE_PASSWORD", "Spring datasource credential", "spring_config_secret", r"spring\.datasource\.(?:password|username|url)\s*[:=]\s*[^\s#]+", "High", "CWE-798"),
    ("SPRING_SECURITY_OAUTH_SECRET", "Spring OAuth client secret", "oauth_client_secret", r"spring\.security\.oauth2\.client\.registration\.[\w.-]+\.client-secret\s*[:=]\s*[^\s#]+", "Critical", "CWE-798"),
    ("JWT_SIGNING_SECRET", "JWT signing secret", "jwt_secret", r"(?:jwt|token|signing)[_-]?(?:secret|key)\s*[:=]\s*[\"']?[^\"'\s#]{8,}", "Critical", "CWE-798"),
    ("OAUTH_CLIENT_SECRET", "OAuth client secret", "oauth_client_secret", r"(?:client[_-]?secret|oauth[_-]?secret)\s*[:=]\s*[\"']?[^\"'\s#]{8,}", "Critical", "CWE-798"),
    ("AWS_SECRET_KEY", "AWS secret access key", "cloud_secret", r"(?:aws_secret_access_key|AWS_SECRET_ACCESS_KEY)\s*[:=]\s*[\"']?[A-Za-z0-9/+=]{20,}", "Critical", "CWE-798"),
    ("KAFKA_CREDENTIALS", "Kafka credential in config", "messaging_secret", r"(?:sasl\.jaas\.config|sasl\.password|KAFKA_PASSWORD|kafka\.password)\s*[:=]\s*[^\s#]+", "High", "CWE-798"),
    ("RABBITMQ_CREDENTIALS", "RabbitMQ credential / AMQP URI", "messaging_secret", r"amqps?://[^:\s'\"]+:[^@\s'\"]+@", "High", "CWE-798"),
    ("DATABASE_URL_CREDENTIALS", "Database connection string credentials", "database_connection_secret", r"(?:postgres(?:ql)?|mysql|mongodb|redis|sqlserver)://[^:\s'\"]+:[^@\s'\"]+@[^\s'\"]+", "Critical", "CWE-798"),
    ("JDBC_URL_CREDENTIALS", "JDBC connection string credentials", "database_connection_secret", r"jdbc:[^\s'\"]+(?:user|username)=([^;&\s]+).*?(?:password|pwd)=([^;&\s]+)", "Critical", "CWE-798"),
    ("CLOUD_METADATA_TOKEN_USE", "Cloud metadata credential access", "cloud_metadata_credential", r"169\.254\.169\.254|metadata\.google\.internal|/latest/meta-data/", "High", "CWE-918"),
]

DECOY_WORDS = re.compile(r"(?:example|sample|dummy|changeme|fake|test|placeholder|corpus|invalid)", re.I)
SECRET_WORDS = re.compile(r"secret|credential|password|passwd|pwd|token|api[_-]?key|private[_-]?key|client[_-]?secret|connection[_-]?string", re.I)
SECRET_VULN_TYPES = {
    "hardcoded_secret", "secret_exposure", "jwt_secret", "connection_string",
    "oauth_client_secret", "database_connection_string", "kafka_credential",
    "rabbitmq_credential", "spring_config_secret", "cloud_secret", "messaging_secret",
    "database_connection_secret", "cloud_metadata_credential",
}


def _priority(sev: str) -> str:
    return {"Critical": "P1", "High": "P2", "Medium": "P3", "Low": "P4"}.get(sev, "P3")


def _language(path: Path) -> str:
    return {
        ".properties": "properties", ".yml": "yaml", ".yaml": "yaml", ".json": "json",
        ".java": "java", ".cs": "csharp", ".js": "javascript", ".ts": "typescript",
        ".go": "go", ".php": "php", ".py": "python",
    }.get(path.suffix.lower(), "unknown")


def _skip(path: Path) -> bool:
    return any(part in EXCLUDED for part in path.parts)


def _is_secret_finding(f: dict) -> bool:
    vt = str(f.get("vuln_type", "")).lower()
    title = str(f.get("title", ""))
    snippet = str(f.get("snippet", ""))
    rule_id = str(f.get("rule_id", ""))
    if vt in SECRET_VULN_TYPES:
        return True
    return bool(SECRET_WORDS.search(title) or SECRET_WORDS.search(rule_id) or SECRET_WORDS.search(snippet))


def _build_finding(rule_id, title, vuln, sev, cwe, file, line, snippet, lang):
    confidence = "Medium" if DECOY_WORDS.search(snippet) else "High"
    severity = "Medium" if confidence == "Medium" and sev == "Critical" else sev
    return {
        "rule_id": rule_id,
        "title": title,
        "vuln_type": vuln,
        "severity": severity,
        "priority": _priority(severity),
        "confidence": confidence,
        "language": lang,
        "file": str(file),
        "line": line,
        "snippet": snippet.strip(),
        "description": f"Potential {title.lower()} detected in source/configuration.",
        "business_impact": "Exposed credentials can enable unauthorized access, lateral movement, data theft, and cloud/service account compromise.",
        "remediation": [
            "Remove the secret from source/configuration files.",
            "Move it to a managed secret store.",
            "Rotate the credential immediately.",
            "Audit VCS history for exposure.",
        ],
        "owasp": "A07:2021 - Identification and Authentication Failures",
        "cwe": cwe,
        "pci_dss": "Req 3 / Req 8 - Protect authentication secrets",
        "nist": "IA-5 / SC-12 / SC-28",
        "nist_800_53": "IA-5 / SC-12 / SC-28",
        "iso27001": "A.5.17 / A.8.24",
        "iso_27001": "A.5.17 / A.8.24",
        "soc2": "CC6.1 / CC6.6",
        "evidence": f"{file}:{line}: {snippet.strip()}",
        "detection": "Enterprise Secret Intelligence",
        "engine": "scanner.secret_intelligence",
        "secret_type": vuln,
        "validated_live": False,
        "offline_only": True,
        "enterprise_control": True,
        "group_key": f"{rule_id}|{file}|{line}",
    }


def scan_file(filepath: str) -> list[dict]:
    path = Path(filepath)
    if _skip(path):
        return []
    if path.suffix.lower() not in SECRET_EXT and path.name not in {".env", "application.properties", "application.yml", "application.yaml"}:
        return []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    findings = []
    lines = text.splitlines()
    lang = _language(path)
    for rule_id, title, vuln, pattern, sev, cwe in SECRET_RULES:
        for match in re.compile(pattern, _F).finditer(text):
            line = text[:match.start()].count("\n") + 1
            snippet = lines[line - 1] if line <= len(lines) else match.group(0)
            if snippet.strip().startswith(("#", "//", "*")):
                continue
            findings.append(_build_finding(rule_id, title, vuln, sev, cwe, path, line, snippet, lang))
            break
    return findings


def scan_secret_intelligence(target_path: str) -> dict:
    target = Path(target_path)
    files = [target] if target.is_file() else [p for p in target.rglob("*") if p.is_file()]
    findings = []
    for path in files:
        findings.extend(scan_file(str(path)))
    return {"secret_intelligence_findings": findings, "secret_intelligence_summary": summarize_secret_intelligence(findings)}


def analyze_secret_intelligence(target_path: str) -> dict:
    return scan_secret_intelligence(target_path)


def classify_secrets(findings: list[dict]) -> list[dict]:
    """Classify true secret findings only; never overwrite engine on non-secret findings."""
    for finding in findings or []:
        if not _is_secret_finding(finding):
            continue
        title = str(finding.get("title", "")).lower()
        snippet = str(finding.get("snippet", "")).lower()
        if "jwt" in title or "jwt" in snippet:
            finding.setdefault("secret_type", "jwt_secret")
        elif "oauth" in title or "client_secret" in snippet:
            finding.setdefault("secret_type", "oauth_client_secret")
        elif "kafka" in title or "rabbit" in title or "amqp" in snippet:
            finding.setdefault("secret_type", "messaging_secret")
        elif "jdbc" in snippet or "://" in snippet:
            finding.setdefault("secret_type", "database_connection_secret")
        else:
            finding.setdefault("secret_type", "generic_secret")
        finding.setdefault("engine", "scanner.secret_intelligence")
        finding.setdefault("detection", "Enterprise Secret Intelligence")
    return findings


def enrich_secret_intelligence(findings: list[dict]) -> list[dict]:
    return classify_secrets(findings)


def summarize_secret_intelligence(findings: list[dict]) -> dict:
    secrets = [f for f in findings or [] if _is_secret_finding(f)]
    return {
        "total_secrets_classified": len(secrets),
        "by_secret_type": dict(Counter(f.get("secret_type", "unknown") for f in secrets)),
        "by_severity": dict(Counter(f.get("severity", "Unknown") for f in secrets)),
        "offline_only_not_validated": True,
    }


def secret_intelligence_summary(findings: list[dict]) -> dict:
    secrets = [f for f in findings or [] if _is_secret_finding(f)]
    critical = sum(1 for f in secrets if str(f.get("severity", "")).lower() == "critical")
    high = sum(1 for f in secrets if str(f.get("severity", "")).lower() == "high")
    return {
        "total_secrets": len(secrets),
        "critical_blast_radius": critical,
        "high_blast_radius": high,
        "validation_status": "OFFLINE_ONLY_NOT_VALIDATED",
        "summary_status": "SECRET_INTELLIGENCE_SUMMARY_AVAILABLE",
        "by_secret_type": dict(Counter(f.get("secret_type", "unknown") for f in secrets)),
        "by_severity": dict(Counter(f.get("severity", "Unknown") for f in secrets)),
    }

def apply_optional_live_secret_validation(
    findings,
    enabled=False,
    timeout=6,
    max_validations=50,
):
    """
    Optional V4 live secret validation wrapper.

    V3 behavior is preserved because this function returns an offline summary
    unless enabled=True. Any validator failure is converted to a summary object
    instead of breaking the scan.
    """
    try:
        from analysis.secret_live_validation_engine import (
            enrich_findings_with_live_secret_validation,
        )

        return enrich_findings_with_live_secret_validation(
            findings=findings or [],
            enabled=enabled,
            timeout=timeout,
            max_validations=max_validations,
        )

    except Exception as exc:
        return {
            "enabled": bool(enabled),
            "mode": "LIVE_NETWORK_VALIDATION" if enabled else "OFFLINE_ONLY_NOT_VALIDATED",
            "total_secret_findings": len(findings or []),
            "validated": 0,
            "live_valid": 0,
            "not_valid_or_revoked": 0,
            "inconclusive": 0,
            "unsupported": 0,
            "errors": 1,
            "max_validations": max_validations,
            "timeout_seconds": timeout,
            "status": "SECRET_LIVE_VALIDATION_ENGINE_ERROR",
            "error_type": type(exc).__name__,
        }

if __name__ == "__main__":
    import json, sys
    print(json.dumps(scan_secret_intelligence(sys.argv[1] if len(sys.argv) > 1 else "."), indent=2))
