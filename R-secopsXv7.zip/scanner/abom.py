from __future__ import annotations

import re
from pathlib import Path


SCANNABLE_EXT = {
    ".py", ".js", ".ts", ".jsx", ".tsx",
    ".java", ".go", ".rb"
}


ABOM_RULES = [
    {
        "framework": "LangChain",
        "component": "Agent Executor",
        "patterns": [
            r"\bAgentExecutor\b",
            r"\binitialize_agent\b",
            r"\bcreate_openai_functions_agent\b",
            r"\bcreate_react_agent\b",
        ],
        "category": "Agent Framework",
        "risk": "HIGH",
    },
    {
        "framework": "LangChain",
        "component": "Tool",
        "patterns": [
            r"\bTool\s*\(",
            r"\bDynamicTool\s*\(",
            r"\bStructuredTool\s*\(",
        ],
        "category": "Tool Execution",
        "risk": "HIGH",
    },
    {
        "framework": "CrewAI",
        "component": "Agent",
        "patterns": [
            r"\bAgent\s*\(",
        ],
        "category": "Agent Framework",
        "risk": "HIGH",
    },
    {
        "framework": "CrewAI",
        "component": "Crew",
        "patterns": [
            r"\bCrew\s*\(",
        ],
        "category": "Agent Orchestration",
        "risk": "HIGH",
    },
    {
        "framework": "CrewAI",
        "component": "Task",
        "patterns": [
            r"\bTask\s*\(",
        ],
        "category": "Agent Tasking",
        "risk": "MEDIUM",
    },
    {
        "framework": "AutoGen",
        "component": "Assistant Agent",
        "patterns": [
            r"\bAssistantAgent\s*\(",
        ],
        "category": "Agent Framework",
        "risk": "HIGH",
    },
    {
        "framework": "AutoGen",
        "component": "User Proxy Agent",
        "patterns": [
            r"\bUserProxyAgent\s*\(",
        ],
        "category": "Agent Framework",
        "risk": "HIGH",
    },
    {
        "framework": "LlamaIndex",
        "component": "Query Engine",
        "patterns": [
            r"\bas_query_engine\s*\(",
            r"\bVectorStoreIndex\b",
            r"\bGPTVectorStoreIndex\b",
        ],
        "category": "Retrieval Agent",
        "risk": "HIGH",
    },
]


TOOL_HINTS = [
    "shell",
    "filesystem",
    "file",
    "command",
    "terminal",
    "exec",
    "browser",
    "http",
    "request",
    "api",
    "database",
    "sql",
]


MEMORY_HINTS = [
    "memory",
    "conversationbuffer",
    "chatmemory",
    "vectorstore",
]


HUMAN_APPROVAL_HINTS = [
    "human",
    "approval",
    "review",
    "confirm",
    "authorize",
]


def _should_scan(path: Path) -> bool:
    return path.is_file() and path.suffix.lower() in SCANNABLE_EXT


def _line_for_offset(source: str, offset: int) -> int:
    return source[:offset].count("\n") + 1


def _nearby_window(lines, line_no):
    start = max(0, line_no - 8)
    end = min(len(lines), line_no + 8)
    return "\n".join(lines[start:end]).lower()


def _tool_hints(window):
    found = []

    for hint in TOOL_HINTS:
        if hint in window:
            found.append(hint)

    return sorted(set(found))


def _memory_hints(window):
    found = []

    for hint in MEMORY_HINTS:
        if hint in window:
            found.append(hint)

    return sorted(set(found))


def _human_approval(window):
    for hint in HUMAN_APPROVAL_HINTS:
        if hint in window:
            return True

    return False


def _make_item(
    rule,
    filepath,
    line,
    evidence,
    tools,
    memory,
    human_approval
):
    return {
        "bom_type": "ABOM",
        "framework": rule["framework"],
        "component": rule["component"],
        "category": rule["category"],
        "file": filepath,
        "line": line,
        "evidence": evidence.strip(),
        "tools_detected": tools,
        "memory_detected": memory,
        "human_approval_detected": human_approval,
        "risk": rule["risk"],
        "recommendation":
            "Review agent permissions, tool execution boundaries, memory usage, and human approval controls."
    }


def scan_file(filepath):
    path = Path(filepath)

    if not _should_scan(path):
        return []

    try:
        source = path.read_text(
            encoding="utf-8",
            errors="replace"
        )
    except Exception:
        return []

    lines = source.splitlines()

    findings = []

    for rule in ABOM_RULES:

        for pattern in rule["patterns"]:

            regex = re.compile(
                pattern,
                re.IGNORECASE | re.MULTILINE
            )

            for match in regex.finditer(source):

                line_no = _line_for_offset(
                    source,
                    match.start()
                )

                evidence = (
                    lines[line_no - 1]
                    if line_no - 1 < len(lines)
                    else ""
                )

                window = _nearby_window(
                    lines,
                    line_no
                )

                findings.append(
                    _make_item(
                        rule,
                        str(path),
                        line_no,
                        evidence,
                        _tool_hints(window),
                        _memory_hints(window),
                        _human_approval(window)
                    )
                )

    return deduplicate(findings)


def deduplicate(items):

    seen = set()
    final = []

    for item in items:

        key = (
            item["framework"],
            item["component"],
            item["file"],
            item["line"]
        )

        if key in seen:
            continue

        seen.add(key)
        final.append(item)

    return final


def generate_abom(target_path):

    target = Path(target_path)

    results = []

    if target.is_file():
        return scan_file(str(target))

    if not target.exists():
        return []

    for path in target.rglob("*"):

        if _should_scan(path):

            results.extend(
                scan_file(str(path))
            )

    return deduplicate(results)


if __name__ == "__main__":

    import argparse
    import json

    parser = argparse.ArgumentParser()

    parser.add_argument("target")

    parser.add_argument(
        "--output",
        default="abom.json"
    )

    args = parser.parse_args()

    abom = generate_abom(args.target)

    with open(
        args.output,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            abom,
            f,
            indent=2
        )

    print(
        f"[ABOM] Items found: {len(abom)}"
    )

    print(
        f"[ABOM] Output written: {args.output}"
    )