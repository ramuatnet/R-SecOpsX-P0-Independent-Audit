from __future__ import annotations

from collections import Counter


# Offline CISA KEV-style seed map.
# Expand over time from official KEV catalog.
KNOWN_EXPLOITED_CVES = {
    "CVE-2021-44228": {
        "vendor": "Apache",
        "product": "Log4j",
        "name": "Apache Log4j Remote Code Execution",
        "kev_added_date": "2021-12-10",
        "due_date": "2021-12-24",
        "ransomware_use": "Known",
    },
    "CVE-2021-45046": {
        "vendor": "Apache",
        "product": "Log4j",
        "name": "Apache Log4j Code Execution",
        "kev_added_date": "2021-12-10",
        "due_date": "2021-12-24",
        "ransomware_use": "Known",
    },
    "CVE-2022-22965": {
        "vendor": "Spring",
        "product": "Spring Framework",
        "name": "Spring Framework Remote Code Execution",
        "kev_added_date": "2022-04-04",
        "due_date": "2022-04-25",
        "ransomware_use": "Unknown",
    },
    "CVE-2017-5638": {
        "vendor": "Apache",
        "product": "Struts",
        "name": "Apache Struts Remote Code Execution",
        "kev_added_date": "2021-11-03",
        "due_date": "2022-05-03",
        "ransomware_use": "Known",
    },
    "CVE-2018-11776": {
        "vendor": "Apache",
        "product": "Struts",
        "name": "Apache Struts Remote Code Execution",
        "kev_added_date": "2021-11-03",
        "due_date": "2022-05-03",
        "ransomware_use": "Known",
    },
    "CVE-2023-34362": {
        "vendor": "Progress",
        "product": "MOVEit Transfer",
        "name": "MOVEit Transfer SQL Injection",
        "kev_added_date": "2023-06-02",
        "due_date": "2023-06-23",
        "ransomware_use": "Known",
    },
    "CVE-2023-3519": {
        "vendor": "Citrix",
        "product": "ADC/Gateway",
        "name": "Citrix ADC Remote Code Execution",
        "kev_added_date": "2023-07-19",
        "due_date": "2023-08-09",
        "ransomware_use": "Known",
    },
    "CVE-2024-3400": {
        "vendor": "Palo Alto Networks",
        "product": "PAN-OS",
        "name": "PAN-OS Command Injection",
        "kev_added_date": "2024-04-12",
        "due_date": "2024-04-19",
        "ransomware_use": "Unknown",
    },
    "CVE-2024-3094": {
        "vendor": "XZ Utils",
        "product": "XZ Utils",
        "name": "XZ Utils Backdoor",
        "kev_added_date": "2024-04-01",
        "due_date": "2024-04-22",
        "ransomware_use": "Unknown",
    },
}


# Deterministic fallback aliases for local corpora / advisory-only feeds.
# Keep this conservative; do not invent aliases.
GHSA_TO_CVE_ALIAS = {
    # Log4Shell GHSA commonly seen in Maven/GitHub advisory data.
    "GHSA-jfh8-c2jp-5v3q": "CVE-2021-44228",
    "GHSA-3pxv-7cmr-fjr4": "CVE-2021-44228",

    # Spring4Shell advisory aliases commonly observed.
    "GHSA-36p3-wjmg-h94x": "CVE-2022-22965",
    "GHSA-2rmj-mq67-h97g": "CVE-2022-22965",
}


def _candidate_ids(pkg: dict) -> list[str]:
    values = []

    for key in (
        "cve",
        "primary_vulnerability_id",
        "source_vulnerability_id",
        "advisory_id",
        "vulnerability_id",
        "id",
    ):
        value = pkg.get(key)
        if value:
            values.append(str(value).strip())

    for vuln in pkg.get("vulnerabilities", []) or []:
        if isinstance(vuln, dict):
            for key in ("cve", "id", "advisory_id"):
                value = vuln.get(key)
                if value:
                    values.append(str(value).strip())

    deduped = []
    for value in values:
        if value and value not in deduped:
            deduped.append(value)

    return deduped


def normalize_to_cve(pkg: dict) -> str | None:
    for value in _candidate_ids(pkg):
        upper = value.upper()

        if upper.startswith("CVE-"):
            return upper

        if upper.startswith("GHSA-") and value in GHSA_TO_CVE_ALIAS:
            return GHSA_TO_CVE_ALIAS[value]

    return None


def _reachable(pkg: dict) -> bool:
    return (
        str(pkg.get("reachability_status") or "").upper() == "REACHABLE"
        or str(pkg.get("reachability_priority") or "").upper()
        == "REACHABLE_VULNERABLE"
    )


def _kev_priority(pkg: dict, cve: str | None) -> str:
    if not cve or cve not in KNOWN_EXPLOITED_CVES:
        return "NO_KEV_SIGNAL"

    if _reachable(pkg):
        return "P0_REACHABLE_KEV"

    return "P1_KEV_REVIEW"


def enrich_kev_intelligence(sbom: list[dict]) -> list[dict]:
    enriched = []

    for pkg in sbom:
        item = dict(pkg)

        cve = normalize_to_cve(item)
        kev_record = KNOWN_EXPLOITED_CVES.get(cve) if cve else None

        item["normalized_cve"] = cve
        item["kev_status"] = bool(kev_record)
        item["actively_exploited"] = bool(kev_record)
        item["kev_priority"] = _kev_priority(item, cve)

        if kev_record:
            item["kev_vendor"] = kev_record.get("vendor")
            item["kev_product"] = kev_record.get("product")
            item["kev_vulnerability_name"] = kev_record.get("name")
            item["kev_added_date"] = kev_record.get("kev_added_date")
            item["kev_due_date"] = kev_record.get("due_date")
            item["kev_ransomware_use"] = kev_record.get("ransomware_use")
            item["kev_method"] = "STATIC_OFFLINE_CISA_KEV_V1"
        else:
            item["kev_method"] = "NO_KEV_MATCH"

        enriched.append(item)

    return enriched


def kev_intelligence_summary(sbom: list[dict]) -> dict:
    priority_counter = Counter()
    ransomware_counter = Counter()

    total_vulnerable = 0
    normalized_cve_count = 0
    kev_count = 0
    reachable_kev = 0
    ransomware_known = 0

    for pkg in sbom:
        if not (
            pkg.get("cve")
            or pkg.get("advisory_id")
            or pkg.get("primary_vulnerability_id")
            or pkg.get("normalized_cve")
        ):
            continue

        total_vulnerable += 1

        if pkg.get("normalized_cve"):
            normalized_cve_count += 1

        if pkg.get("kev_status"):
            kev_count += 1

        if pkg.get("kev_status") and _reachable(pkg):
            reachable_kev += 1

        priority_counter[pkg.get("kev_priority", "NO_KEV_SIGNAL")] += 1

        ransomware = pkg.get("kev_ransomware_use", "Unknown")
        ransomware_counter[ransomware] += 1

        if ransomware == "Known":
            ransomware_known += 1

    return {
        "total_vulnerable_packages": total_vulnerable,
        "normalized_cve_packages": normalized_cve_count,
        "kev_packages": kev_count,
        "reachable_kev_packages": reachable_kev,
        "known_ransomware_use_packages": ransomware_known,
        "kev_priority_counts": dict(priority_counter),
        "ransomware_use_counts": dict(ransomware_counter),
        "summary_status": "STATIC_OFFLINE_CISA_KEV_V1",
    }


if __name__ == "__main__":
    sample = [
        {
            "name": "log4j-core",
            "version": "2.14.1",
            "advisory_id": "GHSA-3pxv-7cmr-fjr4",
            "severity": "Critical",
            "reachability_status": "REACHABLE",
        },
        {
            "name": "spring-web",
            "version": "5.3.17",
            "cve": "CVE-2022-22965",
            "severity": "Critical",
            "reachability_status": "NOT_OBSERVED",
        },
        {
            "name": "left-pad",
            "version": "1.3.0",
            "advisory_id": "GHSA-test",
            "severity": "Medium",
        },
    ]

    import json

    enriched = enrich_kev_intelligence(sample)
    print(json.dumps(enriched, indent=2))
    print(json.dumps(kev_intelligence_summary(enriched), indent=2))