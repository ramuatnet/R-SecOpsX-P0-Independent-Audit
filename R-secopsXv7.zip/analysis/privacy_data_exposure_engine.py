from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Dict, List

SCAN_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".php", ".rb", ".cs",
    ".json", ".yml", ".yaml", ".xml", ".properties", ".env", ".txt", ".md",
}

SKIP_DIRS = {".git", "node_modules", "venv", ".venv", "__pycache__", "dist", "build", "target", ".next"}

PII_PATTERNS = [
    ("AADHAAR", r"\b(?:aadhaar|aadhar|uidai)\b|\b\d{4}[ -]?\d{4}[ -]?\d{4}\b", "CRITICAL", "India national identifier"),
    ("PAN", r"\b[A-Z]{5}[0-9]{4}[A-Z]\b|\bpan(?:_?number)?\b", "HIGH", "India tax identifier"),
    ("SSN", r"\b\d{3}-\d{2}-\d{4}\b|\bssn\b|social_security", "CRITICAL", "US social security number"),
    ("PAYMENT_CARD", r"\b(?:card|credit_card|pan|cvv|cvc)\b|\b(?:4\d{3}|5[1-5]\d{2}|3[47]\d{2})[ -]?\d{4}[ -]?\d{4}[ -]?\d{4}\b", "CRITICAL", "Payment card data"),
    ("EMAIL", r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b|\bemail\b", "MEDIUM", "Email address"),
    ("PHONE", r"\b(?:phone|mobile|msisdn)\b|\b(?:\+?91[- ]?)?[6-9]\d{9}\b", "MEDIUM", "Phone number"),
    ("DOB", r"\b(date_of_birth|dob|birth_date)\b", "MEDIUM", "Date of birth"),
    ("ADDRESS", r"\b(address|postal_code|zipcode|zip_code|geo_location|latitude|longitude)\b", "MEDIUM", "Location/address data"),
    ("HEALTH", r"\b(patient|diagnosis|medical_record|health_record|prescription|hipaa)\b", "HIGH", "Health data"),
    ("BIOMETRIC", r"\b(biometric|fingerprint|face_id|facial_template|iris)\b", "CRITICAL", "Biometric data"),
]

EXPOSURE_PATTERNS = [
    ("PII_LOGGING", r"\b(print|logger\.|console\.log|log\.)\b.*\b(ssn|aadhaar|aadhar|pan|card|cvv|email|phone|token|password)\b", "HIGH", "PII or sensitive data may be written to logs."),
    ("PII_API_RESPONSE", r"\b(return|jsonify|res\.json|response)\b.*\b(ssn|aadhaar|aadhar|pan|card|cvv|email|phone|dob|address)\b", "HIGH", "PII may be returned in an API response."),
    ("PII_THIRD_PARTY_TRANSFER", r"\b(requests\.(post|put)|fetch\(|axios\.(post|put)|http\.post)\b.*\b(ssn|aadhaar|aadhar|pan|card|cvv|email|phone|dob|address|token)\b", "HIGH", "PII may be sent to an external or third-party endpoint."),
    ("PII_UNENCRYPTED_STORAGE", r"\b(insert|save|write|put_item|setItem)\b.*\b(ssn|aadhaar|aadhar|pan|card|cvv|dob|address)\b", "HIGH", "PII may be stored without visible encryption or tokenization."),
    ("PROMPT_PII_EXPOSURE", r"\b(prompt|message|chat|llm|openai|anthropic)\b.*\b(ssn|aadhaar|aadhar|pan|card|cvv|email|phone|dob|address)\b", "HIGH", "PII may be sent to an AI prompt/model context."),
    ("NO_RETENTION_CONTROL", r"\b(retention|ttl|expire|delete_after|purge_after)\s*=\s*(None|False|0|\"\")", "MEDIUM", "Retention or deletion control appears disabled or undefined."),
    ("CONSENT_BYPASS", r"\b(consent_required|privacy_check|purpose_check)\s*=\s*False\b|skip_consent\s*=\s*True", "HIGH", "Consent or purpose limitation check may be bypassed."),
]

THIRD_PARTY_HINTS = ["openai", "anthropic", "googleapis", "segment", "mixpanel", "analytics", "hubspot", "stripe", "sendgrid", "slack", "telegram", "discord"]


def _iter_files(target: str):
    root = Path(target)
    for current, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d.lower() not in SKIP_DIRS]
        for name in files:
            path = Path(current) / name
            if path.suffix.lower() in SCAN_EXTENSIONS:
                yield path


def _safe_read(path: Path) -> List[str]:
    try:
        return path.read_text(encoding="utf-8", errors="ignore").splitlines()
    except Exception:
        return []


def _rel(path: Path, target: str) -> str:
    try:
        return str(path.relative_to(Path(target)))
    except Exception:
        return str(path)


def _risk_rank(level: str) -> int:
    return {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}.get(str(level).upper(), 0)


def _recommended_action(indicator: str) -> List[str]:
    base = [
        "Classify the data element and confirm whether it is regulated, confidential, or customer-identifiable.",
        "Minimize collection and exposure; return or transmit only fields required for the business purpose.",
        "Apply masking, tokenization, or strong encryption for storage, logs, prompts, and outbound transfers.",
    ]
    if indicator == "PII_LOGGING":
        return [
            "Remove PII from application, debug, prompt, and access logs.",
            "Apply irreversible redaction for Aadhaar/PAN/SSN/card/email/phone before log write.",
            "Restrict log access, shorten retention, and scan historical logs for exposed PII.",
        ]
    if indicator == "PII_API_RESPONSE":
        return [
            "Use explicit response DTOs/schemas and deny-list sensitive fields from serialized objects.",
            "Mask identifiers and return only the minimum fields required by the caller.",
            "Add authorization checks before returning customer or account-level data.",
        ]
    if indicator == "PII_THIRD_PARTY_TRANSFER":
        return [
            "Validate lawful basis, consent, DPA, and approved vendor status before transfer.",
            "Redact or tokenize PII before sending to third-party APIs or model providers.",
            "Add egress allow-listing and audit logging for sensitive data transfers.",
        ]
    if indicator == "PROMPT_PII_EXPOSURE":
        return [
            "Do not send raw PII to LLM/model context unless explicitly approved and contractually protected.",
            "Redact identifiers before prompt construction and disable prompt/response logging for PII.",
            "Add policy checks for purpose limitation, retention, and cross-border transfer constraints.",
        ]
    return base


def enrich_privacy_data_exposure(target: str, findings: List[Dict[str, Any]] | None = None, api_bom: List[Dict[str, Any]] | None = None, data_flow_summary: Dict[str, Any] | None = None) -> Dict[str, Any]:
    indicators: List[Dict[str, Any]] = []
    pii_type_counts: Dict[str, int] = {}

    for path in _iter_files(target):
        for line_no, line in enumerate(_safe_read(path), start=1):
            text = line.strip()
            if not text:
                continue

            pii_hits = []
            max_risk = "LOW"
            descriptions = []
            for pii_type, pattern, risk, description in PII_PATTERNS:
                if re.search(pattern, text, re.IGNORECASE):
                    pii_hits.append(pii_type)
                    descriptions.append(description)
                    pii_type_counts[pii_type] = pii_type_counts.get(pii_type, 0) + 1
                    if _risk_rank(risk) > _risk_rank(max_risk):
                        max_risk = risk

            exposure_hits = []
            for indicator, pattern, risk, impact in EXPOSURE_PATTERNS:
                if re.search(pattern, text, re.IGNORECASE):
                    exposure_hits.append((indicator, risk, impact))
                    if _risk_rank(risk) > _risk_rank(max_risk):
                        max_risk = risk

            if not pii_hits and not exposure_hits:
                continue

            third_party = any(h in text.lower() for h in THIRD_PARTY_HINTS)
            if third_party and pii_hits and _risk_rank(max_risk) < _risk_rank("HIGH"):
                max_risk = "HIGH"

            indicator_name = exposure_hits[0][0] if exposure_hits else "PII_PATTERN_OBSERVED"
            impact = exposure_hits[0][2] if exposure_hits else "PII-like data element observed in source code and should be reviewed for exposure path."

            indicators.append({
                "indicator": indicator_name,
                "risk_level": max_risk,
                "severity": "Critical" if max_risk == "CRITICAL" else ("High" if max_risk == "HIGH" else "Medium"),
                "file": _rel(path, target),
                "line": line_no,
                "snippet": text[:240],
                "pii_types": sorted(set(pii_hits)),
                "privacy_domain": "Data Privacy / PII Exposure",
                "third_party_transfer_hint": third_party,
                "description": impact,
                "business_impact": "Potential exposure of regulated or customer-identifiable data may trigger privacy, contractual, and compliance obligations.",
                "recommended_actions": _recommended_action(indicator_name),
                "framework_mappings": {
                    "gdpr": ["Art. 5 Data minimisation", "Art. 32 Security of processing"],
                    "dpdp_india": ["Purpose limitation", "Reasonable security safeguards"],
                    "nist_privacy": ["CT.PO-P", "DM.PD-P"],
                },
                "confidence": "MEDIUM" if exposure_hits else "LOW",
            })

    # Add contextual signal from data-flow engine if it already found sensitive flows.
    dfs = data_flow_summary or {}
    sensitive_count = int(dfs.get("total_data_flow_sensitivity_indicators", 0) or dfs.get("total_indicators", 0) or 0)
    if sensitive_count:
        indicators.append({
            "indicator": "SENSITIVE_DATA_FLOW_CONTEXT",
            "risk_level": "HIGH" if sensitive_count >= 5 else "MEDIUM",
            "severity": "High" if sensitive_count >= 5 else "Medium",
            "file": "DATA_FLOW_CORRELATION",
            "line": 0,
            "snippet": f"{sensitive_count} sensitive data-flow indicators observed by data-flow engine.",
            "pii_types": [],
            "privacy_domain": "Data Privacy / Data Flow",
            "third_party_transfer_hint": False,
            "description": "Existing data-flow indicators suggest sensitive data handling paths that require privacy review.",
            "business_impact": "Sensitive data movement may expand breach impact and regulatory exposure.",
            "recommended_actions": [
                "Review correlated sensitive data flows and confirm data classification for each source/sink.",
                "Add masking/encryption at sinks and enforce data minimisation in API responses.",
                "Map each sensitive flow to owner, purpose, retention, and approved processing basis.",
            ],
            "confidence": "MEDIUM",
        })

    critical = sum(1 for i in indicators if i.get("risk_level") == "CRITICAL")
    high = sum(1 for i in indicators if i.get("risk_level") == "HIGH")
    third_party_count = sum(1 for i in indicators if i.get("third_party_transfer_hint"))

    return {
        "summary_status": "PRIVACY_DATA_EXPOSURE_INDICATORS_IDENTIFIED" if indicators else "NO_PRIVACY_DATA_EXPOSURE_INDICATORS_IDENTIFIED",
        "total_privacy_indicators": len(indicators),
        "critical_privacy_indicators": critical,
        "high_privacy_indicators": high,
        "third_party_transfer_indicators": third_party_count,
        "pii_type_counts": pii_type_counts,
        "executive_relevant": critical + high,
        "engine_mode": "STATIC_PRIVACY_PATTERN_AND_CONTEXT_ANALYSIS_V1",
        "indicators": indicators[:500],
    }
