"""
security_control_coverage_engine.py
R-SecOpsX Security Control Coverage Engine

Purpose:
    Static, evidence-based security-control coverage inference.

Design principle:
    This engine records controls that are OBSERVED in available static evidence.
    Missing-control entries are review signals, not proof of absence.
"""

from __future__ import annotations

import re
from collections import defaultdict
from typing import Any, Dict, List


CONTROL_PATTERNS = [
    # ------------------------------------------------------------------
    # Authentication controls
    # ------------------------------------------------------------------
    (
        "AUTHENTICATION_CONTROL",
        r"\blogin_required\b|\bauthentication_required\b|\bauthenticate\s*\(|\bverify_token\b|\bjwt\.decode\b|\brequire_login\b|\bcurrent_user\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V2",
    ),
    (
        "MFA_CONTROL",
        r"\bmfa\b|\btotp\b|\bMultiFactorAuth\b|\btwo_factor\b|\btwo-factor\b|\bone_time_password\b|\botp_secret\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V2",
    ),
    (
        "STEP_UP_AUTH_CONTROL",
        r"\bstep_up\b|\bre_authenticate\b|\bre-authenticate\b|\brequire_mfa\b|\brecent_login_required\b|\bconfirm_password\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V2",
    ),
    (
        "RISK_BASED_AUTH_CONTROL",
        r"\brisk_score\b|\bdevice_trust\b|\bnew_device\b|\bimpossible_travel\b|\banomaly_score\b|\bsuspicious_login\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V2",
    ),
    (
        "PASSWORD_POLICY_CONTROL",
        r"\bpassword_policy\b|\bmin_length\b|\bminimum_length\b|\bpassword_regex\b|\brequire_uppercase\b|\brequire_lowercase\b|\brequire_digit\b|\brequire_special\b|\bpassword_complexity\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V2",
    ),
    (
        "BREACHED_PASSWORD_CHECK",
        r"\bhaveibeenpwned\b|\bpwned_password\b|\bbreached_password\b|\bpassword_blacklist\b|\bcompromised_password\b|\bcommon_password\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V2",
    ),
    (
        "PASSWORD_HISTORY_CONTROL",
        r"\bpassword_history\b|\bprevious_passwords\b|\bpassword_reuse_history\b|\bpassword_history_count\b|\blast_password_hashes\b|\bpassword_archive\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V2",
    ),
    (
        "PASSWORD_REUSE_CONTROL",
        r"\bprevent_password_reuse\b|\bdisallow_password_reuse\b|\breject_previous_password\b|\bno_password_reuse\b|\bpassword_not_reused\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V2",
    ),
    (
        "PASSWORD_BREACH_API_RATE_LIMIT",
        r"\bhibp_rate_limit\b|\bpwned_password_rate_limit\b|\bbreach_check_rate_limit\b|\bpassword_breach_cache\b|\bbreach_api_backoff\b|\bhibp_backoff\b",
        "ABUSE_PREVENTION",
        "OWASP_ASVS_V2",
    ),
    (
        "DEVICE_BINDING_CONTROL",
        r"\bdevice_binding\b|\btrusted_device\b|\bdevice_id_binding\b|\bdevice_public_key\b|\bdevice_attestation\b|\bwebauthn_device\b|\bpasskey_binding\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V2",
    ),
    (
        "ACCOUNT_LOCKOUT_CONTROL",
        r"\baccount_lockout\b|\block_after\b|\bfailed_login_attempts\b|\bmax_login_attempts\b|\blogin_attempts\b|\block_login\b|\btemporary_lock\b",
        "ABUSE_PREVENTION",
        "OWASP_ASVS_V2",
    ),
    (
        "SESSION_TIMEOUT_CONTROL",
        r"\bsession_timeout\b|\bexpires_in\b|\bmax_age\b|\bidle_timeout\b|\babsolute_timeout\b|\bsession_expiry\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V3",
    ),
    (
        "SESSION_ROTATION_CONTROL",
        r"\bregenerate_session\b|\bsession\.regenerate\b|\brotate_session\b|\brenew_session\b|\bnew_session_id\b|\bcycle_key\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V3",
    ),
    (
        "PASSWORD_RESET_TOKEN_CONTROL",
        r"\breset_token\b|\bpassword_reset_token\b|\bforgot_password\b|\breset_password\b|\btoken_expiry\b|\bone_time_token\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V2",
    ),
    (
        "EMAIL_VERIFICATION_CONTROL",
        r"\bemail_verified\b|\bverify_email\b|\bemail_verification_token\b|\bconfirm_email\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V2",
    ),
    (
        "JWT_VALIDATION_CONTROL",
        r"\bverify_signature\b|\bissuer\b|\baudience\b|\bexp\b|\bjwks\b|\bjwt_required\b|\bdecode_token\b",
        "AUTHENTICATION",
        "OWASP_ASVS_V2",
    ),

    # ------------------------------------------------------------------
    # Authorization controls
    # ------------------------------------------------------------------
    (
        "AUTHORIZATION_CONTROL",
        r"\bauthorize\s*\(|\bpermission_required\b|\brole_required\b|\bhas_permission\b|\bcheck_permission\b|\brequire_permission\b",
        "AUTHORIZATION",
        "OWASP_ASVS_V4",
    ),
    (
        "RBAC_CONTROL",
        r"\brbac\b|\bRoleBinding\b|\bClusterRole\b|\bpolicy_document\b|\brole_policy\b|\brole_based\b",
        "AUTHORIZATION",
        "OWASP_ASVS_V4",
    ),
    (
        "OWNERSHIP_CHECK",
        r"\bowner_id\b|\bbelongs_to_user\b|\bcheck_owner\b|\bownership_check\b|\bobject_owner\b|\bresource_owner\b",
        "AUTHORIZATION",
        "OWASP_API1_BOLA",
    ),
    (
        "TENANT_ISOLATION_CONTROL",
        r"\btenant_id\b|\borg_id\b|\bworkspace_id\b|\brow_level_security\b|\btenant_scope\b|\borganization_scope\b",
        "AUTHORIZATION",
        "OWASP_API1",
    ),
    (
        "PRIVILEGED_ACTION_AUTHORIZATION",
        r"\brequire_admin\b|\badmin_required\b|\bsuperuser_required\b|\bprivileged_action\b|\brequire_role\s*\(.*admin",
        "AUTHORIZATION",
        "OWASP_ASVS_V4",
    ),
    (
        "ADMIN_APPROVAL_WORKFLOW",
        r"\badmin_approval\b|\bapproval_required\b|\bapprover_id\b|\bfour_eyes\b|\btwo_person_rule\b|\bdual_control\b|\bmanager_approval\b",
        "AUTHORIZATION",
        "OWASP_ASVS_V4",
    ),
    (
        "JUST_IN_TIME_ACCESS",
        r"\bjust_in_time_access\b|\bjit_access\b|\btemporary_privilege\b|\bprivilege_expiry\b|\btime_bound_access\b|\belevation_expiry\b|\bprivileged_session_ttl\b",
        "AUTHORIZATION",
        "OWASP_ASVS_V4",
    ),
    (
        "BREAK_GLASS_ACCESS_CONTROL",
        r"\bbreak_glass\b|\bemergency_access\b|\bsealed_admin\b|\bemergency_admin\b|\bbreakglass\b|\bbreak_glass_approval\b|\bbreak_glass_audit\b",
        "AUTHORIZATION",
        "OWASP_ASVS_V4",
    ),

    # ------------------------------------------------------------------
    # Input validation and upload controls
    # ------------------------------------------------------------------
    (
        "INPUT_VALIDATION_CONTROL",
        r"\bvalidate_[a-zA-Z0-9_]+\b|\bschema\.validate\b|\bpydantic\b|\bmarshmallow\b|\bjoi\.validate\b|\brequest_schema\b",
        "INPUT_VALIDATION",
        "OWASP_ASVS_V5",
    ),
    (
        "SANITIZATION_CONTROL",
        r"\bsanitize\b|\bhtmlspecialchars\b|\bbleach\.clean\b|\bstrip_tags\b|\bclean_input\b",
        "INPUT_VALIDATION",
        "OWASP_ASVS_V5",
    ),
    (
        "SECURE_FILE_UPLOAD_CONTROL",
        r"\ballowed_extensions\b|\bmax_file_size\b|\bvirus_scan\b|\bcontent_type_validation\b|\bfile_type_allowlist\b|\bsecure_filename\b",
        "INPUT_VALIDATION",
        "OWASP_ASVS_V12",
    ),
    (
        "PATH_TRAVERSAL_GUARD_CONTROL",
        r"\bsafe_join\b|\bnormalize_path\b|\brealpath\b|\bresolved_path\b|\bpath_allowlist\b",
        "INPUT_VALIDATION",
        "OWASP_ASVS_V5",
    ),

    # ------------------------------------------------------------------
    # Output and data exposure controls
    # ------------------------------------------------------------------
    (
        "OUTPUT_ENCODING_CONTROL",
        r"\bhtml\.escape\b|\bmarkupsafe\b|\bencodeURIComponent\b|\bescape_html\b",
        "OUTPUT_PROTECTION",
        "OWASP_ASVS_V5",
    ),
    (
        "RESPONSE_FILTERING_CONTROL",
        r"\bresponse_model\b|\bserializer\b|\bexclude\s*=\b|\bfields\s*=\s*\[|\bmask_fields\b|\bredact\b",
        "OUTPUT_PROTECTION",
        "OWASP_API3",
    ),
    (
        "DATA_MINIMIZATION_CONTROL",
        r"\bdata_minimization\b|\bmask_sensitive\b|\bredact_sensitive\b|\bpii_redaction\b|\bexclude_sensitive\b",
        "OUTPUT_PROTECTION",
        "OWASP_API3",
    ),

    # ------------------------------------------------------------------
    # Abuse prevention controls
    # ------------------------------------------------------------------
    (
        "RATE_LIMIT_CONTROL",
        r"\brate_limit\b|\bLimiter\b|\bthrottle\b|\bslow_down\b|\bmax_requests\b|\brequest_limit\b",
        "ABUSE_PREVENTION",
        "OWASP_API4",
    ),
    (
        "LOGIN_RATE_LIMIT_CONTROL",
        r"\blogin_rate_limit\b|\blogin_throttle\b|\bfailed_login_rate\b|\bmax_login_rate\b|\bip_login_limit\b",
        "ABUSE_PREVENTION",
        "OWASP_ASVS_V2",
    ),
    (
        "CAPTCHA_CONTROL",
        r"\brecaptcha\b|\bhcaptcha\b|\bturnstile\b|\bcaptcha_(verify|validate|check)\b|\bverify_captcha\b|\bvalidate_captcha\b|\bcaptcha_siteverify\b",
        "ABUSE_PREVENTION",
        "OWASP_ASVS_V2",
    ),
    (
        "IDEMPOTENCY_CONTROL",
        r"\bidempotency_key\b|\bIdempotency-Key\b|\bidempotent_request\b",
        "ABUSE_PREVENTION",
        "OWASP_API6",
    ),
    (
        "REPLAY_PROTECTION_CONTROL",
        r"\breplay_protection\b|\btimestamp_validation\b|\bnonce_required\s*=\s*True\b|\bnonce\b|\banti_replay\b",
        "ABUSE_PREVENTION",
        "OWASP_API6",
    ),
    (
        "BOT_ABUSE_DETECTION_CONTROL",
        r"\bbot_detection\b|\babuse_score\b|\bfraud_score\b|\bautomation_detected\b|\bdevice_fingerprint\b",
        "ABUSE_PREVENTION",
        "OWASP_API4",
    ),

    # ------------------------------------------------------------------
    # API security controls
    # ------------------------------------------------------------------
    (
        "WEBHOOK_SIGNATURE_VALIDATION",
        r"\bverify_signature\b|\bX-Hub-Signature\b|\bstripe-signature\b|\bwebhook_secret\b|\bsvix-signature\b|\bx-signature\b",
        "API_SECURITY",
        "OWASP_API10",
    ),
    (
        "API_SCHEMA_VALIDATION_CONTROL",
        r"\bopenapi\b|\bswagger\b|\bapi_schema\b|\brequest_validation\b|\bvalidate_request\b",
        "API_SECURITY",
        "OWASP_API8",
    ),
    (
        "MASS_ASSIGNMENT_GUARD_CONTROL",
        r"\ballowed_fields\b|\bdeny_fields\b|\bfillable\b|\bguarded\b|\bmass_assignment\b|\bexclude_unset\b",
        "API_SECURITY",
        "OWASP_API6",
    ),

    # ------------------------------------------------------------------
    # Web/browser security controls
    # ------------------------------------------------------------------
    (
        "CSRF_CONTROL",
        r"\bcsrf\b|\bCSRFProtect\b|\bcsrf_token\b|\banti_csrf\b",
        "WEB_SECURITY",
        "OWASP_ASVS_V4",
    ),
    (
        "CORS_RESTRICTION_CONTROL",
        r"\ballowed_origins\b|\bCORS\(.*origins\s*=\s*\[|\bAccess-Control-Allow-Origin\b.*https?://|\bcors_origin_allowlist\b",
        "WEB_SECURITY",
        "OWASP_API8",
    ),
    (
        "SECURITY_HEADERS_CONTROL",
        r"\bContent-Security-Policy\b|\bX-Frame-Options\b|\bStrict-Transport-Security\b|\bX-Content-Type-Options\b|\bReferrer-Policy\b",
        "WEB_SECURITY",
        "OWASP_ASVS_V14",
    ),
    (
        "SECURE_COOKIE_CONTROL",
        r"\bsecure\s*=\s*True\b|\bhttponly\s*=\s*True\b|\bSameSite\b|\bsamesite\s*=\s*['\"]?(strict|lax)",
        "WEB_SECURITY",
        "OWASP_ASVS_V3",
    ),

    # ------------------------------------------------------------------
    # Crypto controls
    # ------------------------------------------------------------------
    (
        "ENCRYPTION_CONTROL",
        r"\bencrypt\b|\bAES\b|\bChaCha20\b|\bFernet\b|\bTLS\b|\bssl_context\b",
        "CRYPTO",
        "OWASP_ASVS_V6",
    ),
    (
        "PASSWORD_HASHING_CONTROL",
        r"\bbcrypt\b|\bargon2\b|\bpbkdf2\b|\bscrypt\b|\bhash_password\b|\bwerkzeug\.security\b",
        "CRYPTO",
        "OWASP_ASVS_V6",
    ),
    (
        "CERT_VALIDATION_CONTROL",
        r"\bverify\s*=\s*True\b|\bcheck_hostname\s*=\s*True\b|\bCERT_REQUIRED\b|\bssl\.create_default_context\b",
        "CRYPTO",
        "OWASP_ASVS_V6",
    ),
    (
        "KEY_ROTATION_CONTROL",
        r"\bkey_rotation\b|\brotate_key\b|\bkey_version\b|\bkms_key_id\b|\bautomatic_rotation\b",
        "CRYPTO",
        "OWASP_ASVS_V6",
    ),

    # ------------------------------------------------------------------
    # Secrets controls
    # ------------------------------------------------------------------
    (
        "SECRETS_MANAGER_CONTROL",
        r"\bSecretsManager\b|\bsecretmanager\b|\bKeyVault\b|\bVault\b|\bget_secret_value\b|\bsecret_client\b",
        "SECRETS",
        "OWASP_ASVS_V6",
    ),
    (
        "ENV_SECRET_CONTROL",
        r"\bos\.environ\b|\bgetenv\s*\(|\bprocess\.env\b|\bENV\[",
        "SECRETS",
        "OWASP_ASVS_V6",
    ),
    (
        "SECRET_ROTATION_CONTROL",
        r"\bsecret_rotation\b|\brotate_secret\b|\brotation_interval\b|\bsecret_version\b",
        "SECRETS",
        "OWASP_ASVS_V6",
    ),

    # ------------------------------------------------------------------
    # Monitoring and resilience controls
    # ------------------------------------------------------------------
    (
        "AUDIT_LOGGING_CONTROL",
        r"\baudit_log\b|\bsecurity_event\b|\bSIEM\b|\blogger\.(info|warning|error|critical)\b|\baudit_event\b",
        "MONITORING",
        "OWASP_ASVS_V7",
    ),
    (
        "AUTH_EVENT_MONITORING_CONTROL",
        r"\blogin_event\b|\bfailed_login\b|\bprivilege_change\b|\baccount_locked\b|\bsecurity_alert\b",
        "MONITORING",
        "OWASP_ASVS_V7",
    ),
    (
        "ERROR_HANDLING_CONTROL",
        r"\berror_handler\b|\bhandle_exception\b|\bexcept\s+[A-Za-z0-9_]+Error\b|\bcatch\s*\([^)]*Error|\bsafe_error\b",
        "RESILIENCE",
        "OWASP_ASVS_V7",
    ),
    (
        "FAIL_CLOSED_CONTROL",
        r"\bfail_closed\b|\bdeny_by_default\b|\bdefault_deny\b|\bsecure_default\b",
        "RESILIENCE",
        "OWASP_ASVS_V1",
    ),
]


REQUIRED_CONTROL_DOMAINS = [
    "AUTHENTICATION",
    "AUTHORIZATION",
    "INPUT_VALIDATION",
    "OUTPUT_PROTECTION",
    "ABUSE_PREVENTION",
    "API_SECURITY",
    "WEB_SECURITY",
    "CRYPTO",
    "SECRETS",
    "MONITORING",
    "RESILIENCE",
]


DOMAIN_RECOMMENDATIONS = {
    "AUTHENTICATION": "Review authentication enforcement, password policy, breached-password checks, password history/reuse controls, MFA, device binding, session rotation, and password-reset controls.",
    "AUTHORIZATION": "Review object-level, role-level, tenant-level, privileged-action, admin-approval, just-in-time access, and break-glass controls.",
    "INPUT_VALIDATION": "Review schema validation, input normalization, sanitization, path controls, and upload restrictions.",
    "OUTPUT_PROTECTION": "Review response filtering, sensitive-data redaction, and output encoding.",
    "ABUSE_PREVENTION": "Review rate limits, CAPTCHA verification, account lockout, breach-check API throttling, replay protection, and bot-abuse controls.",
    "API_SECURITY": "Review API schema validation, webhook signature validation, and mass-assignment protections.",
    "WEB_SECURITY": "Review CSRF protection, CORS restrictions, secure cookies, and browser security headers.",
    "CRYPTO": "Review encryption, password hashing, TLS, certificate validation, and key rotation.",
    "SECRETS": "Review secrets managers, environment isolation, runtime secret handling, and secret rotation.",
    "MONITORING": "Review audit logging, security event logging, auth-event logging, and SIEM integration.",
    "RESILIENCE": "Review structured error handling, fail-closed behavior, and safe exception disclosure.",
}


def _collect_text(obj: Any) -> str:
    if obj is None:
        return ""
    if isinstance(obj, str):
        return obj
    if isinstance(obj, dict):
        return " ".join(_collect_text(v) for v in obj.values() if v is not None)
    if isinstance(obj, list):
        return " ".join(_collect_text(x) for x in obj)
    return str(obj)


def _function_name(item: Dict[str, Any]) -> str:
    return str(
        item.get("function_name")
        or item.get("function")
        or item.get("method")
        or item.get("method_name")
        or ""
    ).strip()


def _finding_text(finding: Dict[str, Any]) -> str:
    return " ".join([
        str(finding.get("rule_id", "")),
        str(finding.get("title", "")),
        str(finding.get("description", "")),
        str(finding.get("snippet", "")),
        str(finding.get("evidence", "")),
        str(finding.get("file", "")),
        str(finding.get("file_path", "")),
        str(finding.get("issue_type", "")),
        _collect_text(finding.get("occurrences", [])),
    ])


def _coverage_grade(ratio: float) -> str:
    if ratio >= 0.85:
        return "STRONG"
    if ratio >= 0.60:
        return "MODERATE"
    if ratio > 0:
        return "LIMITED"
    return "NOT_OBSERVED"


def _defense_status(ratio: float, missing_count: int) -> str:
    if ratio >= 0.85 and missing_count == 0:
        return "DEFENSE_IN_DEPTH_CONTROLS_OBSERVED"
    if ratio >= 0.60:
        return "PARTIAL_DEFENSE_IN_DEPTH_CONTROLS_OBSERVED"
    return "CONTROL_COVERAGE_GAPS_IDENTIFIED"


def _risk_for_domain(domain: str) -> str:
    if domain in {"AUTHENTICATION", "AUTHORIZATION", "SECRETS", "CRYPTO"}:
        return "HIGH"
    if domain in {"ABUSE_PREVENTION", "API_SECURITY", "WEB_SECURITY", "INPUT_VALIDATION", "OUTPUT_PROTECTION"}:
        return "MEDIUM"
    return "LOW"


def _detect_controls(
    context_id: str,
    context_type: str,
    text: str,
    evidence: Dict[str, Any],
) -> List[Dict[str, Any]]:
    controls: List[Dict[str, Any]] = []

    for control, pattern, domain, framework in CONTROL_PATTERNS:
        match = re.search(pattern, text or "", flags=re.IGNORECASE | re.DOTALL)
        if not match:
            continue

        controls.append({
            "context_id": context_id,
            "context_type": context_type,
            "control": control,
            "domain": domain,
            "status": "OBSERVED",
            "risk_level": "INFO",
            "coverage_observed": True,
            "confidence": "Medium",
            "evidence_match": match.group(0)[:160],
            "evidence": evidence or {},
            "mapped_frameworks": [framework],
            "recommended_action": (
                "Validate whether this control is consistently enforced across applicable routes, "
                "functions, services, and deployment paths."
            ),
        })

    return controls


def _missing_control_findings(domains_observed: List[str]) -> List[Dict[str, Any]]:
    missing: List[Dict[str, Any]] = []

    for domain in REQUIRED_CONTROL_DOMAINS:
        if domain in domains_observed:
            continue

        risk = _risk_for_domain(domain)

        missing.append({
            "context_id": domain,
            "context_type": "DOMAIN_COVERAGE",
            "control": f"{domain}_CONTROL_NOT_OBSERVED",
            "domain": domain,
            "status": "NOT_OBSERVED",
            "risk_level": risk,
            "coverage_observed": False,
            "confidence": "Low",
            "evidence_match": None,
            "evidence": {
                "note": "Control was not observed in available static evidence. This is not proof the control is absent.",
            },
            "mapped_frameworks": [],
            "recommended_action": DOMAIN_RECOMMENDATIONS.get(domain, "Review control coverage."),
        })

    return missing


def _dedupe(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    deduped: Dict[tuple, Dict[str, Any]] = {}

    for item in items:
        key = (
            item.get("context_type"),
            item.get("context_id"),
            item.get("control"),
            item.get("domain"),
        )

        if key not in deduped:
            deduped[key] = item

    return list(deduped.values())


def enrich_security_control_coverage(
    findings: List[Dict[str, Any]],
    api_bom: List[Dict[str, Any]] = None,
    cbom: List[Dict[str, Any]] = None,
    abom: List[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    findings = findings or []
    api_bom = api_bom or []
    cbom = cbom or []
    abom = abom or []

    control_findings: List[Dict[str, Any]] = []
    file_groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    function_groups: Dict[tuple, List[Dict[str, Any]]] = defaultdict(list)

    for finding in findings:
        file_key = finding.get("file") or finding.get("file_path") or ""
        fn = _function_name(finding)

        context_id = str(
            finding.get("id")
            or finding.get("rule_id")
            or finding.get("title")
            or file_key
            or "finding"
        )

        control_findings.extend(_detect_controls(
            context_id=context_id,
            context_type="FINDING",
            text=_finding_text(finding),
            evidence={
                "file": file_key,
                "line": finding.get("line"),
                "rule_id": finding.get("rule_id"),
                "title": finding.get("title"),
                "function": fn or None,
            },
        ))

        if file_key:
            file_groups[str(file_key)].append(finding)
        if file_key and fn:
            function_groups[(str(file_key), fn)].append(finding)

    for file_key, grouped in file_groups.items():
        control_findings.extend(_detect_controls(
            context_id=file_key,
            context_type="FILE_CONTEXT",
            text=" ".join(_finding_text(x) for x in grouped),
            evidence={
                "file": file_key,
                "finding_count": len(grouped),
            },
        ))

    for (file_key, fn), grouped in function_groups.items():
        control_findings.extend(_detect_controls(
            context_id=f"{file_key}::{fn}",
            context_type="FUNCTION_CONTEXT",
            text=" ".join(_finding_text(x) for x in grouped),
            evidence={
                "file": file_key,
                "function": fn,
                "finding_count": len(grouped),
            },
        ))

    for route in api_bom:
        route_id = str(route.get("route") or route.get("path") or route.get("endpoint") or "api_route")
        method = route.get("method")

        control_findings.extend(_detect_controls(
            context_id=f"{method or ''} {route_id}".strip(),
            context_type="API_ROUTE",
            text=_collect_text(route),
            evidence={
                "route": route.get("route") or route.get("path") or route.get("endpoint"),
                "method": method,
            },
        ))

    for component in cbom:
        cid = str(component.get("algorithm") or component.get("primitive") or component.get("name") or "cbom_component")

        control_findings.extend(_detect_controls(
            context_id=cid,
            context_type="CBOM_COMPONENT",
            text=_collect_text(component),
            evidence={
                "algorithm": component.get("algorithm") or component.get("primitive"),
                "file": component.get("file"),
                "line": component.get("line"),
            },
        ))

    for agent in abom:
        aid = str(agent.get("name") or agent.get("agent") or "ai_agent")

        control_findings.extend(_detect_controls(
            context_id=aid,
            context_type="AI_AGENT",
            text=_collect_text(agent),
            evidence={
                "agent": agent.get("name") or agent.get("agent"),
                "type": agent.get("type"),
            },
        ))

    control_findings = _dedupe(control_findings)

    domains_observed = sorted({
        c.get("domain")
        for c in control_findings
        if c.get("status") == "OBSERVED" and c.get("domain")
    })

    missing_findings = _missing_control_findings(domains_observed)
    all_control_findings = control_findings + missing_findings

    observed_count = len([c for c in all_control_findings if c.get("status") == "OBSERVED"])
    not_observed_count = len([c for c in all_control_findings if c.get("status") == "NOT_OBSERVED"])

    coverage_ratio = round(
        len([d for d in domains_observed if d in REQUIRED_CONTROL_DOMAINS])
        / max(len(REQUIRED_CONTROL_DOMAINS), 1),
        2,
    )

    by_domain: Dict[str, Dict[str, Any]] = {}
    for domain in REQUIRED_CONTROL_DOMAINS:
        domain_items = [c for c in all_control_findings if c.get("domain") == domain]
        observed = [c for c in domain_items if c.get("status") == "OBSERVED"]
        not_observed = [c for c in domain_items if c.get("status") == "NOT_OBSERVED"]

        by_domain[domain] = {
            "status": "OBSERVED" if observed else "NOT_OBSERVED",
            "observed_controls": len(observed),
            "not_observed_controls": len(not_observed),
            "risk_level": "INFO" if observed else _risk_for_domain(domain),
        }

    by_context = {
        "finding_context": sum(1 for c in all_control_findings if c.get("context_type") == "FINDING"),
        "file_context": sum(1 for c in all_control_findings if c.get("context_type") == "FILE_CONTEXT"),
        "function_context": sum(1 for c in all_control_findings if c.get("context_type") == "FUNCTION_CONTEXT"),
        "api_route_context": sum(1 for c in all_control_findings if c.get("context_type") == "API_ROUTE"),
        "cbom_component_context": sum(1 for c in all_control_findings if c.get("context_type") == "CBOM_COMPONENT"),
        "ai_agent_context": sum(1 for c in all_control_findings if c.get("context_type") == "AI_AGENT"),
        "domain_coverage_context": sum(1 for c in all_control_findings if c.get("context_type") == "DOMAIN_COVERAGE"),
    }

    executive_relevant_gaps = sum(
        1 for c in all_control_findings
        if c.get("status") == "NOT_OBSERVED" and c.get("risk_level") in {"HIGH", "MEDIUM"}
    )

    required_missing = [d for d in REQUIRED_CONTROL_DOMAINS if d not in domains_observed]

    return {
        "total_controls_evaluated": len(REQUIRED_CONTROL_DOMAINS),
        "controls_observed": observed_count,
        "controls_not_observed": not_observed_count,
        "domains_observed_count": len([d for d in domains_observed if d in REQUIRED_CONTROL_DOMAINS]),
        "domains_not_observed_count": len(required_missing),
        "coverage_ratio": coverage_ratio,
        "coverage_grade": _coverage_grade(coverage_ratio),
        "defense_in_depth_status": _defense_status(coverage_ratio, len(required_missing)),
        "executive_relevant_gaps": executive_relevant_gaps,
        "domains_observed": domains_observed,
        "domains_not_observed": required_missing,
        "by_domain": by_domain,
        "by_context": by_context,
        "control_findings": all_control_findings,
        "engine_mode": "STATIC_SECURITY_CONTROL_COVERAGE_V4_MYTHOS_AUTHZ_HARDENING",
    }
