from __future__ import annotations

import re
from collections import Counter
from pathlib import Path


ENGINE_MODE = "STATIC_AUTH_HARDENING_RISK_V2_TARGET_SCAN"


WEAK_PASSWORD_PATTERNS = [
    r'password\s*=\s*["\'](123456|password|admin|root|qwerty|welcome|letmein)["\']',
    r'passwd\s*=\s*["\'](123456|password|admin|root|qwerty|welcome|letmein)["\']',
    r'pwd\s*=\s*["\'](123456|password|admin|root|qwerty|welcome|letmein)["\']',
    r'default_password\s*=\s*["\'][^"\']+["\']',
    r'hardcoded_password\s*=\s*["\'][^"\']+["\']',
]

WEAK_POLICY_PATTERNS = [
    r'min_length\s*[<:=]\s*[1-7]\b',
    r'password_length\s*[<:=]\s*[1-7]\b',
    r'allow_weak_password\s*=\s*True',
    r'password_complexity\s*=\s*False',
    r'require_special\s*=\s*False',
    r'require_digit\s*=\s*False',
    r'require_uppercase\s*=\s*False',
]

CAPTCHA_BYPASS_PATTERNS = [
    r'captcha_disabled\s*=\s*True',
    r'skip_captcha\s*=\s*True',
    r'bypass_captcha',
    r'recaptcha_enabled\s*=\s*False',
    r'hcaptcha_enabled\s*=\s*False',
]

CAPTCHA_VERIFY_PATTERNS = [
    r'verify_captcha',
    r'captcha_verify',
    r'captcha_validate',
    r'recaptcha/api/siteverify',
    r'hcaptcha.com/siteverify',
    r'turnstile/v0/siteverify',
]

LOGIN_ROUTE_PATTERNS = [
    r'@app\.route\(["\']/(login|signin|auth)',
    r'router\.(post|get)\(["\']/(login|signin|auth)',
    r'path\(["\'](login|signin|auth)',
    r'/login',
    r'/signin',
    r'/auth',
]

RATE_LIMIT_PATTERNS = [
    r'rate_limit',
    r'limiter',
    r'throttle',
    r'login_throttle',
    r'max_requests',
]

ACCOUNT_LOCKOUT_PATTERNS = [
    r'failed_attempts',
    r'failed_login_attempts',
    r'account_lockout',
    r'lock_after',
    r'max_login_attempts',
]

WEAK_RESET_TOKEN_PATTERNS = [
    r'password_reset.*md5',
    r'password_reset.*sha1',
    r'reset_token.*md5',
    r'reset_token.*sha1',
    r'reset_token\s*=\s*random\.randint',
    r'reset_token\s*=\s*random\.choice',
    r'token\s*=\s*random\.randint',
    r'token\s*=\s*random\.choice',
]

SESSION_LOGIN_PATTERNS = [
    r'login',
    r'authenticate',
    r'signin',
]

SESSION_ROTATION_PATTERNS = [
    r'regenerate_session',
    r'rotate_session',
    r'session\.regenerate',
    r'cycle_key',
    r'renew_session',
]

SCAN_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx",
    ".java", ".go", ".php", ".rb", ".cs",
    ".env", ".txt", ".json", ".yml", ".yaml",
    ".properties", ".ini", ".conf", ".cfg",
}

SPECIAL_FILENAMES = {
    ".env",
    "dockerfile",
}


def _text(obj) -> str:
    if obj is None:
        return ""
    if isinstance(obj, (dict, list, tuple, set)):
        return str(obj).lower()
    return str(obj).lower()


def _finding_text(finding: dict) -> str:
    return " ".join([
        _text(finding.get("title")),
        _text(finding.get("description")),
        _text(finding.get("snippet")),
        _text(finding.get("evidence")),
        _text(finding.get("file")),
        _text(finding.get("file_path")),
    ])


def _matches_any(text: str, patterns: list[str]) -> bool:
    return any(re.search(pattern, text, re.IGNORECASE) for pattern in patterns)


def _make(
    rule_id: str,
    title: str,
    severity: str,
    confidence: str,
    file_path: str,
    line,
    evidence: str,
):
    return {
        "rule_id": rule_id,
        "title": title,
        "severity": severity,
        "confidence": confidence,
        "file": file_path,
        "line": line,
        "evidence": evidence,
        "engine_mode": ENGINE_MODE,
        "executive_relevant": severity in {"Critical", "High"},
    }


def _target_findings(target: str | None) -> list[dict]:
    if not target:
        return []

    root = Path(target)
    if not root.exists():
        return []

    generated = []

    for path in root.rglob("*"):
        if not path.is_file():
            continue

        suffix = path.suffix.lower()
        name = path.name.lower()

        if suffix not in SCAN_EXTENSIONS and name not in SPECIAL_FILENAMES:
            continue

        try:
            lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        except Exception:
            continue

        for idx, line in enumerate(lines, start=1):
            clean = line.strip()
            if not clean:
                continue

            generated.append({
                "file": str(path),
                "line": idx,
                "title": "Auth hardening source scan",
                "snippet": clean,
                "evidence": clean,
            })

    return generated


def _has_login_surface(findings: list[dict], api_bom: list[dict]) -> bool:
    corpus = " ".join(_finding_text(f) for f in findings)
    corpus += " " + _text(api_bom)
    return _matches_any(corpus, LOGIN_ROUTE_PATTERNS)


def _has_captcha_token_without_verification(findings: list[dict]) -> list[dict]:
    suspicious = []
    for finding in findings:
        text = _finding_text(finding)
        if "captcha" in text and not _matches_any(text, CAPTCHA_VERIFY_PATTERNS):
            if not _matches_any(text, CAPTCHA_BYPASS_PATTERNS):
                suspicious.append(finding)
    return suspicious


def enrich_auth_hardening_risk(
    findings: list[dict] | None,
    api_bom: list[dict] | None = None,
    target: str | None = None,
):
    findings = list(findings or [])
    api_bom = api_bom or []

    # V2: direct source scan, so auth-hardening can work even when SAST raw findings are 0.
    findings.extend(_target_findings(target))

    indicators = []
    seen = set()

    def add(ind):
        key = (
            ind.get("rule_id"),
            str(ind.get("file") or "").replace("\\", "/").lower(),
            str(ind.get("line")),
            str(ind.get("evidence") or "")[:120].lower(),
        )
        if key in seen:
            return
        seen.add(key)
        indicators.append(ind)

    for finding in findings:
        text = _finding_text(finding)

        if _matches_any(text, WEAK_PASSWORD_PATTERNS):
            add(_make(
                "WEAK_PASSWORD_LITERAL",
                "Weak or default password detected",
                "Critical",
                "High",
                finding.get("file", ""),
                finding.get("line"),
                finding.get("snippet") or finding.get("evidence", ""),
            ))

        if _matches_any(text, WEAK_POLICY_PATTERNS):
            add(_make(
                "WEAK_PASSWORD_POLICY",
                "Weak password policy detected",
                "High",
                "Medium",
                finding.get("file", ""),
                finding.get("line"),
                finding.get("snippet") or finding.get("evidence", ""),
            ))

        if _matches_any(text, CAPTCHA_BYPASS_PATTERNS):
            add(_make(
                "CAPTCHA_BYPASSABLE_FLOW",
                "Captcha disabled or bypassable",
                "High",
                "Medium",
                finding.get("file", ""),
                finding.get("line"),
                finding.get("snippet") or finding.get("evidence", ""),
            ))

        if _matches_any(text, WEAK_RESET_TOKEN_PATTERNS):
            add(_make(
                "WEAK_PASSWORD_RESET_TOKEN",
                "Weak password reset token generation",
                "High",
                "Medium",
                finding.get("file", ""),
                finding.get("line"),
                finding.get("snippet") or finding.get("evidence", ""),
            ))

    # CAPTCHA token observed but no local verification call on same line/context.
    for finding in _has_captcha_token_without_verification(findings):
        add(_make(
            "CAPTCHA_TOKEN_NOT_VERIFIED",
            "Captcha token observed without verification evidence",
            "Medium",
            "Low",
            finding.get("file", ""),
            finding.get("line"),
            finding.get("snippet") or finding.get("evidence", ""),
        ))

    # API login routes without visible rate limiting.
    for route in api_bom:
        route_text = _text(route)

        if _matches_any(route_text, LOGIN_ROUTE_PATTERNS):
            if not _matches_any(route_text, RATE_LIMIT_PATTERNS):
                add(_make(
                    "NO_LOGIN_RATE_LIMIT",
                    "Login endpoint without visible rate limiting",
                    "High",
                    "Low",
                    route.get("file", ""),
                    route.get("line"),
                    route_text,
                ))

    # Global missing controls only if login/auth surface is observed.
    if _has_login_surface(findings, api_bom):
        corpus = " ".join(_finding_text(x) for x in findings)
        corpus += " " + _text(api_bom)

        if not _matches_any(corpus, ACCOUNT_LOCKOUT_PATTERNS):
            add(_make(
                "NO_ACCOUNT_LOCKOUT",
                "No account lockout controls observed",
                "Medium",
                "Low",
                "",
                None,
                "Login/auth surface observed, but no account lockout patterns observed",
            ))

        if not _matches_any(corpus, SESSION_ROTATION_PATTERNS):
            add(_make(
                "SESSION_NOT_ROTATED_AFTER_LOGIN",
                "Session rotation after login not observed",
                "Medium",
                "Low",
                "",
                None,
                "Login/auth surface observed, but no session rotation patterns observed",
            ))

    counts = Counter(x["severity"] for x in indicators)

    return {
        "total_auth_hardening_indicators": len(indicators),
        "critical_auth_hardening_indicators": counts.get("Critical", 0),
        "high_auth_hardening_indicators": counts.get("High", 0),
        "medium_auth_hardening_indicators": counts.get("Medium", 0),
        "executive_relevant_indicators": sum(
            1 for x in indicators if x.get("executive_relevant")
        ),
        "summary_status": (
            "AUTH_HARDENING_RISK_IDENTIFIED"
            if indicators
            else "NO_AUTH_HARDENING_RISK_IDENTIFIED"
        ),
        "indicators": indicators,
        "engine_mode": ENGINE_MODE,
    }