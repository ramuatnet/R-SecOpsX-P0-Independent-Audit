"""analysis/data_flow_correlation_engine.py
Enterprise correlation for IDOR/BOLA, tenant isolation, privilege escalation and workflow bypass.
Backward-compatible APIs:
- correlate_data_flows(payload_or_findings)
- analyze_data_flow_correlation(payload_or_findings)
- correlate_data_flow(findings)
"""
from __future__ import annotations
from collections import Counter, defaultdict

OBJ_ACCESS = {"findById","findOne","getById","repository","repo.","db.","execute","query","select","Model.find","EntityManager"}
AUTH_WORDS = {"authorize","isAuthorized","hasPermission","hasRole","@PreAuthorize","RequireAuthorization","[Authorize]","auth","permission","tenant"}
PRIV_FIELDS = {"role","roles","isAdmin","admin","permission","permissions","privilege","is_superuser","tenantId","tenant_id"}
WORKFLOW_WORDS = {"approval","approved","skip_approval","auto_approve","payment","transfer","coupon","redeem","otp","reset"}

def _severity(kind):
    return "Critical" if kind in {"privilege_escalation","workflow_bypass"} else "High"
def _priority(sev): return {"Critical":"P1","High":"P2","Medium":"P3","Low":"P4"}.get(sev,"P3")

def _norm_file(f): return f.get("file") or f.get("file_path") or f.get("full_path") or ""
def _near(a,b,dist=25):
    try: return _norm_file(a)==_norm_file(b) and abs(int(a.get("line",0))-int(b.get("line",0)))<=dist
    except Exception: return False

def _mk(kind,title,findings,evidence_note):
    base=findings[0] if findings else {}
    sev=_severity(kind)
    return {"rule_id":f"CORR_{kind.upper()}","title":title,"vuln_type":kind,"severity":sev,"priority":_priority(sev),"confidence":"High" if len(findings)>1 else "Medium","language":base.get("language","unknown"),"file":_norm_file(base),"line":base.get("line",0),"snippet":base.get("snippet",""),"description":evidence_note,"remediation":["Enforce object-level authorization before repository/database access.","Validate tenant ownership in every data access path.","Use centralized authorization guards and regression tests.","Make workflow state transitions atomic and server-side enforced."],"owasp":"A01:2021 - Broken Access Control","cwe":"CWE-639","evidence":" | ".join(f"{_norm_file(f)}:{f.get('line')}:{f.get('title')}" for f in findings[:4]),"detection":"Data Flow Correlation","engine":"analysis.data_flow_correlation_engine","correlation_type":kind,"correlated_findings":findings,"group_key":f"CORR_{kind.upper()}|{_norm_file(base)}|{base.get('line',0)}","enterprise_control":True}

def correlate_data_flows(payload_or_findings):
    if isinstance(payload_or_findings, dict):
        findings = payload_or_findings.get("findings") or payload_or_findings.get("deduped_findings") or []
    else:
        findings = payload_or_findings or []
    correlations=[]
    by_file=defaultdict(list)
    for f in findings: by_file[_norm_file(f)].append(f)
    for file, fs in by_file.items():
        fs_sorted=sorted(fs, key=lambda x:int(x.get("line",0) or 0))
        for f in fs_sorted:
            text=" ".join(str(f.get(k,"")) for k in ("title","vuln_type","snippet","description","taint_path","source_expr","sink_call"))
            if any(x in text for x in ("id","Id","ID","args.id","user_id","tenant_id","tenantId")) and any(x in text for x in OBJ_ACCESS):
                has_auth=any(any(w in " ".join(str(g.get(k,"")) for k in ("snippet","title","description")) for w in AUTH_WORDS) for g in fs_sorted if _near(f,g,20))
                if not has_auth:
                    correlations.append(_mk("idor_bola","IDOR / BOLA: User-Controlled Object ID Reaches Data Access",[f],"User-controlled object identifier appears to reach repository/database access without nearby authorization guard."))
            if any(x in text for x in ("tenantId","tenant_id","org_id","organizationId")) and any(x in text for x in OBJ_ACCESS):
                correlations.append(_mk("tenant_isolation_failure","Tenant Isolation Failure Correlation",[f],"Tenant identifier is present in data access flow; verify tenant ownership is enforced before object access."))
            if any(p in text for p in PRIV_FIELDS) and any(src in text for src in ("req.","request.","body","params","@RequestBody","FromBody","$_POST")):
                correlations.append(_mk("privilege_escalation","Privilege Escalation via User-Controlled Role/Permission",[f],"User-controlled role/permission/tenant field may influence privileged state."))
            if any(w in text for w in WORKFLOW_WORDS) and any(w in text for w in ("skip","auto","approved","redeem","payment","transfer","reset")):
                correlations.append(_mk("workflow_bypass","Workflow / Approval / Duplicate Action Bypass",[f],"Workflow-sensitive action appears without clear server-side approval/idempotency enforcement."))
        # Pair taint flows with auth weaknesses nearby
        auth_gaps=[f for f in fs_sorted if str(f.get("vuln_type","")).lower() in {"auth_misconfiguration","missing_authorization","idor","mass_assignment"}]
        data_flows=[f for f in fs_sorted if f.get("taint_path") or str(f.get("detection","")).lower().find("taint")>=0]
        for a in auth_gaps:
            for d in data_flows:
                if _near(a,d,40):
                    correlations.append(_mk("authorization_missing_before_object_access","Authorization Missing Before Object Access",[a,d],"Authorization weakness correlates with tainted data/object access in the same file region.")); break
    # de-duplicate
    seen=set(); out=[]
    for c in correlations:
        k=c.get("group_key")+"|"+c.get("correlation_type","")
        if k not in seen:
            seen.add(k); out.append(c)
    summary=summarize_data_flow_correlation(out)
    if isinstance(payload_or_findings, dict):
        payload_or_findings["data_flow_correlations"] = out
        payload_or_findings["data_flow_correlation_summary"] = summary
        return payload_or_findings
    return out

def correlate_data_flow(findings): return correlate_data_flows(findings)
def analyze_data_flow_correlation(payload_or_findings): return correlate_data_flows(payload_or_findings)

def summarize_data_flow_correlation(correlations):
    return {"total_correlated":len(correlations),"critical":sum(1 for c in correlations if c.get("severity")=="Critical"),"high":sum(1 for c in correlations if c.get("severity")=="High"),"by_type":dict(Counter(c.get("correlation_type","unknown") for c in correlations)),"summary_status":"DATA_FLOW_CORRELATION_IDENTIFIED" if correlations else "NO_DATA_FLOW_CORRELATION_IDENTIFIED"}

if __name__=="__main__":
    import json, sys
    data=json.load(open(sys.argv[1],encoding="utf-8")) if len(sys.argv)>1 else []
    print(json.dumps(correlate_data_flows(data), indent=2))


def enrich_data_flow_correlation(findings: list[dict], api_bom=None, abom=None) -> dict:
    """
    Backward-compatible wrapper expected by main.py.
    Always returns a dict summary, even if older correlation function returns a list.
    """
    api_bom = api_bom or []
    abom = abom or []

    result = None

    if "correlate_data_flows" in globals():
        try:
            result = correlate_data_flows(findings, api_bom=api_bom, abom=abom)
        except TypeError:
            try:
                result = correlate_data_flows(findings)
            except TypeError:
                result = None

    if result is None and "analyze_data_flow_correlation" in globals():
        try:
            result = analyze_data_flow_correlation(findings, api_bom=api_bom, abom=abom)
        except TypeError:
            try:
                result = analyze_data_flow_correlation(findings)
            except TypeError:
                result = None

    if isinstance(result, dict):
        result.setdefault("total_correlated_flows", len(result.get("correlated_flows", [])))
        result.setdefault("critical_correlated_flows", 0)
        result.setdefault("high_correlated_flows", 0)
        result.setdefault("confirmed_flows", 0)
        result.setdefault("fallback_candidate_flows", 0)
        result.setdefault("by_context", {"file_context": 0, "function_context": 0})
        result.setdefault("correlation_confidence", "MIXED_OR_CONTEXTUAL")
        result.setdefault("correlation_mode", "STATIC_CONTEXT_SOURCE_SINK_CORRELATION_V2_WITH_FILE_FALLBACK")
        result.setdefault("correlation_status", "DATA_FLOW_CORRELATION_IDENTIFIED")
        return result

    if isinstance(result, list):
        correlations = result
    else:
        correlations = []

        for finding in findings or []:
            title = str(finding.get("title", "")).lower()
            vuln_type = str(finding.get("vuln_type", "")).lower()

            if any(x in title or x in vuln_type for x in [
                "idor",
                "bola",
                "tenant",
                "privilege",
                "authorization",
                "object id",
                "repository",
                "database",
                "workflow bypass",
            ]):
                correlations.append({
                    "rule_id": "DATA_FLOW_CONTEXTUAL_AUTHZ_CORRELATION",
                    "title": "Contextual Authorization/Data Flow Correlation",
                    "severity": finding.get("severity", "High"),
                    "priority": finding.get("priority", "P2"),
                    "confidence": finding.get("confidence", "Medium"),
                    "file": finding.get("file"),
                    "line": finding.get("line"),
                    "snippet": finding.get("snippet"),
                    "description": "Potential user-controlled object or authorization-sensitive data flow reaches a sensitive access path.",
                    "remediation": "Validate object ownership and tenant boundary before repository, database, or workflow access.",
                    "owasp": "A01:2021 - Broken Access Control",
                    "cwe": "CWE-639",
                    "evidence": finding.get("evidence") or finding.get("snippet"),
                    "detection": "Static Data Flow Correlation",
                    "engine": "analysis.data_flow_correlation_engine",
                    "context": "file_context",
                })

    critical = sum(
        1 for c in correlations
        if str(c.get("severity", "")).lower() == "critical"
    )
    high = sum(
        1 for c in correlations
        if str(c.get("severity", "")).lower() == "high"
    )

    return {
        "total_correlated_flows": len(correlations),
        "critical_correlated_flows": critical,
        "high_correlated_flows": high,
        "confirmed_flows": 0,
        "fallback_candidate_flows": len(correlations),
        "by_context": {
            "file_context": len(correlations),
            "function_context": 0,
        },
        "correlated_flows": correlations,
        "correlation_confidence": "MIXED_OR_CONTEXTUAL",
        "correlation_mode": "STATIC_CONTEXT_SOURCE_SINK_CORRELATION_V2_WITH_FILE_FALLBACK",
        "correlation_status": (
            "DATA_FLOW_CORRELATION_IDENTIFIED"
            if correlations else "NO_DATA_FLOW_CORRELATION_IDENTIFIED"
        ),
    }