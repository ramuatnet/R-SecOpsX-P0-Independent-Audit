from __future__ import annotations

from collections import Counter

from core.license_catalog import (
    normalize_license,
    license_risk,
    license_policy_decision,
    requires_notice,
)


def enrich_license_policy(sbom: list[dict]) -> list[dict]:
    enriched = []

    for pkg in sbom:
        item = dict(pkg)

        license_id = normalize_license(
            item.get("license")
            or item.get("declared_license")
            or item.get("concluded_license")
        )

        risk, issue, reason = license_risk(license_id)
        decision = license_policy_decision(risk, issue)

        item["normalized_license"] = license_id
        item["license_risk"] = risk
        item["license_issue"] = issue
        item["license_policy_decision"] = decision
        item["license_reason"] = reason
        item["license_notice_required"] = requires_notice(license_id)
        item["license_policy_method"] = "RULE_BASED_LICENSE_POLICY_V1"

        enriched.append(item)

    return enriched


def license_policy_summary(sbom: list[dict]) -> dict:
    risk_counter = Counter()
    decision_counter = Counter()
    license_counter = Counter()
    issue_counter = Counter()

    total = 0
    notice_required = 0
    legal_review_required = 0
    unknown_license = 0

    for pkg in sbom:
        total += 1

        risk = pkg.get("license_risk", "UNKNOWN")
        decision = pkg.get("license_policy_decision", "UNKNOWN")
        license_id = pkg.get("normalized_license") or normalize_license(pkg.get("license"))
        issue = pkg.get("license_issue", "UNKNOWN")

        risk_counter[risk] += 1
        decision_counter[decision] += 1
        license_counter[license_id] += 1
        issue_counter[issue] += 1

        if pkg.get("license_notice_required"):
            notice_required += 1

        if decision == "LEGAL_REVIEW_REQUIRED":
            legal_review_required += 1

        if license_id == "UNKNOWN":
            unknown_license += 1

    if total == 0:
        summary_status = "NO_SBOM_COMPONENTS"
    elif unknown_license <= 5:
        summary_status = "PASS_WITH_MANUAL_REVIEW"
    elif unknown_license > 300:
        summary_status = "LICENSE_INTELLIGENCE_INCOMPLETE"
    elif unknown_license > 50:
        summary_status = "LICENSE_CATALOG_GAP"
    else:
        summary_status = "RULE_BASED_LICENSE_POLICY_V1"

    return {
        "total_components": total,
        "risk_counts": dict(risk_counter),
        "decision_counts": dict(decision_counter),
        "license_counts": dict(license_counter),
        "issue_counts": dict(issue_counter),
        "notice_required_components": notice_required,
        "legal_review_required_components": legal_review_required,
        "unknown_license_components": unknown_license,
        "summary_status": summary_status,
    }

if __name__ == "__main__":
    import json

    sample = [
        {"name": "safe-lib", "version": "1.0.0", "license": "MIT"},
        {"name": "apache-lib", "version": "2.0.0", "license": "Apache-2.0"},
        {"name": "gpl-lib", "version": "3.0.0", "license": "GPL-3.0"},
        {"name": "agpl-lib", "version": "3.0.0", "license": "AGPL-3.0"},
        {"name": "unknown-lib", "version": "0.1.0", "license": "unknown"},
    ]

    enriched = enrich_license_policy(sample)
    print(json.dumps(enriched, indent=2))
    print(json.dumps(license_policy_summary(enriched), indent=2))