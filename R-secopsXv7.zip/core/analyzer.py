"""
core/analyzer.py  v5

CHANGES (v4 → v5):
  1. FIX  — _root_cause_key() now uses finding['group_key'] when present
             (set by sast.py v5 as vuln_type|line|snippet).  This correctly
             merges cmd_0.py…cmd_9.py — 10 files with identical code at
             line 4 — into ONE finding with 10 affected_files entries.
             Falls back to v4 per-function key when group_key is absent
             (preserves compatibility with taint_engine output).
  2. KEEP — All v4 fixes retained: _safe_float, non-mutating score_finding,
             confidence swap, SBOM scoring, pivot point analysis.
"""
from __future__ import annotations

import hashlib
from datetime import datetime
from typing import Any

from core.mapper import get_owasp_summary, get_mitre_summary
from core.config import TOOL_FULL, RISK_MODEL
from core.risk_scorer import score_finding, compute_portfolio_score, SCORING_MODEL_DESCRIPTION
from core.attack_graph import get_attack_paths, get_pivot_points
from reporting.report_mappings import (
    BUSINESS_IMPACT_BY_RULE,
    REMEDIATION_BY_RULE,
    MITRE_BY_RULE,
    CONFIG_CRITICAL_RULES,
    rule_key as _report_rule_key,
    needs_business_impact_replacement as _needs_bi_replace,
    needs_remediation_replacement as _needs_rem_replace,
)

SEVERITY_ORDER  = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}
PRIORITY_MAP    = {"Critical": "P1", "High": "P2", "Medium": "P3", "Low": "P4", "Info": "P4"}
CONFIDENCE_RANK = {"High": 3, "Medium": 2, "Low": 1, "": 0}


def _occurrence_from_finding(f: dict) -> dict:
    """Preserve per-occurrence path metadata before report path normalization."""
    return {
        "file": f.get("file") or f.get("file_path") or f.get("full_path") or "",
        "line": f.get("line"),
        "snippet": f.get("snippet", ""),
        "full_path": f.get("full_path") or f.get("file") or f.get("file_path") or "",
        "file_path": f.get("file_path") or f.get("file") or "",
        "file_name": str(f.get("file_name") or ""),
    }


def _safe_float(v, default: float = 0.0) -> float:
    try:    return float(v)
    except: return default


def _path_fp(f: dict) -> str:
    """Strict per-file fingerprint — used only for exact-duplicate removal."""
    key = f"{f.get('vuln_type')}|{f.get('file')}|{f.get('line')}"
    return hashlib.md5(key.encode()).hexdigest()


def _normalise_sink(snippet: str, vuln_type: str) -> str:
    """
    Extract the canonical sink name from a code snippet for cross-file deduplication.
    Handles both function-call sinks (eval, subprocess.run) and
    IaC declarative patterns (privileged: true, acl = "public-read").
    """
    import re

    # IaC declarative patterns — use the vuln_type itself as the sink key
    IAC_TYPES = {
        "iac_privileged_container": "privileged_container",
        "iac_public_s3":            "public_s3_acl",
        "iac_open_security_group":  "open_cidr_0000",
    }
    if vuln_type in IAC_TYPES:
        return IAC_TYPES[vuln_type]

    # PATCH 5: hardcoded secrets — normalise to category so AWS keys from
    # 10 different files merge into ONE root cause regardless of variable name.
    if vuln_type == "hardcoded_secret":
        snip_lower = snippet.lower()
        # AWS key patterns — group all AKIA-pattern credentials
        if "akia" in snip_lower or "akid" in snip_lower:
            return "hardcoded_secret|aws_access_key"
        if "private key" in snip_lower or "begin rsa" in snip_lower or "begin ec" in snip_lower:
            return "hardcoded_secret|private_key"
        if "jwt" in snip_lower:
            return "hardcoded_secret|jwt_secret"
        # Generic API keys — group ALL together regardless of file type (yaml/py/env)
        # This ensures config.yaml and sec_0.py generic keys merge into one finding
        return "hardcoded_secret|generic_credential"

    # IDOR — normalise to generic "idor_access" so all IDOR patterns group together
    if vuln_type == "api_idor":
        return "idor_access"

    # Supply chain — group by the typo package name
    if vuln_type == "supply_chain_typosquat":
        m = re.search(r"import\s+(\w+)|from\s+(\w+)", snippet)
        return m.group(1) or m.group(2) if m else "typosquat"

    # Known function-call sinks
    SINK_NAMES = [
        "subprocess.run", "subprocess.call", "subprocess.Popen",
        "os.system", "os.popen",
        "eval", "exec", "compile",
        "pickle.loads", "pickle.load", "yaml.load", "marshal.loads",
        "requests.get", "requests.post", "requests.put", "requests.delete",
        "urllib.request.urlopen", "http.client",
        "conn.execute", "cursor.execute", "executemany",
        "open", "os.path.join", "os.listdir",
        "redirect", "render_template_string",
        "innerHTML", "document.write",
        "jwt.decode",
    ]
    for sink in SINK_NAMES:
        if sink in snippet:
            return sink

    # Fallback: first word that looks like a function call
    m = re.search(r'(\w+(?:\.\w+)*)\s*\(', snippet)
    return m.group(1) if m else snippet.strip()[:40]


def _root_cause_key(f: dict) -> str:
    """
    Use scanner-provided group_key when available.
    This preserves intentional grouping from scanner/sast.py, including
    enterprise connection-string grouping by rule_id and snippet.
    """
    if f.get("group_key"):
        return str(f.get("group_key"))

    vt      = f.get("vuln_type", "")
    snippet = (f.get("snippet") or "").strip()
    sink    = _normalise_sink(snippet, vt)
    return f"{vt}|{sink}"


# ---------------------------------------------------------------------------
# Deduplication  (logic identical to v4; key function updated above)
# ---------------------------------------------------------------------------

def deduplicate(findings: list[dict]) -> list[dict]:
    # Level 1: exact per-file dedupe
    # When two findings share the same fingerprint (same file+line+vuln),
    # keep the one with the richer detection — TAINT-VALIDATED > Regex.
    seen_exact: dict[str, int] = {}  # fp -> index in phase1
    phase1: list[dict] = []
    for f in findings:
        fp = _path_fp(f)
        if fp not in seen_exact:
            seen_exact[fp] = len(phase1)
            phase1.append(f)
        else:
            existing_idx = seen_exact[fp]
            existing     = phase1[existing_idx]

            # Part 5+6: Conflict resolution — same line, different vuln_type
            # HTTP sink → SSRF wins; remove IDOR classification
            e_vt = existing.get("vuln_type", "")
            f_vt = f.get("vuln_type", "")
            e_sc = existing.get("sink_category", "")
            f_sc = f.get("sink_category", "")

            # Issue 4 FIX: generic rule — sink_category="http" → SSRF wins.
            # Handles SSRF vs IDOR and any future http-sink misclassification.
            both_cats = {e_sc, f_sc}
            if "http" in both_cats or {e_vt, f_vt} == {"ssrf", "api_idor"}:
                # Keep whichever is SSRF; discard IDOR or non-SSRF http finding
                if f_vt == "ssrf" or f_sc == "http":
                    phase1[existing_idx] = f
                # else existing is already the right one (ssrf or http)
                continue

            # Upgrade to TAINT-VALIDATED when incoming has real taint path
            if (f.get("detection") == "TAINT-VALIDATED"
                    and existing.get("detection") != "TAINT-VALIDATED"):
                phase1[existing_idx] = f

    # Level 2: root-cause grouping
    groups: dict[str, dict] = {}
    for f in phase1:
        rck = _root_cause_key(f)
        if rck not in groups:
            entry = dict(f)
            entry["occurrences"]    = [_occurrence_from_finding(f)]
            entry["affected_files"] = [f.get("file", "")]
            entry["instances"]      = 1
            groups[rck] = entry
        else:
            existing      = groups[rck]
            incoming_rank = CONFIDENCE_RANK.get(f.get("confidence", ""), 0)
            existing_rank = CONFIDENCE_RANK.get(existing.get("confidence", ""), 0)

            if incoming_rank > existing_rank:
                occ_bak  = existing["occurrences"]
                aff_bak  = existing["affected_files"]
                inst_bak = existing["instances"]
                groups[rck]                   = dict(f)
                groups[rck]["occurrences"]    = occ_bak
                groups[rck]["affected_files"] = aff_bak
                groups[rck]["instances"]      = inst_bak

            occ = _occurrence_from_finding(f)
            # Issue 4: dedup by (file, line) — same location from regex + fallback
            # must not create two entries in the occurrence list
            _seen_locs = {(o["file"], o["line"]) for o in groups[rck]["occurrences"]}
            if (occ["file"], occ["line"]) not in _seen_locs:
                groups[rck]["occurrences"].append(occ)
            fp_path = f.get("file", "")
            if fp_path and fp_path not in groups[rck]["affected_files"]:
                groups[rck]["affected_files"].append(fp_path)
            groups[rck]["instances"] = len(groups[rck]["occurrences"])
            # Belt-and-suspenders: keep affected_files unique after every merge step
            groups[rck]["affected_files"] = list(dict.fromkeys(groups[rck]["affected_files"]))

            # Fix 1: promote detection label — TAINT-VALIDATED beats regex
            incoming_det = f.get("detection", "")
            existing_det = groups[rck].get("detection", "")
            if incoming_det == "TAINT-VALIDATED" and existing_det != "TAINT-VALIDATED":
                groups[rck]["detection"] = "TAINT-VALIDATED"
                # also carry over the real taint_path if current one is empty
                if f.get("taint_path") and "->" in str(f.get("taint_path", "")):
                    if not groups[rck].get("taint_path") or "->" not in str(groups[rck].get("taint_path", "")):
                        groups[rck]["taint_path"] = f["taint_path"]

            # Fix 2: for secrets, promote to highest severity among occurrences
            if f.get("vuln_type") == "hardcoded_secret":
                sev_rank = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1, "Info": 0}
                incoming_sev = f.get("severity", "Medium")
                existing_sev  = groups[rck].get("severity", "Medium")
                if sev_rank.get(incoming_sev, 0) > sev_rank.get(existing_sev, 0):
                    groups[rck]["severity"] = incoming_sev
                    groups[rck]["priority"] = {
                        "Critical":"P1","High":"P2","Medium":"P3","Low":"P4"
                    }.get(incoming_sev, "P3")

    return list(groups.values())


# ---------------------------------------------------------------------------
# Enrichment
# ---------------------------------------------------------------------------

def _compute_exploitability(f: dict, sbom: list | None = None) -> str:
    """
    Issue 6 FIX: derive exploitability from taint evidence, EPSS, and context.
    Priority: taint trace > EPSS from related SBOM > heuristic.
    """
    # Taint-confirmed data flow = highest exploitability
    taint = f.get("taint_path", "")
    if taint and "->" in taint:
        return "High"
    # EPSS-based: if a related SBOM CVE has EPSS > 0.5 → High
    if sbom:
        vt = f.get("vuln_type","")
        for pkg in sbom:
            epss = float(pkg.get("epss") or 0)
            if epss >= 0.5 and pkg.get("reachable"):
                # Log4Shell EPSS=0.975, Spring4Shell=0.970 → override to High
                if vt in ("insecure_deserialization","command_injection","code_injection"):
                    return "High"
    # Source-name heuristic
    source = f.get("source_expr", "") or ""
    if any(s in source.lower() for s in ("request", "input", "argv", "form", "query", "param")):
        return "Medium"
    return f.get("exploitability") or "Low"


def _compute_exploitability_legacy(f: dict) -> str:
    """
    Determine exploitability based on evidence quality:
      HIGH   — real taint path confirms user-controlled data reaches the sink
      MEDIUM — source name suggests user input but flow is not fully traced
      LOW    — pattern match only, no user-input evidence
    """
    taint = f.get("taint_path", "")
    if taint and "->" in taint:
        return "High"
    source = f.get("source_expr", "") or ""
    if any(s in source.lower() for s in ("request", "input", "argv", "form", "query", "param")):
        return "Medium"
    # Fall back to mapper value if available, else Low
    return f.get("exploitability") or "Low"



def _is_blankish(value) -> bool:
    text = str(value or "").strip().lower()
    return text in {"", "none", "null", "n/a", "na", "not applicable", "unknown"}



def _infer_engine_name(f: dict) -> str:
    """Correct accidental engine overwrite while preserving true scanner source."""
    existing = str(f.get("engine") or "").strip()
    title = str(f.get("title") or "").lower()
    rid = str(f.get("rule_id") or "").lower()
    vt = str(f.get("vuln_type") or "").lower()
    detection = str(f.get("detection") or "").lower()

    secret_tokens = ("secret", "credential", "password", "token", "api key", "connection string", "private key")
    is_secret = vt in {"hardcoded_secret", "secret_exposure", "jwt_secret", "connection_string", "oauth_client_secret", "database_connection_string"} or any(x in title for x in secret_tokens)

    # Only trust scanner.secret_intelligence for real secret findings. Older patches
    # accidentally stamped every finding with scanner.secret_intelligence.
    if existing == "scanner.secret_intelligence" and not is_secret:
        existing = ""

    if existing:
        return existing
    if f.get("taint_path") and "->" in str(f.get("taint_path")):
        return "scanner.taint_engine"
    if "taint" in detection:
        return "scanner.taint_engine"
    if "api_abuse" in rid or "rate limit" in title or vt in {"api_rate_limit", "api_abuse_missing_rate_limit"}:
        return "analysis.api_abuse_risk_engine"
    if any(x in vt or x in rid or x in title for x in ["idor", "bola", "tenant", "workflow", "privilege_escalation"]):
        return "analysis.data_flow_correlation_engine"
    if any(x in title or x in rid for x in ["spring", "asp.net", "graphql", "express", "webflux", "actuator"]):
        return "analysis.framework_enrichment_engine" if "framework" in detection else "scanner.sast"
    if is_secret:
        return "scanner.secret_intelligence"
    if any(x in detection for x in ["sast", "pattern", "regex"]):
        return "scanner.sast"
    return "scanner.sast"

_COMPLIANCE_BY_VULN = {
    "mass_assignment": {"pci_dss":"Req 6.2.4 / Req 7 - Access control", "nist":"AC-3 / SI-10", "nist_800_53":"AC-3 / SI-10", "iso27001":"A.9.4.1 / A.14.2.5", "iso_27001":"A.9.4.1 / A.14.2.5", "soc2":"CC6.1 / CC6.6"},
    "xxe": {"pci_dss":"Req 6.2.4 - Prevent XML external entity attacks", "nist":"SI-10 / SC-7", "nist_800_53":"SI-10 / SC-7", "iso27001":"A.14.2.5 / A.13.1.1", "iso_27001":"A.14.2.5 / A.13.1.1", "soc2":"CC6.6 / CC7.2"},
    "path_traversal": {"pci_dss":"Req 6.2.1 - Protect all system components", "nist":"AC-3", "nist_800_53":"AC-3", "iso27001":"A.9.4.1", "iso_27001":"A.9.4.1", "soc2":"CC6.1"},
    "open_redirect": {"pci_dss":"Req 6.2.4 - Prevent redirect attacks", "nist":"SC-23", "nist_800_53":"SC-23", "iso27001":"A.14.2.5", "iso_27001":"A.14.2.5", "soc2":"CC6.6"},
    "race_condition": {"pci_dss":"Req 6.2.4 - Secure transaction processing", "nist":"SI-10 / AC-3", "nist_800_53":"SI-10 / AC-3", "iso27001":"A.8.28 / A.8.29", "iso_27001":"A.8.28 / A.8.29", "soc2":"CC7.2 / CC6.6"},
    "resource_exhaustion": {"pci_dss":"Req 6.2.4 / Req 8 - Abuse prevention", "nist":"AC-7 / SC-5 / SI-10", "nist_800_53":"AC-7 / SC-5 / SI-10", "iso27001":"A.8.16 / A.8.20", "iso_27001":"A.8.16 / A.8.20", "soc2":"CC7.2 / CC6.6"},
    "tls_bypass": {"pci_dss":"Req 4.2 / Req 6.2.4 - Protect transmission and prevent insecure crypto", "nist":"SC-8 / SC-13 / SI-10", "nist_800_53":"SC-8 / SC-13 / SI-10", "iso27001":"A.8.24 / A.8.20", "iso_27001":"A.8.24 / A.8.20", "soc2":"CC6.7 / CC6.6"},
    "api_rate_limit": {"pci_dss":"Req 6.2.4 / Req 8 - Abuse prevention and authentication controls", "nist":"AC-7 / SC-5 / SI-10", "nist_800_53":"AC-7 / SC-5 / SI-10", "iso27001":"A.8.16 / A.8.20", "iso_27001":"A.8.16 / A.8.20", "soc2":"CC7.2 / CC6.6"},
    "api_abuse_missing_rate_limit": {"pci_dss":"Req 6.2.4 / Req 8 - Abuse prevention and authentication controls", "nist":"AC-7 / SC-5 / SI-10", "nist_800_53":"AC-7 / SC-5 / SI-10", "iso27001":"A.8.16 / A.8.20", "iso_27001":"A.8.16 / A.8.20", "soc2":"CC7.2 / CC6.6"},
}

def _apply_compliance_fallbacks(f: dict) -> None:
    vt = str(f.get("vuln_type") or "").lower()
    title = str(f.get("title") or "").lower()
    if vt not in _COMPLIANCE_BY_VULN:
        if "mass assignment" in title or "overposting" in title:
            vt = "mass_assignment"
        elif "xxe" in title or "dtd" in title:
            vt = "xxe"
        elif "rate limit" in title:
            vt = "api_rate_limit"
    for k, v in _COMPLIANCE_BY_VULN.get(vt, {}).items():
        if _is_blankish(f.get(k)):
            f[k] = v


def _infer_detection_label(f: dict) -> str:
    """Stable report-facing detection label. Never allow Not Applicable."""
    existing = f.get("detection")
    if not _is_blankish(existing):
        if str(existing).strip() == "AST Taint Analysis":
            return "TAINT-VALIDATED"
        return str(existing).strip()

    engine = str(f.get("engine") or "").lower()
    vt = str(f.get("vuln_type") or f.get("rule_id") or "").lower()
    title = str(f.get("title") or "").lower()

    if f.get("taint_path") and "->" in str(f.get("taint_path")):
        return "TAINT-VALIDATED"
    if "taint" in engine:
        return "Enterprise Source-to-Sink Heuristic"
    if "framework" in engine:
        return "Framework-Aware Static Enrichment"
    if "api_abuse" in engine or "api abuse" in title or "rate limit" in title:
        return "API Abuse Heuristic"
    if "data_flow" in engine or "idor" in vt or "tenant" in vt or "workflow" in vt:
        return "Data Flow Correlation"
    if "kubernetes" in engine or vt.startswith("k8s"):
        return "Kubernetes IaC Static Analysis"
    if "terraform" in engine or vt.startswith("tf"):
        return "Terraform IaC Static Analysis"
    if "docker" in engine or vt.startswith("docker"):
        return "Dockerfile IaC Static Analysis"
    if "secret" in engine or "secret" in vt:
        return "Enterprise Secret Intelligence"
    if "llm" in engine or "llm" in vt or "llm" in title:
        return "LLM Security Heuristic"
    return "Enterprise SAST Pattern"


def _infer_owasp_value(f: dict) -> str:
    """Preserve/infer OWASP category instead of allowing summary collapse to Unknown/A08."""
    existing = f.get("owasp") or f.get("owasp_top10_2021")
    if not _is_blankish(existing):
        if isinstance(existing, list):
            return str(existing[0]) if existing else "A05:2021 - Security Misconfiguration"
        return str(existing)
    text = " ".join(str(f.get(k, "")) for k in ("title", "vuln_type", "rule_id", "cwe", "description", "snippet")).lower()
    if "llm" in text or "prompt" in text:
        return "LLM02:2025 - Sensitive Information Disclosure / Insecure Output Handling"
    if any(x in text for x in ["sql", "injection", "exec", "eval", "spel", "command", "template"]):
        return "A03:2021 - Injection"
    if any(x in text for x in ["deserialization", "serialize", "objectinputstream", "binaryformatter", "typenamehandling", "phar", "xstream", "snakeyaml"]):
        return "A08:2021 - Software and Data Integrity Failures"
    if any(x in text for x in ["ssrf", "server-side request forgery"]):
        return "A10:2021 - Server-Side Request Forgery"
    if any(x in text for x in ["csrf", "idor", "bola", "mass assignment", "overposting", "open redirect", "tenant", "privilege", "workflow"]):
        return "A01:2021 - Broken Access Control"
    if any(x in text for x in ["tls", "insecureskipverify", "trustmanager", "hostnameverifier", "md5", "sha-1", "crypto"]):
        return "A02:2021 - Cryptographic Failures"
    if any(x in text for x in ["actuator", "xxe", "dtd", "misconfiguration", "exposed", "debug"]):
        return "A05:2021 - Security Misconfiguration"
    if any(x in text for x in ["redos", "rate limit", "resource exhaustion", "readall"]):
        return "API4:2023 - Unrestricted Resource Consumption"
    return "A05:2021 - Security Misconfiguration"


def _owasp_id_and_category(value: str) -> tuple[str, str]:
    text = str(value or "").strip()
    if not text:
        return "Unknown", "Unknown"
    if ":" in text:
        oid, rest = text.split(":", 1)
        oid = oid.strip()
        return oid, f"{oid}:{rest.strip()}"
    return text.split()[0], text


def _build_owasp_summary(findings: list[dict]) -> dict:
    out: dict[str, dict] = {}
    for f in findings:
        val = _infer_owasp_value(f)
        oid, cat = _owasp_id_and_category(val)
        out.setdefault(oid, {"category": cat, "count": 0})
        out[oid]["count"] += 1
    return out


def _build_mitre_summary(findings: list[dict]) -> list[dict]:
    descriptions = {
        "T1059": "Command and Scripting Interpreter",
        "T1190": "Exploit Public-Facing Application",
        "T1566": "Phishing",
        "T1083": "File and Directory Discovery",
        "T1189": "Drive-by Compromise",
        "T1552": "Unsecured Credentials",
        "T1600": "Weaken Encryption",
        "T1203": "Exploitation for Client Execution",
        "T1557": "Adversary-in-the-Middle",
        "T1068": "Exploitation for Privilege Escalation",
        "T1195": "Supply Chain Compromise",
    }
    seen = []
    for f in findings:
        val = f.get("mitre") or f.get("mitre_attack")
        vals = val if isinstance(val, list) else [val]
        for v in vals:
            tid = str(v or "").strip()
            if not tid or tid.lower() in {"none", "not applicable", "n/a", "na"}:
                continue
            if tid not in seen:
                seen.append(tid)
    return [{"id": tid, "description": descriptions.get(tid, "Mapped ATT&CK technique")} for tid in seen]

def enrich_finding(f: dict) -> dict:
    f = dict(f)
    f["detection"] = _infer_detection_label(f)
    f["owasp"] = _infer_owasp_value(f)
    f["engine"] = _infer_engine_name(f)
    _apply_compliance_fallbacks(f)

    # Final scanner coverage credibility adjustments.
    # 1) TLS bypass is High by default unless exposure/prod/auth context proves Critical.
    rid_title = " ".join(str(f.get(k, "")) for k in ("rule_id", "title", "vuln_type", "snippet")).lower()
    if f.get("vuln_type") == "tls_bypass" and f.get("severity") == "Critical":
        ctx = " ".join(str(f.get(k, "")) for k in ("file", "snippet", "description", "evidence")).lower()
        if not any(x in ctx for x in ["prod", "production", "internet", "public", "payment", "auth", "token", "credential"]):
            f["severity"] = "High"
            f["priority"] = "P2"

    # 2) Language/rule-specific business impact to prevent cross-language leakage.
    if _needs_bi_replace(f.get("business_impact")) or any(x in str(f.get("business_impact", "")).lower() for x in ["pickle.loads", "yaml.load"]):
        lang = str(f.get("language") or f.get("file") or "").lower()
        if "binaryformatter" in rid_title or "typenamehandling" in rid_title or "datacontract" in rid_title or ".cs" in lang or "dotnet" in rid_title:
            f["business_impact"] = "Unsafe .NET deserialization can instantiate attacker-controlled types, leading to remote code execution, privilege escalation, or sensitive data exposure."
        elif "objectinputstream" in rid_title or "jackson" in rid_title or "snakeyaml" in rid_title or "xstream" in rid_title or "kafka" in rid_title or ".java" in lang:
            f["business_impact"] = "Unsafe Java/JVM deserialization or polymorphic type handling can trigger gadget chains, remote code execution, or message-consumer compromise."
        elif "unserialize" in rid_title or "phar" in rid_title or ".php" in lang:
            f["business_impact"] = "Unsafe PHP object deserialization can invoke gadget chains through magic methods, causing remote code execution, file access, or application takeover."
        elif "node" in rid_title or "serialize" in rid_title or "yaml" in rid_title:
            f["business_impact"] = "Unsafe Node.js dynamic parsing/deserialization can execute attacker-controlled payloads or poison application object state."

    # Big4 reporting precision enrichment: keep scanner output intact, but
    # normalize report-facing MITRE, business impact, remediation, and
    # static critical confidence optics using a central mapping catalog.
    _rk = _report_rule_key(f)
    if _rk in MITRE_BY_RULE:
        f["mitre"] = MITRE_BY_RULE[_rk]

    if _needs_bi_replace(f.get("business_impact")):
        mapped_impact = BUSINESS_IMPACT_BY_RULE.get(_rk)
        if mapped_impact:
            f["business_impact"] = mapped_impact

    if _needs_rem_replace(f.get("remediation")):
        mapped_remediation = REMEDIATION_BY_RULE.get(_rk)
        if mapped_remediation:
            f["remediation"] = mapped_remediation

    if _rk in CONFIG_CRITICAL_RULES and str(f.get("confidence", "")).upper() == "LOW":
        f["confidence"] = "Medium"
    sev = f.get("severity", "Medium")
    f["priority"]    = PRIORITY_MAP.get(sev, "P4")
    f["fingerprint"] = hashlib.md5(
        f"{f.get('vuln_type')}|{f.get('file')}|{f.get('line')}".encode()
    ).hexdigest()
    f["detected_at"] = datetime.utcnow().isoformat() + "Z"
    if "affected_files" not in f:
        f["affected_files"] = [f.get("file", "")]
        f["instances"] = 1
    # Part 3: ensure sink_category is set on every finding
    if not f.get("sink_category"):
        f["sink_category"] = "unknown"

    # Issue 2 FIX: IDOR with http sink_category is a misclassification — drop it.
    # The conflict-resolution in Phase 1 dedup handles the common case (same line
    # as SSRF), but this guard catches any IDOR on HTTP sinks that arrive solo.
    if f.get("vuln_type") == "api_idor" and f.get("sink_category") == "http":
        return {}   # signal to caller: discard this finding

    # Compute exploitability before confidence scoring so HIGH exploitability is reflected.
    f["exploitability"] = _compute_exploitability(f)
    if f.get("severity") == "Critical" and str(f.get("exploitability", "")).lower() == "low":
        # Static RCE/deserialization/auth-bypass style findings are not proven taint flows,
        # but should not present as Critical with LOW exploitability in executive reports.
        f["exploitability"] = "Medium"
    # GAP 7: confidence_score (0-100) for enterprise adoption
    _conf_base  = {"High": 80, "Medium": 55, "Low": 30, "": 40}
    _det_bonus  = {"AST Taint Analysis": 15, "TAINT-VALIDATED": 15,
                   "Regex + Contextual Analysis": 5,
                   "Structural Fallback (AST)": 8, "Regex Pattern": 0}
    _expl_bonus = {"High": 10, "Medium": 5, "Low": 0}
    # Issue 2: RCE-class always HIGH — detection method irrelevant
    _RCE_CLASS = {"code_injection", "command_injection", "insecure_deserialization"}
    _HIGH_CONF_STATIC = {"tls_bypass", "jndi_injection", "actuator_exposure", "auth_misconfiguration", "spel_injection"}
    if f.get("vuln_type") in _RCE_CLASS:
        conf_score = 90
    elif f.get("severity") == "Critical" and f.get("exploitability") == "High" and f.get("vuln_type") in _HIGH_CONF_STATIC:
        conf_score = 80
    else:
        conf_score = (
            _conf_base.get(f.get("confidence", ""), 40)
            + _det_bonus.get(f.get("detection", ""), 0)
            + _expl_bonus.get(f.get("exploitability", ""), 0)
        )
    if f.get("taint_path") and "->" in str(f.get("taint_path", "")):
        conf_score += 10
    f["confidence_score"] = min(conf_score, 100)
    # PATCH 7: standardise to HIGH/MEDIUM/LOW for enterprise consistency
    f["confidence_label"] = (
        "HIGH"   if conf_score >= 85 else
        "HIGH"   if conf_score >= 75 else   # taint-validated = HIGH
        "MEDIUM" if conf_score >= 55 else
        "LOW"
    )
    # Keep numeric score for sorting but use label for display
    if _report_rule_key(f) in CONFIG_CRITICAL_RULES and f.get("confidence_label") == "LOW":
        f["confidence_label"] = "MEDIUM"
    f["confidence"] = f["confidence_label"]  # unify the field name

    # Issue 1: always expose occurrence_count for report visibility
    # Issue 2 FIX: guarantee unique affected_files — use dict.fromkeys to preserve order
    if "affected_files" in f:
        f["affected_files"] = list(dict.fromkeys(p for p in f["affected_files"] if p))
    f["occurrence_count"]  = len(f.get("occurrences", [])) or f.get("instances", 1)
    f["unique_file_count"] = len(set(
        o.get("file","") for o in f.get("occurrences", [{"file": f.get("file","")}])
    ))
    if "occurrences" not in f:
        f["occurrences"] = [_occurrence_from_finding(f)]
    for field in ["pci_dss", "nist", "iso27001", "soc2", "exploitability",
                  "taint_path", "confidence", "cve_note", "attack_scenario"]:
        f.setdefault(field, "")
    if not f.get("cve") and not f.get("cve_note"):
        f["cve_note"] = f"Code-level vulnerability (no CVE). Mapped to {f.get('cwe', 'CWE')}."
    return f


def severity_distribution(findings: list[dict]) -> dict[str, int]:
    dist: dict = {s: 0 for s in SEVERITY_ORDER}
    for f in findings:
        dist[f.get("severity", "Info")] = dist.get(f.get("severity", "Info"), 0) + 1
    return dist


def group_by_severity(findings: list[dict]) -> list[dict]:
    return sorted(
        findings,
        key=lambda f: (
            SEVERITY_ORDER.get(f.get("severity", "Info"), 99),
            -CONFIDENCE_RANK.get(f.get("confidence", ""), 0),
        )
    )


def _score_sbom_entry(pkg: dict) -> dict:
    pkg = dict(pkg)
    cvss = _safe_float(pkg.get("cvss"))
    if pkg.get("reachable") and cvss > 0:
        pkg["risk_score"]  = min(100.0, round(cvss * 10, 1))
        pkg["fingerprint"] = hashlib.md5(
            f"{pkg.get('name', '')}|{pkg.get('cve', '')}".encode()
        ).hexdigest()
        pkg["detected_at"] = datetime.utcnow().isoformat() + "Z"
    else:
        pkg.setdefault("risk_score", 0)
    return pkg


# ---------------------------------------------------------------------------
# Insights
# ---------------------------------------------------------------------------

def generate_insights(findings: list[dict], sbom: list[dict],
                      attack_paths: list[dict]) -> list[str]:
    insights = []
    dist = severity_distribution(findings)

    if dist["Critical"] > 0:
        n = dist["Critical"]
        insights.append(
            f"CRITICAL: {n} critical vulnerabilit{'y' if n==1 else 'ies'} identified — "
            "immediate remediation required before next deployment."
        )
    if dist["High"] > 0:
        n = dist["High"]
        insights.append(
            f"HIGH RISK: {n} high-severity issue{'s' if n>1 else ''} present. "
            "Schedule remediation within 7 days per SLA guidelines."
        )

    injection_types = {"sql_injection","command_injection","code_injection","xss"}
    inj = sum(1 for f in findings if f.get("vuln_type") in injection_types)
    if inj >= 2:
        insights.append(
            f"INJECTION CLUSTER: {inj} injection-class vulnerabilities detected. "
            "Review all input validation and sanitisation across the codebase."
        )

    ssrf_count = sum(1 for f in findings if f.get("vuln_type") == "ssrf")
    if ssrf_count > 0:
        insights.append(
            f"SSRF RISK: {ssrf_count} Server-Side Request Forgery "
            f"vulnerabilit{'y' if ssrf_count==1 else 'ies'} detected. "
            "Validate all outbound HTTP request URLs against a server-side allow-list."
        )

    deser_count = sum(1 for f in findings if f.get("vuln_type") == "insecure_deserialization")
    if deser_count > 0:
        insights.append(
            f"DESERIALIZATION: {deser_count} insecure deserialization sink"
            f"{'s' if deser_count>1 else ''} detected. "
            "Never deserialize untrusted data with pickle, yaml.load, or ObjectInputStream."
        )

    secret_count = sum(1 for f in findings if f.get("vuln_type") == "hardcoded_secret")
    if secret_count > 0:
        insights.append(
            f"SECRET EXPOSURE: {secret_count} hardcoded credential"
            f"{'s' if secret_count>1 else ''} found. "
            "Rotate all affected credentials immediately and audit VCS history."
        )

    multi = [f for f in findings if f.get("instances", 1) > 1]
    if multi:
        extra = sum(f.get("instances",1)-1 for f in multi)
        insights.append(
            f"REPEATED PATTERNS: {len(multi)} root-cause vulnerability type"
            f"{'s' if len(multi)>1 else ''} with {extra} additional "
            f"occurrence{'s' if extra>1 else ''}. "
            "Fix the root cause in shared code to eliminate all occurrences."
        )

    if len(attack_paths) > 0:
        insights.append(
            f"ATTACK CHAINS: {len(attack_paths)} exploitable attack path"
            f"{'s' if len(attack_paths)>1 else ''} identified. "
            "Multi-step chains significantly increase breach probability."
        )

    pivots = get_pivot_points(findings)
    if pivots:
        insights.append(
            f"PIVOT POINTS: {', '.join(pivots[:3])} "
            f"{'are' if len(pivots)>1 else 'is'} reachable from multiple attack chains — "
            "prioritize remediation of these vulnerabilities first."
        )

    vuln_deps = [d for d in sbom if _safe_float(d.get("cvss")) >= 7.0]

    reachable_deps = [
        d for d in vuln_deps
        if (
            d.get("reachability_priority") == "REACHABLE_VULNERABLE"
            or d.get("reachability_status") == "REACHABLE"
            or d.get("reachability_status") == "MANIFEST_REFERENCED"
            or d.get("reachable") is True
            or d.get("reachable_vulnerable") is True
        )
    ]

    typosquat_deps = [f for f in findings if f.get("vuln_type") == "supply_chain_typosquat"]
    if vuln_deps:
        reach_note = (f" {len(reachable_deps)} marked reachable (exploitable in this context)."
                      if reachable_deps else "")
        insights.append(
            f"SUPPLY CHAIN: {len(vuln_deps)} dependency package"
            f"{'s' if len(vuln_deps)>1 else ''} with CVSS >= 7.0 detected.{reach_note} "
            "Upgrade to patched versions before release."
        )
    if typosquat_deps:
        insights.append(
            f"DEPENDENCY CONFUSION: {len(typosquat_deps)} probable typosquatted package"
            f"{'s' if len(typosquat_deps)>1 else ''} detected. "
            "Malicious packages execute code on install — remove immediately and audit pip history."
        )

    crit_high = dist["Critical"] + dist["High"]
    if crit_high > 0:
        insights.append(
            f"COMPLIANCE RISK: {crit_high} critical/high findings may violate "
            "PCI DSS, NIST 800-53, ISO 27001, and SOC 2 requirements. "
            "Engage security team for formal risk acceptance."
        )

    low_conf = [f for f in findings if f.get("confidence") == "Low"]
    if low_conf:
        insights.append(
            f"LOW CONFIDENCE: {len(low_conf)} finding"
            f"{'s' if len(low_conf)>1 else ''} require manual review to confirm exploitability."
        )

    if not insights:
        insights.append("No critical or high severity vulnerabilities detected. Continue monitoring.")
    return insights


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def _root_cause_family(f: dict) -> str:
    """Broad remediation-family grouping for executive root-cause reporting."""
    text = " ".join(str(f.get(k, "")) for k in (
        "title", "vuln_type", "rule_id", "cwe", "owasp", "description", "snippet"
    )).lower()

    if any(x in text for x in [
        "deserialization", "deserialize", "objectinputstream", "binaryformatter",
        "typenamehandling", "xstream", "snakeyaml", "unserialize", "phar", "gob"
    ]):
        return "Insecure Deserialization"
    if any(x in text for x in [
        "command injection", "code injection", "exec", "eval", "new function",
        "child_process", "spel", "template injection", "jndi", "log4shell", "shell"
    ]):
        return "Command / Code Injection"
    if any(x in text for x in ["sql", "hql", "jpql", "nosql", "fromsqlraw", "query injection", "orm"]):
        return "SQL / ORM / NoSQL Injection"
    if any(x in text for x in ["ssrf", "server-side request forgery", "metadata", "outbound request"]):
        return "Server-Side Request Forgery"
    if any(x in text for x in [
        "idor", "bola", "mass assignment", "overposting", "open redirect",
        "tenant", "privilege", "workflow", "approval", "csrf", "access control"
    ]):
        return "Broken Access Control / Business Logic"
    if any(x in text for x in ["secret", "credential", "password", "token", "private key", "api key"]):
        return "Secrets / Credential Exposure"
    if any(x in text for x in ["tls", "insecureskipverify", "trustmanager", "hostnameverifier", "md5", "sha-1", "crypto"]):
        return "Cryptographic Weakness"
    if any(x in text for x in ["redos", "rate limit", "resource exhaustion", "readall", "query depth", "complexity"]):
        return "Resource Exhaustion / ReDoS"
    if any(x in text for x in ["prototype pollution", "unsafe merge", "object merge"]):
        return "Broken Access Control / Business Logic"
    if any(x in text for x in ["race", "toctou", "shared map", "duplicate action", "check then act"]):
        return "Race Conditions / TOCTOU"
    if any(x in text for x in ["actuator", "xxe", "dtd", "misconfiguration", "exposed", "debug", "security configuration", "missing @valid", "missing validation", "@validated"]):
        return "Security Misconfiguration"
    if any(x in text for x in ["path traversal", "zipslip", "zip slip", "file traversal", "filepath.join"]):
        return "Path Traversal / Unsafe File Access"
    if any(x in text for x in ["xss", "cross-site scripting", "raw echo", "innerhtml", "document.write"]):
        return "Cross-Site Scripting"
    return "Security Misconfiguration / Secure Coding"

def _top_root_causes(grouped: list[dict], n: int = 5) -> list[dict]:
    """Top-N remediation families by total occurrence count.

    The detailed findings remain deduplicated by precise rule/evidence, but the
    executive priority table groups them into broad fix families so management
    sees useful remediation leverage instead of one-off rule titles.
    """
    families: dict[str, dict] = {}
    for f in grouped or []:
        family = _root_cause_family(f)
        entry = families.setdefault(family, {
            "title": family,
            "severity": "Info",
            "instances": 0,
            "affected_files": [],
            "risk_score": 0,
            "representative_findings": [],
        })
        entry["instances"] += int(f.get("instances", 1) or 1)
        files = f.get("affected_files") or [f.get("file", "")]
        for fp in files:
            if fp and fp not in entry["affected_files"]:
                entry["affected_files"].append(fp)
        if SEVERITY_ORDER.get(f.get("severity", "Info"), 99) < SEVERITY_ORDER.get(entry.get("severity", "Info"), 99):
            entry["severity"] = f.get("severity", "Info")
        entry["risk_score"] = max(_safe_float(entry.get("risk_score")), _safe_float(f.get("risk_score")))
        if len(entry["representative_findings"]) < 5:
            entry["representative_findings"].append(f.get("title", ""))

    return sorted(
        families.values(),
        key=lambda x: (int(x.get("instances", 0)), _safe_float(x.get("risk_score"))),
        reverse=True,
    )[:n]


def build_report_payload(findings: list[dict], sbom: list[dict],
                         target_path: str) -> dict[str, Any]:
    deduped  = deduplicate(findings)
    # Issue 2 FIX: drop any finding that enrich_finding signals as invalid
    # (returns {} for IDOR with http sink_category)
    enriched = [e for f in deduped
                if (e := enrich_finding(score_finding(f))) and e.get("vuln_type")]
    grouped  = group_by_severity(enriched)

    scored_sbom = [_score_sbom_entry(p) for p in sbom]

    vulnerable_sbom = [
        p for p in scored_sbom
        if (
            _safe_float(p.get("cvss")) > 0
            or p.get("cve")
            or p.get("vulnerabilities")
        )
    ]
    # Risk score reflects severity of root-cause vulnerabilities.
    # Dedup ratio is reported separately in metadata for transparency
    # but does NOT reduce the score — same vulns = same risk regardless of file count.
    total_occ  = sum(f.get("instances", 1) for f in enriched)
    n_roots    = len(enriched)
    portfolio = compute_portfolio_score(enriched + vulnerable_sbom)
    dist         = severity_distribution(enriched)
    owasp        = _build_owasp_summary(enriched)
    mitre        = _build_mitre_summary(enriched)
    attack_paths = get_attack_paths(enriched)
    insights     = generate_insights(enriched, scored_sbom, attack_paths)

    return {
        "metadata": {
            "tool":                  TOOL_FULL,
            "target":                target_path,
            "scan_date":             datetime.utcnow().isoformat() + "Z",
            "total_findings": len(enriched) + len(vulnerable_sbom),
            "sast_findings":         len(enriched),
            "sca_findings":          len(vulnerable_sbom),
            "risk_score":            portfolio,
            "dedup_ratio":           round(n_roots / total_occ, 2) if total_occ else 1.0,
            "risk_score_model":      SCORING_MODEL_DESCRIPTION,
            "severity_distribution": dist,
        },
        "findings":     enriched,
        "grouped":      grouped,
        "owasp":        owasp,
        "mitre":        mitre,
        "attack_paths": attack_paths,
        "sbom":         scored_sbom,
        "insights":     insights,
        "top_root_causes": _top_root_causes(grouped),
    }


# ---- final dedupe/executive merge patch ----
_original_deduplicate_final_gap = deduplicate

def _merge_semantic_duplicate_findings(findings: list[dict]) -> list[dict]:
    out = []
    spel_seen = None
    for f in findings:
        text = " ".join(str(f.get(k, "")) for k in ("rule_id", "title", "vuln_type", "file")).lower()
        if "spel" in text:
            if spel_seen is None:
                g = dict(f)
                g["title"] = "Spring SpEL Injection (Pattern + Taint Confirmed)" if str(g.get("detection","")).upper() == "TAINT-VALIDATED" or g.get("taint_path") else g.get("title")
                spel_seen = g
                out.append(g)
            else:
                if str(f.get("detection", "")).upper() == "TAINT-VALIDATED" or f.get("taint_path"):
                    spel_seen.update({k: v for k, v in f.items() if k in {"detection", "taint_path", "exploitability", "confidence", "risk_score"} and v})
                    spel_seen["title"] = "Spring SpEL Injection (Pattern + Taint Confirmed)"
                    occ = spel_seen.setdefault("occurrences", [])
                    occ.extend(f.get("occurrences", [_occurrence_from_finding(f)]))
                    spel_seen["instances"] = len(occ)
                continue
        else:
            out.append(f)
    return out

def deduplicate(findings: list[dict]) -> list[dict]:
    return _merge_semantic_duplicate_findings(_original_deduplicate_final_gap(findings))
# ---- end final dedupe/executive merge patch ----


# ---- final enterprise QA polish: occurrence paths + language-safe impacts ----
_PRE_QA_DEDUPLICATE = deduplicate

def _qa_normalize_occurrences(findings: list[dict]) -> list[dict]:
    for f in findings:
        occs = f.get("occurrences") or [_occurrence_from_finding(f)]
        fixed = []
        seen = set()
        for occ in occs:
            if not isinstance(occ, dict):
                continue
            file_value = occ.get("file") or occ.get("file_path") or occ.get("full_path") or f.get("file", "")
            full_value = occ.get("full_path") or file_value
            key = (file_value, occ.get("line"))
            if key in seen:
                continue
            seen.add(key)
            new_occ = dict(occ)
            new_occ["file"] = file_value
            new_occ["full_path"] = full_value
            new_occ.setdefault("file_path", file_value)
            new_occ.setdefault("file_name", str(file_value).replace("\\", "/").split("/")[-1])
            fixed.append(new_occ)
        f["occurrences"] = fixed or [_occurrence_from_finding(f)]
        f["affected_files"] = list(dict.fromkeys(o.get("file", "") for o in f["occurrences"] if o.get("file")))
        f["instances"] = len(f["occurrences"])
    return findings

def deduplicate(findings: list[dict]) -> list[dict]:
    return _qa_normalize_occurrences(_PRE_QA_DEDUPLICATE(findings))
# ---- end final enterprise QA polish ----

# -----------------------------------------------------------------------------
# Final issue-group helper used by downstream reporting quality checks
# -----------------------------------------------------------------------------
def normalize_final_issue_group(finding: dict) -> dict:
    title = str(finding.get("title", "")).upper()
    vuln = str(finding.get("vuln_type", "")).upper()
    if "TENANT_ISOLATION" in title or "TENANT_ISOLATION" in vuln:
        finding["issue_group"] = "Broken Access Control / Business Logic"
        if str(finding.get("framework", "")).lower() == "ai":
            finding["framework"] = "Application Security"
    elif "GRAPHQL" in title or "GRAPHQL" in vuln:
        finding["issue_group"] = "API Security / GraphQL"
        finding["framework"] = "graphql"
    elif "IDOR" in title or "BOLA" in title or vuln in {"IDOR", "BOLA"}:
        finding["issue_group"] = "Broken Access Control / Business Logic"
    return finding

