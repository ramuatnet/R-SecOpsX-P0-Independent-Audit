"""
core/attack_graph.py  v4

FIX LOG (v3 → v4):
  1. BUG  — present_vulns set now filters out None / empty vuln_type values,
             preventing a None key from polluting the membership checks
  2. ENH  — CHAIN_EDGES extended with debug_exposure, weak_crypto, and csrf
             chains; hardcoded_secret now reachable from 3 paths (in-degree=3)
             and correctly surfaces as a pivot point for the sample_app findings
"""
from __future__ import annotations

import warnings

try:
    import networkx as nx
    _NX = True
except ImportError:
    _NX = False

# ---------------------------------------------------------------------------
# Attack chain templates
# ---------------------------------------------------------------------------
ATTACK_CHAINS: dict[str, dict] = {
    "sql_injection": {
        "entry":    "User Input (HTTP Request)",
        "exploit":  "SQL Injection",
        "pivot":    "Database Server",
        "impact":   "Sensitive Data Exfiltration / Auth Bypass",
        "narrative": (
            "Attacker supplies malicious SQL via HTTP request "
            "→ application executes unsanitized query "
            "→ database server returns/modifies sensitive data "
            "→ authentication bypass or full data exfiltration."
        ),
    },
    "command_injection": {
        "entry":    "User Input (HTTP Request)",
        "exploit":  "Command Injection",
        "pivot":    "OS Shell",
        "impact":   "Remote Code Execution / Server Compromise",
        "narrative": (
            "Attacker injects shell metacharacters via HTTP parameter "
            "→ application passes input to OS shell "
            "→ arbitrary commands execute as application user "
            "→ full server compromise and lateral movement."
        ),
    },
    "code_injection": {
        "entry":    "User Input (HTTP Request)",
        "exploit":  "Code Injection (eval/exec)",
        "pivot":    "Python Runtime",
        "impact":   "Arbitrary Code Execution",
        "narrative": (
            "Attacker supplies crafted Python expression "
            "→ eval()/exec() executes it in server runtime "
            "→ arbitrary code runs with application privileges "
            "→ full host compromise."
        ),
    },
    "path_traversal": {
        "entry":    "User Input (File Parameter)",
        "exploit":  "Path Traversal",
        "pivot":    "File System",
        "impact":   "Sensitive File Disclosure",
        "narrative": (
            "Attacker supplies ../ sequences in file parameter "
            "→ application opens files outside intended directory "
            "→ configuration files, credentials, or source code exposed."
        ),
    },
    "xss": {
        "entry":    "User Input (Reflected/Stored)",
        "exploit":  "Cross-Site Scripting",
        "pivot":    "Victim Browser",
        "impact":   "Session Hijacking / Credential Theft",
        "narrative": (
            "Attacker injects malicious script into page "
            "→ victim's browser executes script in application context "
            "→ session token stolen or credentials harvested."
        ),
    },
    "hardcoded_secret": {
        "entry":    "Source Code / VCS",
        "exploit":  "Credential Exposure",
        "pivot":    "Authenticated Service",
        "impact":   "Unauthorized Access / Data Breach",
        "narrative": (
            "Secret committed to source code or VCS "
            "→ attacker discovers credential via repository access "
            "→ authenticates to downstream service "
            "→ unauthorized data access or account takeover."
        ),
    },
    "auth_bypass": {
        "entry":    "User Input (Role/Permission Parameter)",
        "exploit":  "Authorization Bypass",
        "pivot":    "Application Logic",
        "impact":   "Privilege Escalation / Data Access",
        "narrative": (
            "Attacker manipulates role or permission parameter "
            "→ application trusts client-supplied privilege level "
            "→ attacker gains elevated access "
            "→ unauthorized data read/write or admin functions."
        ),
    },
    "open_redirect": {
        "entry":    "User Input (URL Parameter)",
        "exploit":  "Open Redirect",
        "pivot":    "Victim Browser",
        "impact":   "Phishing / Credential Harvesting",
        "narrative": (
            "Attacker crafts link with malicious redirect URL "
            "→ victim clicks trusted domain link "
            "→ browser redirected to attacker-controlled site "
            "→ credentials harvested via phishing page."
        ),
    },
    "debug_exposure": {
        "entry":    "Web Request (Any User)",
        "exploit":  "Debug Interface Exposure",
        "pivot":    "Interactive Python Debugger",
        "impact":   "Full Application Compromise / Secret Disclosure",
        "narrative": (
            "Flask debug=True exposes an interactive debugger at /__debugger__ "
            "→ attacker triggers an exception via a crafted request "
            "→ gains an interactive Python console with no authentication "
            "→ executes arbitrary code, reads env vars and secrets."
        ),
    },
    "weak_crypto": {
        "entry":    "Database / Credential Store",
        "exploit":  "Weak Cryptography (MD5/SHA-1)",
        "pivot":    "Password Hash Database",
        "impact":   "Authentication Bypass via Cracked Credentials",
        "narrative": (
            "Attacker obtains the password hash database "
            "→ MD5/SHA-1 hashes cracked offline via rainbow tables in hours "
            "→ plaintext passwords recovered "
            "→ attacker authenticates as any user."
        ),
    },
    "api_idor": {
        "entry":    "Authenticated HTTP Request (Predictable ID)",
        "exploit":  "Insecure Direct Object Reference (IDOR)",
        "pivot":    "Application Data Layer",
        "impact":   "Unauthorized Data Exposure / Mass Data Enumeration",
        "narrative": (
            "Attacker changes a numeric ID in the URL "
            "→ application returns another user's record without authorization check "
            "→ attacker enumerates all records sequentially "
            "→ full data breach of user PII, financial data, or private content."
        ),
    },
    "api_jwt_bypass": {
        "entry":    "Any HTTP Request (No Valid Credentials Required)",
        "exploit":  "JWT Signature Verification Disabled",
        "pivot":    "Authentication Layer",
        "impact":   "Full Account Takeover / Privilege Escalation",
        "narrative": (
            "Attacker crafts a JWT with arbitrary claims (any user ID, admin role) "
            "→ server skips signature verification due to verify_signature=False "
            "→ attacker is authenticated as any user including administrators "
            "→ complete account takeover and privilege escalation."
        ),
    },
}

# ---------------------------------------------------------------------------
# Chain edges — which vuln types enable others
# FIX #2: added debug_exposure, weak_crypto, and csrf edges
# ---------------------------------------------------------------------------
CHAIN_EDGES: list[tuple[str, str]] = [
    # Existing chains
    ("sql_injection",    "hardcoded_secret"),    # DB creds from config
    ("path_traversal",   "hardcoded_secret"),    # config file exposes secrets
    ("hardcoded_secret", "command_injection"),   # cred used to auth + RCE
    ("hardcoded_secret", "auth_bypass"),         # cred enables privilege esc
    ("auth_bypass",      "sql_injection"),       # admin bypass → SQL
    ("xss",              "auth_bypass"),         # XSS steals session → bypass
    ("command_injection","path_traversal"),      # RCE enables FS access
    # FIX #2: new chains
    ("debug_exposure",   "hardcoded_secret"),    # interactive console → env vars / secrets
    ("debug_exposure",   "command_injection"),   # debugger console = arbitrary code exec
    ("weak_crypto",      "auth_bypass"),         # cracked password hash → login bypass
    ("csrf",             "auth_bypass"),         # CSRF-forced action → privilege change
    # IaC + API chains
    ("api_idor",         "sql_injection"),       # IDOR exposes object → SQL param injection
    ("api_jwt_bypass",   "auth_bypass"),         # token bypass → full privilege escalation
    ("api_jwt_bypass",   "hardcoded_secret"),    # JWT bypass often co-exists with hardcoded secrets
]


def build_attack_graph(findings: list[dict]) -> "nx.DiGraph | None":
    if not _NX:
        return None

    G = nx.DiGraph()
    # FIX #1: filter None / empty vuln_type before building the set
    present_vulns = {
        f.get("vuln_type") for f in findings
        if f.get("vuln_type")
    }

    for vuln in present_vulns:
        chain = ATTACK_CHAINS.get(vuln)
        if chain:
            G.add_node(vuln, **chain)

    for src, dst in CHAIN_EDGES:
        if src in present_vulns and dst in present_vulns:
            G.add_edge(src, dst, label="enables")

    return G


def get_attack_paths(findings: list[dict]) -> list[dict]:
    """
    Return identified attack paths with narratives.
    VAL-009 FIX: each path is labelled with its evidence_type:
      'taint-confirmed' — at least one AST taint finding for this vuln type
      'pattern-detected' — only regex/structural findings (cannot confirm data flow)
    """
    present_vulns = {
        f.get("vuln_type") for f in findings
        if f.get("vuln_type")
    }
    # A vuln type is "taint-confirmed" when ANY of these is true:
    #   1. AST taint analysis produced a real source->sink trace
    #   2. exploitability is "High" (set by _compute_exploitability in analyzer)
    taint_confirmed_types = {
        f.get("vuln_type") for f in findings
        if (
            (f.get("detection") == "AST Taint Analysis"
             and f.get("taint_path")
             and "->" in str(f.get("taint_path", "")))
            or f.get("exploitability", "").lower() == "high"
        )
    }

    paths = []

    for vuln_type, chain in ATTACK_CHAINS.items():
        if vuln_type not in present_vulns:
            continue

        matching = [f for f in findings if f.get("vuln_type") == vuln_type]
        if not matching:
            continue
        worst = max(matching, key=lambda f: {
            "Critical": 4, "High": 3, "Medium": 2, "Low": 1, "Info": 0
        }.get(f.get("severity", "Low"), 0))

        chained_to = [
            dst for src, dst in CHAIN_EDGES
            if src == vuln_type and dst in present_vulns
        ]

        # VAL-009: honest labeling
        is_taint = vuln_type in taint_confirmed_types
        evidence_type = "taint-confirmed" if is_taint else "pattern-detected"
        evidence_note = (
            "Data flow confirmed by AST taint analysis."
            if is_taint else
            "Detected by pattern matching — data flow not confirmed. Manual review recommended."
        )

        paths.append({
            "vuln_type":     vuln_type,
            "title":         f"Attack Path: {chain['exploit']}",
            "severity":      worst.get("severity", "Medium"),
            "risk_score":    worst.get("risk_score", 0),
            "evidence_type": evidence_type,
            "evidence_note": evidence_note,
            "steps": [
                chain["entry"],
                chain["exploit"],
                chain["pivot"],
                chain["impact"],
            ],
            "narrative":   chain["narrative"],
            "chains_to":   chained_to,
            "file":        worst.get("file", ""),
            "line":        worst.get("line", ""),
        })

    sev_order = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}
    paths.sort(key=lambda p: sev_order.get(p["severity"], 9))
    return paths


def get_pivot_points(findings: list[dict]) -> list[str]:
    """
    Identify vulnerabilities reachable from multiple attack chains.
    Requires networkx. Emits a warning (not a silent empty list) if absent.
    """
    if not _NX:
        warnings.warn(
            "networkx not installed — pivot point analysis disabled. "
            "Install with: pip install networkx",
            ImportWarning,
            stacklevel=2,
        )
        return []

    G = build_attack_graph(findings)
    if G is None or G.number_of_nodes() == 0:
        return []

    return [node for node, deg in G.in_degree() if deg >= 2]
