from collections import defaultdict
import hashlib
import re


def normalize(snippet: str) -> str:
    snippet = snippet.lower()
    snippet = re.sub(r'\s+', '', snippet)
    snippet = re.sub(r'["\'].*?["\']', 'STR', snippet)
    return snippet


def root_key(f: dict) -> str:
    base = f.get("vuln_type", "") + normalize(f.get("snippet", ""))
    return hashlib.md5(base.encode()).hexdigest()


def calculate_risk(severity: str, instances: int) -> int:
    base = {
        "Critical": 9,
        "High": 7,
        "Medium": 5,
        "Low": 3,
        "Info": 1
    }.get(severity, 5)

    # boost if repeated across files
    multiplier = min(2, 1 + (instances / 10))
    return round(base * multiplier, 1)


def group_findings(findings: list[dict]) -> list[dict]:
    grouped = defaultdict(lambda: {
        "title": None,
        "vuln_type": None,
        "severity": None,
        "priority": None,
        "snippet": None,

        # PDF-compatible fields
        "instances": 0,
        "affected_files": [],
        "file": "",
        "line": "",

        # compliance
        "owasp": "",
        "mitre": "",
        "cwe": "",
        "pci_dss": "",
        "nist": "",
        "iso27001": "",
        "soc2": "",

        # intelligence
        "taint_path": "",
        "description": "",
        "business_impact": "",
        "remediation": [],
        "risk_score": 0,
    })

    for f in findings:
        key = root_key(f)
        g = grouped[key]

        # core
        g["title"] = f.get("title")
        g["vuln_type"] = f.get("vuln_type")
        g["severity"] = f.get("severity")
        g["priority"] = f.get("priority")
        g["snippet"] = f.get("snippet")

        # metadata (preserve first occurrence)
        if not g["file"]:
            g["file"] = f.get("file")
            g["line"] = f.get("line")

        # compliance (preserve)
        g["owasp"] = f.get("owasp")
        g["mitre"] = f.get("mitre")
        g["cwe"] = f.get("cwe")
        g["pci_dss"] = f.get("pci_dss")
        g["nist"] = f.get("nist")
        g["iso27001"] = f.get("iso27001")
        g["soc2"] = f.get("soc2")

        # description
        g["description"] = f.get("description")
        g["business_impact"] = f.get("business_impact")
        g["remediation"] = f.get("remediation", [])

        # taint
        if f.get("taint_path") and not g["taint_path"]:
            g["taint_path"] = f.get("taint_path")

        # occurrences
        file_entry = f.get("file")
        if file_entry not in g["affected_files"]:
            g["affected_files"].append(file_entry)

    # finalize
    results = []
    for g in grouped.values():
        g["instances"] = len(g["affected_files"])
        g["risk_score"] = calculate_risk(g["severity"], g["instances"])
        results.append(g)

    return results