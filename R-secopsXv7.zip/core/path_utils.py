from __future__ import annotations

import os
from pathlib import Path


def to_report_path(file_path: str, target_root: str) -> str:
    try:
        rel = os.path.relpath(file_path, target_root)
        root_name = Path(target_root).name
        return str(Path(root_name) / rel)
    except Exception:
        return file_path


def file_name(file_path: str) -> str:
    return Path(file_path).name